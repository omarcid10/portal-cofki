-- =====================================================================
-- Cofki Auditorías · 04 · Vistas para pantallas y dashboards
-- (security_invoker: respetan los permisos del usuario que consulta)
-- =====================================================================

-- Avance de cada auditoría (barra de progreso y "qué falta")
create view public.v_audit_progress with (security_invoker = true) as
select a.id as audit_id,
       count(i.id) as total_puntos,
       count(i.id) filter (where public.respuesta_completa(i.item_type, r.result, r.text_value, r.measurement_value)) as respondidos,
       count(i.id) filter (where r.result in ('parcial','no_cumple')) as hallazgos,
       count(i.id) filter (where r.result in ('parcial','no_cumple') and r.priority = 'critica') as hallazgos_criticos
from public.audits a
join public.audit_sections s     on s.template_version_id = a.template_version_id
join public.audit_subsections sb on sb.section_id = s.id
join public.audit_items i        on i.subsection_id = sb.id
left join public.audit_responses r on r.audit_id = a.id and r.item_id = i.id
group by a.id;

-- Avance por proceso dentro de una auditoría (índice de procesos)
create view public.v_audit_section_progress with (security_invoker = true) as
select a.id as audit_id, s.id as section_id, s.name as section_name, s.sort,
       count(i.id) as total_puntos,
       count(i.id) filter (where public.respuesta_completa(i.item_type, r.result, r.text_value, r.measurement_value)) as respondidos,
       count(i.id) filter (where r.result in ('parcial','no_cumple')) as hallazgos
from public.audits a
join public.audit_sections s     on s.template_version_id = a.template_version_id
join public.audit_subsections sb on sb.section_id = s.id
join public.audit_items i        on i.subsection_id = sb.id
left join public.audit_responses r on r.audit_id = a.id and r.item_id = i.id
group by a.id, s.id, s.name, s.sort;

-- Resumen semanal: una fila por semana × sucursal × tipo (detecta "no realizada")
create view public.weekly_summary with (security_invoker = true) as
with semanas as (
  select generate_series(
           coalesce((select min(week_start) from public.audits), public.inicio_semana()),
           public.inicio_semana(), interval '7 days')::date as week_start
)
select w.week_start, b.id as branch_id, b.name as branch_name, b.sort as branch_sort,
       t.id as audit_type_id, t.code as audit_type_code, t.name as audit_type_name,
       a.id as audit_id, a.status, a.leader_id, u.full_name as leader_name,
       a.score_total, a.started_at, a.finished_at, a.elapsed_seconds, a.active_seconds,
       a.closed_under_target,
       case when a.id is null then 'no_realizada'
            when a.status = 'en_curso' then 'en_curso'
            else 'cerrada' end as estado_semana
from semanas w
cross join public.branches b
cross join public.audit_types t
left join public.audits a on a.week_start = w.week_start and a.branch_id = b.id
                         and a.audit_type_id = t.id and a.status <> 'cancelada'
left join public.users u on u.id = a.leader_id
where b.active and t.active;

-- Calificación por sucursal y semana (A&B, Front y total ponderado)
create view public.v_branch_week_scores with (security_invoker = true) as
select ws.week_start, ws.branch_id, ws.branch_name, ws.branch_sort,
       max(ws.score_total) filter (where ws.audit_type_code = 'AB'    and ws.status = 'cerrada') as score_ab,
       max(ws.score_total) filter (where ws.audit_type_code = 'FRONT' and ws.status = 'cerrada') as score_front,
       round(sum(ws.score_total * public.config('peso_sucursal_' || ws.audit_type_code, 0.5))
               filter (where ws.status = 'cerrada')
             / nullif(sum(public.config('peso_sucursal_' || ws.audit_type_code, 0.5))
               filter (where ws.status = 'cerrada'), 0), 2) as score_total,
       count(*) filter (where ws.status = 'cerrada') as auditorias_cerradas,
       count(*) as auditorias_programadas
from public.weekly_summary ws
group by ws.week_start, ws.branch_id, ws.branch_name, ws.branch_sort;

-- Planes de acción con banderas de vencido / próximo a vencer
create view public.v_action_plans with (security_invoker = true) as
select p.*,
       b.name as branch_name, t.code as audit_type_code, t.name as audit_type_name,
       s.name as section_name, i.code as item_code, i.text as item_text,
       u.full_name as created_by_name, a.week_start, a.leader_id,
       public.plan_abierto(p.status) as abierto,
       public.plan_abierto(p.status) and p.due_date < public.hoy() as vencido,
       public.plan_abierto(p.status) and p.due_date >= public.hoy()
         and p.due_date <= public.hoy() + public.config('dias_proxima_vencer', 3)::int as proximo_a_vencer,
       greatest(public.hoy() - p.due_date, 0) as dias_vencido
from public.action_plans p
join public.audits a on a.id = p.audit_id
left join public.branches b    on b.id = p.branch_id
left join public.audit_types t on t.id = p.audit_type_id
left join public.audit_sections s on s.id = p.section_id
left join public.audit_items i    on i.id = p.item_id
left join public.users u          on u.id = p.created_by
where a.status <> 'cancelada';

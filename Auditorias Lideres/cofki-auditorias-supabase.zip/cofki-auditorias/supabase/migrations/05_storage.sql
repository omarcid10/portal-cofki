-- =====================================================================
-- Cofki Auditorías · 05 · Storage de evidencias (bucket privado)
-- Ruta de cada foto: {audit_id}/{item_id}/{uuid}.jpg  (+ _thumb.jpg)
-- =====================================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('evidencias', 'evidencias', false, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create or replace function public.audit_id_de_ruta(p_name text) returns uuid
language plpgsql immutable set search_path = public as $$
begin
  return (split_part(p_name, '/', 1))::uuid;
exception when others then
  return null;
end $$;
grant execute on function public.audit_id_de_ruta(text) to authenticated;

create policy "evidencias_lectura" on storage.objects for select to authenticated
  using (bucket_id = 'evidencias' and public.es_usuario_activo());

create policy "evidencias_subir" on storage.objects for insert to authenticated
  with check (bucket_id = 'evidencias'
              and public.soy_dueno_en_curso(public.audit_id_de_ruta(name)));

create policy "evidencias_borrar" on storage.objects for delete to authenticated
  using (bucket_id = 'evidencias'
         and public.soy_dueno_en_curso(public.audit_id_de_ruta(name)));

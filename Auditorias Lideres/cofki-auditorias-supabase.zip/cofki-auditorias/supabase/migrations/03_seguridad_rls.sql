-- =====================================================================
-- Cofki Auditorías · 03 · Seguridad (Row Level Security)
-- Reglas:
--  · Todo usuario activo puede CONSULTAR (líderes ven el otro tipo en solo lectura).
--  · Líder: edita solo SUS auditorías y solo mientras están en curso.
--  · Líder: cambia estatus solo de los planes que él creó (vía función).
--  · Socios: no capturan; reabren auditorías y administran catálogo/configuración.
--  · Iniciar, cerrar, cancelar y reabrir solo por funciones oficiales (no hay insert directo).
-- =====================================================================

alter table public.roles               enable row level security;
alter table public.branches            enable row level security;
alter table public.audit_types         enable row level security;
alter table public.users               enable row level security;
alter table public.scoring_config      enable row level security;
alter table public.template_versions   enable row level security;
alter table public.audit_sections      enable row level security;
alter table public.audit_subsections   enable row level security;
alter table public.audit_items         enable row level security;
alter table public.audits              enable row level security;
alter table public.audit_responses     enable row level security;
alter table public.action_plans        enable row level security;
alter table public.action_plan_updates enable row level security;
alter table public.audit_evidence      enable row level security;
alter table public.audit_scores        enable row level security;
alter table public.audit_change_log    enable row level security;

-- ---------- Lectura para cualquier usuario activo ----------
do $$
declare t text;
begin
  foreach t in array array['roles','branches','audit_types','users','scoring_config','template_versions',
    'audit_sections','audit_subsections','audit_items','audits','audit_responses','action_plans',
    'action_plan_updates','audit_evidence','audit_scores','audit_change_log']
  loop
    execute format('create policy "lectura_usuarios_activos" on public.%I for select to authenticated using (public.es_usuario_activo())', t);
  end loop;
end $$;

-- ---------- Configuración y catálogo: socios ----------
create policy "socios_editan_config" on public.scoring_config
  for update to authenticated using (public.es_socio()) with check (public.es_socio());

do $$
declare t text;
begin
  foreach t in array array['audit_sections','audit_subsections','audit_items'] loop
    execute format('create policy "socios_insertan" on public.%I for insert to authenticated with check (public.es_socio())', t);
    execute format('create policy "socios_editan"   on public.%I for update to authenticated using (public.es_socio()) with check (public.es_socio())', t);
    execute format('create policy "socios_borran"   on public.%I for delete to authenticated using (public.es_socio())', t);
  end loop;
end $$;
-- (Solo versiones en borrador; lo valida el trigger del catálogo.)

-- ---------- Auditorías ----------
-- Sin insert/delete directo: se crean con iniciar_auditoria().
create policy "lider_edita_su_auditoria" on public.audits
  for update to authenticated
  using (leader_id = auth.uid() and status = 'en_curso')
  with check (leader_id = auth.uid());

-- ---------- Respuestas y evidencias: dueño de la auditoría en curso ----------
create or replace function public.soy_dueno_en_curso(p_audit_id uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from audits
                  where id = p_audit_id and leader_id = auth.uid() and status = 'en_curso')
$$;
grant execute on function public.soy_dueno_en_curso(uuid) to authenticated;
revoke execute on function public.soy_dueno_en_curso(uuid) from public, anon;

create policy "dueno_inserta" on public.audit_responses for insert to authenticated
  with check (public.soy_dueno_en_curso(audit_id));
create policy "dueno_edita"   on public.audit_responses for update to authenticated
  using (public.soy_dueno_en_curso(audit_id)) with check (public.soy_dueno_en_curso(audit_id));
create policy "dueno_borra"   on public.audit_responses for delete to authenticated
  using (public.soy_dueno_en_curso(audit_id));

create policy "dueno_inserta" on public.audit_evidence for insert to authenticated
  with check (public.soy_dueno_en_curso(audit_id));
create policy "dueno_edita"   on public.audit_evidence for update to authenticated
  using (public.soy_dueno_en_curso(audit_id)) with check (public.soy_dueno_en_curso(audit_id));
create policy "dueno_borra"   on public.audit_evidence for delete to authenticated
  using (public.soy_dueno_en_curso(audit_id));

-- ---------- Planes de acción ----------
create policy "dueno_crea_plan" on public.action_plans for insert to authenticated
  with check (public.soy_dueno_en_curso(audit_id));
create policy "creador_edita_plan" on public.action_plans for update to authenticated
  using (created_by = auth.uid()) with check (created_by = auth.uid());
create policy "creador_borra_plan" on public.action_plans for delete to authenticated
  using (created_by = auth.uid() and public.soy_dueno_en_curso(audit_id));

-- action_plan_updates, audit_scores, audit_change_log, users, template_versions:
-- sin políticas de escritura → solo se escriben desde funciones oficiales o desde el panel de Supabase.

-- =====================================================================
-- Cofki Auditorías · 01 · Esquema (tipos y tablas)
-- Ejecutar en: Supabase → SQL Editor. Orden: 01 → 07.
-- =====================================================================

-- ---------- Tipos ----------
create type public.audit_status    as enum ('en_curso','cerrada','cancelada');
create type public.response_result as enum ('cumple','parcial','no_cumple','na');
create type public.priority_level  as enum ('critica','alta','media','baja');
create type public.item_type       as enum ('evaluable','medicion','dato');
create type public.action_status   as enum ('pendiente','en_proceso','corregido','no_corregido');
create type public.template_status as enum ('borrador','publicada','retirada');

-- ---------- Utilidad: updated_at automático ----------
create or replace function public.set_updated_at() returns trigger
language plpgsql set search_path = public as $$ begin new.updated_at := now(); return new; end $$;

-- ---------- Catálogos generales ----------
create table public.roles (
  code text primary key,                 -- lider_ab | lider_front | socio
  name text not null
);

create table public.branches (
  id     serial primary key,
  code   text not null unique,
  name   text not null,
  active boolean not null default true,
  sort   int not null default 0
);

create table public.audit_types (
  id                 serial primary key,
  code               text not null unique,  -- AB | FRONT
  name               text not null,
  target_min_minutes int  not null default 180,
  target_max_minutes int  not null default 240,
  active             boolean not null default true,
  sort               int not null default 0
);

create table public.users (
  id            uuid primary key references auth.users(id) on delete cascade,
  full_name     text not null,
  email         text,
  role_code     text not null references public.roles(code),
  audit_type_id int  references public.audit_types(id),
  active        boolean not null default true,
  created_at    timestamptz not null default now(),
  constraint users_tipo_por_rol check (
    (role_code = 'socio' and audit_type_id is null) or
    (role_code <> 'socio' and audit_type_id is not null)
  )
);

create table public.scoring_config (
  key         text primary key,
  value       numeric not null,
  description text
);

-- ---------- Plantillas versionadas ----------
create table public.template_versions (
  id            serial primary key,
  audit_type_id int not null references public.audit_types(id),
  version       int not null,
  status        public.template_status not null default 'borrador',
  notes         text,
  created_at    timestamptz not null default now(),
  published_at  timestamptz,
  unique (audit_type_id, version)
);
-- Solo una versión publicada por tipo
create unique index template_una_publicada
  on public.template_versions(audit_type_id) where status = 'publicada';

create table public.audit_sections (          -- Proceso (los 15 grandes)
  id                  serial primary key,
  template_version_id int not null references public.template_versions(id) on delete cascade,
  code                text,
  name                text not null,
  sort                int not null default 0,
  weight              numeric(6,2) not null default 1 check (weight >= 0)
);

create table public.audit_subsections (       -- Subproceso
  id         serial primary key,
  section_id int not null references public.audit_sections(id) on delete cascade,
  name       text not null,
  sort       int not null default 0,
  is_default boolean not null default false   -- "General" oculto cuando el proceso no tiene subgrupos
);

create table public.audit_items (             -- Punto auditable
  id            serial primary key,
  subsection_id int not null references public.audit_subsections(id) on delete cascade,
  code          text not null,                -- AB-001, FR-001
  text          text not null,
  original_text text,
  guidance      text,
  sort          int not null default 0,
  item_type     public.item_type not null default 'evaluable',
  weight        numeric(6,2) not null default 1 check (weight >= 0),
  unit          text,
  allow_na      boolean not null default true
);

-- ---------- Auditorías ----------
create table public.audits (
  id                  uuid primary key default gen_random_uuid(),
  template_version_id int  not null references public.template_versions(id),
  audit_type_id       int  not null references public.audit_types(id),
  branch_id           int  not null references public.branches(id),
  leader_id           uuid not null references public.users(id),
  week_start          date not null,              -- lunes de la semana (hora Monterrey)
  audit_date          date not null,
  status              public.audit_status not null default 'en_curso',
  started_at          timestamptz not null default now(),
  finished_at         timestamptz,
  elapsed_seconds     int,
  active_seconds      int not null default 0,
  last_heartbeat_at   timestamptz,
  closed_under_target boolean,
  general_comments    text,
  strengths           text,
  opportunities       text,
  score_total         numeric(5,2),
  snapshot            jsonb,
  cancelled_at        timestamptz,
  cancelled_by        uuid references public.users(id),
  cancel_reason       text,
  reopened_count      int not null default 0,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);
-- Evita duplicados: 1 auditoría por sucursal + tipo + semana (sin contar canceladas)
create unique index audits_sin_duplicados
  on public.audits(branch_id, audit_type_id, week_start) where status <> 'cancelada';
create index audits_semana on public.audits(week_start);
create index audits_lider  on public.audits(leader_id);
create trigger audits_updated before update on public.audits
  for each row execute function public.set_updated_at();

create table public.audit_responses (
  id                uuid primary key default gen_random_uuid(),
  audit_id          uuid not null references public.audits(id) on delete cascade,
  item_id           int  not null references public.audit_items(id),
  result            public.response_result,
  priority          public.priority_level,
  comment           text,
  measurement_value numeric,
  text_value        text,
  answered_at       timestamptz not null default now(),
  answered_by       uuid default auth.uid(),
  updated_at        timestamptz not null default now(),
  unique (audit_id, item_id)
);
create trigger responses_updated before update on public.audit_responses
  for each row execute function public.set_updated_at();

create table public.action_plans (
  id                uuid primary key default gen_random_uuid(),
  audit_id          uuid not null references public.audits(id) on delete cascade,
  response_id       uuid references public.audit_responses(id) on delete set null,
  item_id           int  references public.audit_items(id),
  section_id        int  references public.audit_sections(id),
  branch_id         int  references public.branches(id),
  audit_type_id     int  references public.audit_types(id),
  finding           text not null,
  corrective_action text not null,
  responsible       text not null,
  priority          public.priority_level not null,
  due_date          date not null,
  status            public.action_status not null default 'pendiente',
  created_by        uuid references public.users(id),
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  closed_at         timestamptz,
  closed_by         uuid references public.users(id)
);
create index plans_estatus on public.action_plans(status, due_date);
create index plans_sucursal on public.action_plans(branch_id);
create trigger plans_updated before update on public.action_plans
  for each row execute function public.set_updated_at();

create table public.action_plan_updates (
  id             uuid primary key default gen_random_uuid(),
  action_plan_id uuid not null references public.action_plans(id) on delete cascade,
  from_status    public.action_status,
  to_status      public.action_status not null,
  comment        text,
  created_by     uuid references public.users(id),
  created_at     timestamptz not null default now()
);

create table public.audit_evidence (
  id             uuid primary key default gen_random_uuid(),
  audit_id       uuid not null references public.audits(id) on delete cascade,
  response_id    uuid references public.audit_responses(id) on delete set null,
  action_plan_id uuid references public.action_plans(id) on delete set null,
  item_id        int  not null references public.audit_items(id),
  section_id     int  references public.audit_sections(id),
  branch_id      int  references public.branches(id),
  leader_id      uuid references public.users(id),
  storage_path   text not null unique,
  thumb_path     text,
  caption        text,
  taken_at       timestamptz,
  created_by     uuid references public.users(id),
  created_at     timestamptz not null default now()
);
create index evidence_auditoria on public.audit_evidence(audit_id);

create table public.audit_scores (             -- Calificaciones congeladas al cerrar
  id       bigserial primary key,
  audit_id uuid not null references public.audits(id) on delete cascade,
  level    text not null check (level in ('punto','subproceso','proceso','total')),
  ref_id   int,
  earned   numeric,
  possible numeric,
  pct      numeric(5,2)
);
create index scores_auditoria on public.audit_scores(audit_id, level);

create table public.audit_change_log (         -- Registro de cancelaciones, reaperturas y cambios post-cierre
  id          bigserial primary key,
  audit_id    uuid references public.audits(id) on delete cascade,
  table_name  text not null,
  record_id   text,
  action      text not null,
  old_data    jsonb,
  new_data    jsonb,
  reason      text,
  changed_by  uuid default auth.uid(),
  changed_at  timestamptz not null default now()
);

-- =====================================================================
-- Cofki Auditorías · 02 · Funciones, reglas de negocio y candados
-- =====================================================================

-- ---------- Fechas (hora de Monterrey, semana lunes–domingo) ----------
create or replace function public.hoy() returns date
language sql stable set search_path = public as $$ select (now() at time zone 'America/Monterrey')::date $$;

create or replace function public.inicio_semana(p_ts timestamptz default now()) returns date
language sql stable set search_path = public as $$ select date_trunc('week', p_ts at time zone 'America/Monterrey')::date $$;

-- ---------- Usuario actual ----------
create or replace function public.mi_rol() returns text
language sql stable security definer set search_path = public as $$
  select role_code from users where id = auth.uid() and active
$$;

create or replace function public.mi_tipo_auditoria() returns int
language sql stable security definer set search_path = public as $$
  select audit_type_id from users where id = auth.uid() and active
$$;

create or replace function public.es_socio() returns boolean
language sql stable set search_path = public as $$ select coalesce(public.mi_rol() = 'socio', false) $$;

create or replace function public.es_usuario_activo() returns boolean
language sql stable set search_path = public as $$ select public.mi_rol() is not null $$;

create or replace function public.config(p_key text, p_default numeric) returns numeric
language sql stable security definer set search_path = public as $$
  select coalesce((select value from scoring_config where key = p_key), p_default)
$$;

-- ---------- Reglas simples ----------
-- Un plan sigue abierto (visible y cuenta para vencidos) salvo que esté "corregido".
create or replace function public.plan_abierto(p public.action_status) returns boolean
language sql immutable set search_path = public as $$ select p in ('pendiente','en_proceso','no_corregido') $$;

-- ¿El punto ya tiene respuesta suficiente?
create or replace function public.respuesta_completa(
  p_tipo public.item_type, p_result public.response_result, p_texto text, p_valor numeric)
returns boolean language sql immutable set search_path = public as $$
  select case when p_tipo = 'dato'
              then p_result is not null or nullif(trim(p_texto),'') is not null or p_valor is not null
              else p_result is not null end
$$;

-- Marca interna: las funciones oficiales (RPC) la encienden para poder cambiar campos protegidos.
create or replace function public.en_rpc() returns boolean
language sql stable set search_path = public as $$ select coalesce(current_setting('app.rpc', true), '') = 'on' $$;

-- ---------- Calificación (transparente) ----------
-- Punto: Cumple = peso · Parcial = peso × factor · No cumple = 0 · N/A y Dato no cuentan.
-- Subproceso y Proceso: Σ obtenido ÷ Σ posible.
-- Total: promedio de procesos ponderado por el peso de cada proceso.
create or replace function public.puntaje_auditoria(p_audit_id uuid) returns jsonb
language sql stable set search_path = public as $$
with pf as (select public.config('parcial_factor', 0.5) as f),
a as (select * from audits where id = p_audit_id),
it as (
  select i.id as item_id, sb.id as sub_id, sb.name as sub_name, sb.sort as sub_sort, sb.is_default,
         s.id as sec_id, s.name as sec_name, s.sort as sec_sort, s.weight as sec_weight,
         case when i.item_type <> 'dato' and r.result in ('cumple','parcial','no_cumple')
              then i.weight else 0 end as posible,
         case when i.item_type = 'dato' then 0
              when r.result = 'cumple'  then i.weight
              when r.result = 'parcial' then i.weight * (select f from pf)
              else 0 end as obtenido
  from a
  join audit_sections s     on s.template_version_id = a.template_version_id
  join audit_subsections sb on sb.section_id = s.id
  join audit_items i        on i.subsection_id = sb.id
  left join audit_responses r on r.audit_id = a.id and r.item_id = i.id
),
sub as (select sec_id, sub_id, sub_name, sub_sort, bool_and(is_default) as is_default,
               sum(obtenido) e, sum(posible) p from it group by 1,2,3,4),
sec as (select sec_id, sec_name, sec_sort, sec_weight, sum(obtenido) e, sum(posible) p
        from it group by 1,2,3,4),
tot as (select sum(sec_weight * e / p) / nullif(sum(sec_weight), 0) as pct from sec where p > 0)
select jsonb_build_object(
  'total', round((select pct from tot) * 100, 2),
  'procesos', coalesce((select jsonb_agg(jsonb_build_object(
      'id', sec.sec_id, 'nombre', sec.sec_name, 'peso', sec.sec_weight,
      'obtenido', sec.e, 'posible', sec.p,
      'pct', case when sec.p > 0 then round(sec.e / sec.p * 100, 2) end,
      'subprocesos', (select jsonb_agg(jsonb_build_object(
           'id', sub.sub_id, 'nombre', sub.sub_name, 'general', sub.is_default,
           'obtenido', sub.e, 'posible', sub.p,
           'pct', case when sub.p > 0 then round(sub.e / sub.p * 100, 2) end) order by sub.sub_sort)
         from sub where sub.sec_id = sec.sec_id)
    ) order by sec.sec_sort) from sec), '[]'::jsonb),
  'puntos', coalesce((select jsonb_agg(jsonb_build_object(
      'item_id', item_id, 'obtenido', obtenido, 'posible', posible)) from it), '[]'::jsonb)
)
$$;

-- ---------- Candados (triggers) ----------
-- Auditoría: fuera de las funciones oficiales solo se editan los comentarios de cierre, y solo en curso.
create or replace function public.tg_audits_guard() returns trigger
language plpgsql set search_path = public as $$
begin
  if public.en_rpc() then return new; end if;
  if old.status <> 'en_curso' then
    raise exception 'La auditoría no está en curso; no se puede modificar.';
  end if;
  if (to_jsonb(new) - array['general_comments','strengths','opportunities','updated_at'])
     <> (to_jsonb(old) - array['general_comments','strengths','opportunities','updated_at']) then
    raise exception 'Solo se pueden editar comentarios, fortalezas y oportunidades.';
  end if;
  return new;
end $$;
create trigger audits_guard before update on public.audits
  for each row execute function public.tg_audits_guard();

create or replace function public.assert_auditoria_en_curso(p_audit_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from public.audits where id = p_audit_id and status = 'en_curso') then
    raise exception 'La auditoría no está en curso; no se puede modificar.';
  end if;
end $$;

-- Respuestas: solo con auditoría en curso; si fue reabierta, se registra cada cambio.
create or replace function public.tg_responses_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_audit uuid := coalesce(new.audit_id, old.audit_id); v_reab int;
begin
  perform public.assert_auditoria_en_curso(v_audit);
  select reopened_count into v_reab from public.audits where id = v_audit;
  if v_reab > 0 then
    insert into public.audit_change_log(audit_id, table_name, record_id, action, old_data, new_data)
    values (v_audit, 'audit_responses', coalesce(new.id, old.id)::text, lower(tg_op),
            case when tg_op <> 'INSERT' then to_jsonb(old) end,
            case when tg_op <> 'DELETE' then to_jsonb(new) end);
  end if;
  if tg_op = 'DELETE' then return old; end if;
  new.answered_by := coalesce(auth.uid(), new.answered_by);
  return new;
end $$;
create trigger responses_guard before insert or update or delete on public.audit_responses
  for each row execute function public.tg_responses_guard();

-- Evidencias: auditoría en curso + contexto completo automático (sucursal, líder, proceso, respuesta).
create or replace function public.tg_evidence_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  perform public.assert_auditoria_en_curso(coalesce(new.audit_id, old.audit_id));
  if tg_op = 'DELETE' then return old; end if;
  if new.storage_path not like new.audit_id::text || '/%' then
    raise exception 'La ruta de la foto debe iniciar con el id de la auditoría.';
  end if;
  select a.branch_id, a.leader_id into new.branch_id, new.leader_id
    from public.audits a where a.id = new.audit_id;
  select sb.section_id into new.section_id
    from public.audit_items i join public.audit_subsections sb on sb.id = i.subsection_id
   where i.id = new.item_id;
  if new.response_id is null then
    select id into new.response_id from public.audit_responses
     where audit_id = new.audit_id and item_id = new.item_id;
  end if;
  new.created_by := coalesce(auth.uid(), new.created_by);
  return new;
end $$;
create trigger evidence_guard before insert or update or delete on public.audit_evidence
  for each row execute function public.tg_evidence_guard();

-- Planes de acción: se crean/editan con la auditoría en curso; después solo cambia el estatus (vía RPC).
create or replace function public.tg_plans_guard() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_open boolean; v_reab int;
begin
  select status = 'en_curso', reopened_count into v_open, v_reab
    from public.audits where id = coalesce(new.audit_id, old.audit_id);

  if tg_op = 'INSERT' then
    if not v_open then raise exception 'La auditoría no está en curso; no se puede crear el plan.'; end if;
    select a.branch_id, a.audit_type_id into new.branch_id, new.audit_type_id
      from public.audits a where a.id = new.audit_id;
    if new.item_id is not null then
      select sb.section_id into new.section_id
        from public.audit_items i join public.audit_subsections sb on sb.id = i.subsection_id
       where i.id = new.item_id;
      if new.response_id is null then
        select id into new.response_id from public.audit_responses
         where audit_id = new.audit_id and item_id = new.item_id;
      end if;
    end if;
    new.created_by := coalesce(auth.uid(), new.created_by);
    new.status := 'pendiente';
    return new;
  end if;

  if tg_op = 'DELETE' then
    if not v_open then raise exception 'La auditoría está cerrada; el plan no se puede borrar.'; end if;
    return old;
  end if;

  -- UPDATE
  if (new.status, new.closed_at, new.closed_by) is distinct from (old.status, old.closed_at, old.closed_by)
     and not public.en_rpc() then
    raise exception 'El estatus se cambia desde "Actualizar estatus" para que quede en la bitácora.';
  end if;
  if not v_open and not public.en_rpc() then
    raise exception 'La auditoría está cerrada; solo se puede actualizar el estatus del plan.';
  end if;
  if v_open and v_reab > 0 then
    insert into public.audit_change_log(audit_id, table_name, record_id, action, old_data, new_data)
    values (new.audit_id, 'action_plans', new.id::text, 'update', to_jsonb(old), to_jsonb(new));
  end if;
  return new;
end $$;
create trigger plans_guard before insert or update or delete on public.action_plans
  for each row execute function public.tg_plans_guard();

-- Catálogo: solo se editan versiones en "borrador". Lo publicado queda intacto para el histórico.
create or replace function public.tg_catalogo_guard() returns trigger
language plpgsql set search_path = public as $$
declare v_version int; v_status public.template_status;
begin
  if tg_table_name = 'audit_sections' then
    v_version := coalesce(new.template_version_id, old.template_version_id);
  elsif tg_table_name = 'audit_subsections' then
    select template_version_id into v_version from public.audit_sections
     where id = coalesce(new.section_id, old.section_id);
  else
    select s.template_version_id into v_version
      from public.audit_subsections sb join public.audit_sections s on s.id = sb.section_id
     where sb.id = coalesce(new.subsection_id, old.subsection_id);
  end if;
  select status into v_status from public.template_versions where id = v_version;
  if v_status <> 'borrador' then
    raise exception 'Esta versión del catálogo ya está publicada. Crea una nueva versión para editarla.';
  end if;
  if tg_op = 'DELETE' then return old; end if;
  return new;
end $$;
create trigger sections_guard    before insert or update or delete on public.audit_sections
  for each row execute function public.tg_catalogo_guard();
create trigger subsections_guard before insert or update or delete on public.audit_subsections
  for each row execute function public.tg_catalogo_guard();
create trigger items_guard       before insert or update or delete on public.audit_items
  for each row execute function public.tg_catalogo_guard();

-- =====================================================================
-- Funciones oficiales (RPC) que llama la app
-- =====================================================================

-- Iniciar (o continuar) la auditoría de una sucursal en la semana actual.
create or replace function public.iniciar_auditoria(p_branch_id int)
returns public.audits language plpgsql security definer set search_path = public as $$
declare v_tipo int; v_rol text; v_version int; v_semana date := public.inicio_semana(); v_a audits;
begin
  v_rol := public.mi_rol();
  if v_rol is null or v_rol = 'socio' then
    raise exception 'Solo los líderes pueden iniciar auditorías.';
  end if;
  v_tipo := public.mi_tipo_auditoria();
  if not exists (select 1 from branches where id = p_branch_id and active) then
    raise exception 'Sucursal no válida.';
  end if;

  select * into v_a from audits
   where branch_id = p_branch_id and audit_type_id = v_tipo
     and week_start = v_semana and status <> 'cancelada';
  if found then
    if v_a.status = 'en_curso' and v_a.leader_id = auth.uid() then
      return v_a;                                   -- continuar la existente
    elsif v_a.status = 'en_curso' then
      raise exception 'Otro líder tiene esta auditoría en curso esta semana.';
    else
      raise exception 'Esta sucursal ya fue auditada esta semana.';
    end if;
  end if;

  select id into v_version from template_versions
   where audit_type_id = v_tipo and status = 'publicada';
  if v_version is null then
    raise exception 'No hay catálogo publicado para este tipo de auditoría.';
  end if;

  perform set_config('app.rpc', 'on', true);
  insert into audits(template_version_id, audit_type_id, branch_id, leader_id,
                     week_start, audit_date, started_at, last_heartbeat_at)
  values (v_version, v_tipo, p_branch_id, auth.uid(), v_semana, public.hoy(), now(), now())
  returning * into v_a;
  return v_a;
end $$;

-- Latido: la app lo llama cada minuto mientras la auditoría está abierta en pantalla.
-- Suma tiempo activo; si pasaron más de 5 min sin latido (app cerrada), ese hueco no se cuenta.
create or replace function public.latido_auditoria(p_audit_id uuid)
returns int language plpgsql security definer set search_path = public as $$
declare v_a audits; v_delta int;
begin
  select * into v_a from audits where id = p_audit_id for update;
  if v_a.leader_id is distinct from auth.uid() or v_a.status <> 'en_curso' then
    return null;
  end if;
  v_delta := coalesce(extract(epoch from now() - v_a.last_heartbeat_at)::int, 0);
  if v_delta > 300 then v_delta := 0; end if;
  perform set_config('app.rpc', 'on', true);
  update audits set active_seconds = active_seconds + v_delta, last_heartbeat_at = now()
   where id = p_audit_id;
  return v_a.active_seconds + v_delta;
end $$;

-- Cerrar: valida que todo esté respondido, calcula y congela calificaciones, guarda snapshot y bloquea.
create or replace function public.cerrar_auditoria(
  p_audit_id uuid, p_comentarios text default null,
  p_fortalezas text default null, p_oportunidades text default null)
returns public.audits language plpgsql security definer set search_path = public as $$
declare v_a audits; v_pend int; v_score jsonb; v_elapsed int; v_bajo boolean; v_ahora timestamptz := now();
begin
  select * into v_a from audits where id = p_audit_id for update;
  if not found then raise exception 'Auditoría no encontrada.'; end if;
  if v_a.leader_id <> auth.uid() then raise exception 'Solo el líder de esta auditoría puede cerrarla.'; end if;
  if v_a.status <> 'en_curso' then raise exception 'La auditoría no está en curso.'; end if;

  select count(*) into v_pend
    from audit_sections s
    join audit_subsections sb on sb.section_id = s.id
    join audit_items i on i.subsection_id = sb.id
    left join audit_responses r on r.audit_id = v_a.id and r.item_id = i.id
   where s.template_version_id = v_a.template_version_id
     and not coalesce(public.respuesta_completa(i.item_type, r.result, r.text_value, r.measurement_value), false);
  if v_pend > 0 then
    raise exception 'Faltan % puntos por responder.', v_pend;
  end if;

  -- Duración: en una reapertura se conserva la del primer cierre.
  if v_a.reopened_count > 0 and v_a.elapsed_seconds is not null then
    v_elapsed := v_a.elapsed_seconds; v_bajo := v_a.closed_under_target;
  else
    v_elapsed := extract(epoch from v_ahora - v_a.started_at)::int;
    v_bajo := coalesce(nullif(v_a.active_seconds, 0), v_elapsed)
              < public.config('advertencia_minutos', 180) * 60;
  end if;

  v_score := public.puntaje_auditoria(v_a.id);

  delete from audit_scores where audit_id = v_a.id;
  insert into audit_scores(audit_id, level, ref_id, earned, possible, pct)
  select v_a.id, 'punto', (p->>'item_id')::int, (p->>'obtenido')::numeric, (p->>'posible')::numeric,
         case when (p->>'posible')::numeric > 0
              then round((p->>'obtenido')::numeric / (p->>'posible')::numeric * 100, 2) end
    from jsonb_array_elements(v_score->'puntos') p;
  insert into audit_scores(audit_id, level, ref_id, earned, possible, pct)
  select v_a.id, 'proceso', (s->>'id')::int, (s->>'obtenido')::numeric, (s->>'posible')::numeric,
         (s->>'pct')::numeric
    from jsonb_array_elements(v_score->'procesos') s;
  insert into audit_scores(audit_id, level, ref_id, earned, possible, pct)
  select v_a.id, 'subproceso', (sb->>'id')::int, (sb->>'obtenido')::numeric, (sb->>'posible')::numeric,
         (sb->>'pct')::numeric
    from jsonb_array_elements(v_score->'procesos') s,
         jsonb_array_elements(s->'subprocesos') sb;
  insert into audit_scores(audit_id, level, earned, possible, pct)
  values (v_a.id, 'total', null, null, (v_score->>'total')::numeric);

  perform set_config('app.rpc', 'on', true);
  update audits set
    status = 'cerrada', finished_at = v_ahora, elapsed_seconds = v_elapsed,
    closed_under_target = v_bajo,
    general_comments = coalesce(p_comentarios, general_comments),
    strengths        = coalesce(p_fortalezas, strengths),
    opportunities    = coalesce(p_oportunidades, opportunities),
    score_total      = (v_score->>'total')::numeric
  where id = v_a.id returning * into v_a;

  update audits set snapshot = public.construir_snapshot(v_a.id, v_score)
   where id = v_a.id returning * into v_a;
  return v_a;
end $$;

-- Snapshot: foto completa del resultado al cierre (base del PDF y del histórico).
create or replace function public.construir_snapshot(p_audit_id uuid, p_score jsonb)
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'generado', now(),
    'encabezado', jsonb_build_object(
      'sucursal', b.name, 'tipo', t.name, 'tipo_codigo', t.code, 'lider', u.full_name,
      'fecha', a.audit_date, 'semana', a.week_start,
      'inicio', a.started_at, 'fin', a.finished_at,
      'duracion_seg', a.elapsed_seconds, 'tiempo_activo_seg', a.active_seconds,
      'bajo_objetivo', a.closed_under_target, 'version_catalogo', tv.version,
      'reaperturas', a.reopened_count),
    'calificacion', p_score - 'puntos',
    'cierre', jsonb_build_object('comentarios', a.general_comments,
                                 'fortalezas', a.strengths, 'oportunidades', a.opportunities),
    'respuestas', (
      select coalesce(jsonb_agg(jsonb_build_object(
        'item_id', i.id, 'codigo', i.code, 'punto', i.text, 'tipo', i.item_type, 'peso', i.weight,
        'unidad', i.unit, 'proceso', s.name, 'proceso_id', s.id, 'subproceso', sb.name,
        'resultado', r.result, 'prioridad', r.priority, 'comentario', r.comment,
        'medicion', r.measurement_value, 'dato', r.text_value)
        order by s.sort, sb.sort, i.sort), '[]'::jsonb)
      from audit_sections s
      join audit_subsections sb on sb.section_id = s.id
      join audit_items i on i.subsection_id = sb.id
      left join audit_responses r on r.audit_id = a.id and r.item_id = i.id
      where s.template_version_id = a.template_version_id),
    'planes', (
      select coalesce(jsonb_agg(jsonb_build_object(
        'id', p.id, 'item_id', p.item_id, 'hallazgo', p.finding, 'accion', p.corrective_action,
        'responsable', p.responsible, 'prioridad', p.priority, 'fecha_compromiso', p.due_date,
        'estatus', p.status) order by p.created_at), '[]'::jsonb)
      from action_plans p where p.audit_id = a.id),
    'evidencias', (
      select coalesce(jsonb_agg(jsonb_build_object(
        'id', e.id, 'item_id', e.item_id, 'plan_id', e.action_plan_id,
        'ruta', e.storage_path, 'miniatura', e.thumb_path, 'pie', e.caption)
        order by e.created_at), '[]'::jsonb)
      from audit_evidence e where e.audit_id = a.id)
  )
  from audits a
  join branches b on b.id = a.branch_id
  join audit_types t on t.id = a.audit_type_id
  join users u on u.id = a.leader_id
  join template_versions tv on tv.id = a.template_version_id
  where a.id = p_audit_id
$$;

-- Cancelar una auditoría en curso (iniciada por error). Cualquiera de los usuarios activos.
create or replace function public.cancelar_auditoria(p_audit_id uuid, p_motivo text default null)
returns public.audits language plpgsql security definer set search_path = public as $$
declare v_a audits;
begin
  if not public.es_usuario_activo() then raise exception 'No autorizado.'; end if;
  select * into v_a from audits where id = p_audit_id for update;
  if not found or v_a.status <> 'en_curso' then
    raise exception 'Solo se pueden cancelar auditorías en curso.';
  end if;
  perform set_config('app.rpc', 'on', true);
  update audits set status = 'cancelada', cancelled_at = now(), cancelled_by = auth.uid(),
                    cancel_reason = p_motivo
   where id = p_audit_id returning * into v_a;
  insert into audit_change_log(audit_id, table_name, record_id, action, reason)
  values (p_audit_id, 'audits', p_audit_id::text, 'cancelar', p_motivo);
  return v_a;
end $$;

-- Reabrir una auditoría cerrada. Solo socios, con motivo obligatorio.
create or replace function public.reabrir_auditoria(p_audit_id uuid, p_motivo text)
returns public.audits language plpgsql security definer set search_path = public as $$
declare v_a audits;
begin
  if not public.es_socio() then raise exception 'Solo los socios pueden reabrir auditorías.'; end if;
  if nullif(trim(p_motivo), '') is null then raise exception 'El motivo es obligatorio.'; end if;
  select * into v_a from audits where id = p_audit_id for update;
  if not found or v_a.status <> 'cerrada' then
    raise exception 'Solo se pueden reabrir auditorías cerradas.';
  end if;
  insert into audit_change_log(audit_id, table_name, record_id, action, old_data, reason)
  values (p_audit_id, 'audits', p_audit_id::text, 'reabrir',
          jsonb_build_object('score_total', v_a.score_total, 'finished_at', v_a.finished_at,
                             'snapshot', v_a.snapshot), p_motivo);
  perform set_config('app.rpc', 'on', true);
  update audits set status = 'en_curso', reopened_count = reopened_count + 1,
                    last_heartbeat_at = null
   where id = p_audit_id returning * into v_a;
  return v_a;
end $$;

-- Cambiar estatus de un plan de acción (solo quien lo creó). Queda en la bitácora.
create or replace function public.actualizar_estatus_plan(
  p_plan_id uuid, p_estatus public.action_status, p_comentario text default null)
returns public.action_plans language plpgsql security definer set search_path = public as $$
declare v_p action_plans;
begin
  select * into v_p from action_plans where id = p_plan_id for update;
  if not found then raise exception 'Plan no encontrado.'; end if;
  if v_p.created_by <> auth.uid() then
    raise exception 'Solo el líder que creó el plan puede actualizar su estatus.';
  end if;
  if v_p.status = p_estatus and nullif(trim(p_comentario), '') is null then
    raise exception 'El plan ya tiene ese estatus; agrega un comentario si quieres registrar avance.';
  end if;
  insert into action_plan_updates(action_plan_id, from_status, to_status, comment, created_by)
  values (p_plan_id, v_p.status, p_estatus, p_comentario, auth.uid());
  perform set_config('app.rpc', 'on', true);
  update action_plans set status = p_estatus,
         closed_at = case when p_estatus = 'corregido' then now() end,
         closed_by = case when p_estatus = 'corregido' then auth.uid() end
   where id = p_plan_id returning * into v_p;
  return v_p;
end $$;

-- Catálogo: crear un borrador copiando la versión publicada (para editar puntos o pesos).
create or replace function public.crear_borrador_catalogo(p_audit_type_id int)
returns int language plpgsql security definer set search_path = public as $$
declare v_src int; v_new int; r_s record; r_sb record; v_s int; v_sb int;
begin
  if not public.es_socio() then raise exception 'Solo los socios pueden editar el catálogo.'; end if;
  if exists (select 1 from template_versions where audit_type_id = p_audit_type_id and status = 'borrador') then
    raise exception 'Ya existe un borrador para este tipo; edítalo o publícalo.';
  end if;
  select id into v_src from template_versions where audit_type_id = p_audit_type_id and status = 'publicada';
  insert into template_versions(audit_type_id, version, status)
  values (p_audit_type_id,
          (select coalesce(max(version), 0) + 1 from template_versions where audit_type_id = p_audit_type_id),
          'borrador')
  returning id into v_new;
  for r_s in select * from audit_sections where template_version_id = v_src loop
    insert into audit_sections(template_version_id, code, name, sort, weight)
    values (v_new, r_s.code, r_s.name, r_s.sort, r_s.weight) returning id into v_s;
    for r_sb in select * from audit_subsections where section_id = r_s.id loop
      insert into audit_subsections(section_id, name, sort, is_default)
      values (v_s, r_sb.name, r_sb.sort, r_sb.is_default) returning id into v_sb;
      insert into audit_items(subsection_id, code, text, original_text, guidance, sort,
                              item_type, weight, unit, allow_na)
      select v_sb, code, text, original_text, guidance, sort, item_type, weight, unit, allow_na
        from audit_items where subsection_id = r_sb.id;
    end loop;
  end loop;
  return v_new;
end $$;

-- Catálogo: publicar un borrador (la versión anterior pasa a "retirada"; sus auditorías no cambian).
create or replace function public.publicar_catalogo(p_version_id int)
returns void language plpgsql security definer set search_path = public as $$
declare v_tipo int;
begin
  if not public.es_socio() then raise exception 'Solo los socios pueden publicar el catálogo.'; end if;
  select audit_type_id into v_tipo from template_versions where id = p_version_id and status = 'borrador';
  if v_tipo is null then raise exception 'Solo se pueden publicar borradores.'; end if;
  update template_versions set status = 'retirada' where audit_type_id = v_tipo and status = 'publicada';
  update template_versions set status = 'publicada', published_at = now() where id = p_version_id;
end $$;

-- ---------- Permisos de ejecución ----------
revoke execute on all functions in schema public from public, anon;
grant  execute on all functions in schema public to authenticated;

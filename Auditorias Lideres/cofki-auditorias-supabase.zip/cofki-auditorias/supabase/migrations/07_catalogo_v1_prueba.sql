-- =====================================================================
-- Cofki Auditorías · 07 · Catálogo v1 (PRUEBA)
-- Generado desde Catalogo_Auditorias_Cofki.xlsx (propuesta aún en revisión).
-- Sirve para probar la app. Antes de salir a producción se reemplaza por la versión aprobada.
-- =====================================================================

do $$
declare v int; s int; sb int;
begin
  insert into public.template_versions(audit_type_id, version, status, notes)
  values ((select id from public.audit_types where code = 'AB'), 1, 'borrador', 'v1 de prueba — pendiente de aprobación')
  returning id into v;

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'AB-01', 'Personal A&B', 1, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Higiene y presentación', 1, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-001', 'Uniforme completo, limpio y en buen estado', 'Uniforme completo y limpio', 1, 'evaluable', 2, null),
    (sb, 'AB-002', 'Cofia colocada y cabello completamente cubierto', 'Cofia y cabello correctamente cubiertos', 2, 'evaluable', 3, null),
    (sb, 'AB-003', 'Manos, uñas y barba en condiciones adecuadas (cortas, limpias, sin joyería)', 'Manos, uñas y barba en condiciones adecuadas', 3, 'evaluable', 3, null),
    (sb, 'AB-004', 'Hábitos de higiene correctos durante la operación', 'Hábitos correctos de higiene', 4, 'evaluable', 3, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Conducta y disciplina', 2, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-005', 'Trato respetuoso entre el equipo', 'Trato respetuoso', 5, 'evaluable', 1, null),
    (sb, 'AB-006', 'Comportamiento profesional en la estación', 'Comportamiento profesional', 6, 'evaluable', 1, null),
    (sb, 'AB-007', 'Instrucciones del líder/gerente se cumplen', 'Cumplimiento de instrucciones', 7, 'evaluable', 2, null),
    (sb, 'AB-008', 'Celular usado solo conforme a la política', 'Uso correcto del celular', 8, 'evaluable', 1, null),
    (sb, 'AB-009', 'Personal llega y opera en su horario asignado', 'Puntualidad y horarios', 9, 'evaluable', 2, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Organización y productividad', 3, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-010', 'Estaciones asignadas correctamente', 'Estaciones correctamente asignadas', 10, 'evaluable', 1, null),
    (sb, 'AB-011', 'Cada colaborador conoce sus funciones', 'Funciones claras', 11, 'evaluable', 1, null),
    (sb, 'AB-012', 'Personal suficiente para la operación del turno', 'Personal suficiente', 12, 'evaluable', 2, null),
    (sb, 'AB-013', 'Flujo de trabajo ordenado', 'Flujo de trabajo ordenado', 13, 'evaluable', 1, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'AB-02', 'Inocuidad y seguridad alimentaria', 2, 3) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Manipulación', 1, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-014', 'Lavado de manos correcto y en los momentos requeridos', 'Lavado correcto de manos', 14, 'evaluable', 3, null),
    (sb, 'AB-015', 'Se previene la contaminación cruzada', 'Prevención de contaminación cruzada', 15, 'evaluable', 3, null),
    (sb, 'AB-016', 'Crudos y cocidos almacenados y manipulados por separado', 'Separación de crudos y cocidos', 16, 'evaluable', 3, null),
    (sb, 'AB-017', 'Utensilios y superficies usados correctamente (tablas/colores por tipo)', 'Uso correcto de utensilios y superficies', 17, 'evaluable', 3, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Control de alimentos', 2, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-018', 'Productos etiquetados', 'Etiquetado', 18, 'evaluable', 3, null),
    (sb, 'AB-019', 'Etiquetas con fecha de producción', 'Fecha de producción', 19, 'evaluable', 2, null),
    (sb, 'AB-020', 'Etiquetas con fecha de caducidad', 'Fecha de caducidad', 20, 'evaluable', 3, null),
    (sb, 'AB-021', 'Productos en buen estado', 'Producto en buen estado', 21, 'evaluable', 3, null),
    (sb, 'AB-022', 'Sin productos sin identificación ni vencidos', 'Productos sin identificación o vencidos', 22, 'evaluable', 3, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Almacenamiento', 3, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-023', 'Alimentos protegidos/tapados', 'Alimentos protegidos', 23, 'evaluable', 3, null),
    (sb, 'AB-024', 'Ningún producto en el piso', 'Productos fuera del piso', 24, 'evaluable', 2, null),
    (sb, 'AB-025', 'Químicos separados de alimentos', 'Químicos separados', 25, 'evaluable', 3, null),
    (sb, 'AB-026', 'Contenedores adecuados y cerrados', 'Contenedores adecuados y cerrados', 26, 'evaluable', 2, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Temperaturas', 4, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-027', 'Temperatura de refrigeradores dentro del estándar', 'Refrigeradores dentro del estándar', 27, 'medicion', 3, '°C · estándar por confirmar (ej. 0–4 °C)'),
    (sb, 'AB-028', 'Temperatura de congeladores dentro del estándar', 'Congeladores dentro del estándar', 28, 'medicion', 3, '°C · estándar por confirmar (ej. ≤ -18 °C)'),
    (sb, 'AB-029', 'Productos preparados conservados a la temperatura correcta', 'Productos preparados correctamente conservados', 29, 'evaluable', 3, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'AB-03', 'Refrigeración y almacén', 3, 2) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Refrigeración', 1, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-030', 'Refrigeración: temperatura correcta en todos los equipos', 'Temperatura', 30, 'evaluable', 3, null),
    (sb, 'AB-031', 'Refrigeración: equipos limpios', 'Limpieza', 31, 'evaluable', 2, null),
    (sb, 'AB-032', 'Refrigeración: empaques en buen estado', 'Empaques', 32, 'evaluable', 1, null),
    (sb, 'AB-033', 'Refrigeración: puertas cierran correctamente', 'Puertas', 33, 'evaluable', 2, null),
    (sb, 'AB-034', 'Refrigeración: iluminación interior funcionando', 'Iluminación', 34, 'evaluable', 1, null),
    (sb, 'AB-035', 'Refrigeración: equipos funcionando correctamente', 'Funcionamiento', 35, 'evaluable', 3, null),
    (sb, 'AB-036', 'Refrigeración: acomodo correcto (por tipo, crudos abajo)', 'Acomodo', 36, 'evaluable', 2, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Rotación', 2, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-037', 'Rotación PEP (primeras entradas, primeras salidas) cumplida', 'Cumplimiento de PEP', 37, 'evaluable', 2, null),
    (sb, 'AB-038', 'Caducidades vigentes en refrigeración y almacén', 'Caducidades', 38, 'evaluable', 3, null),
    (sb, 'AB-039', 'Productos próximos a caducar identificados y con plan de uso', 'Productos próximos a caducar', 39, 'evaluable', 2, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Almacén', 3, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-040', 'Almacén ordenado', 'Orden', 40, 'evaluable', 1, null),
    (sb, 'AB-041', 'Almacén limpio', 'Limpieza', 41, 'evaluable', 2, null),
    (sb, 'AB-042', 'Almacén con acomodo correcto', 'Acomodo', 42, 'evaluable', 1, null),
    (sb, 'AB-043', 'Productos sin movimiento identificados', 'Productos sin movimiento', 43, 'evaluable', 1, null),
    (sb, 'AB-044', 'Sin faltantes de insumos en almacén', 'Faltantes', 44, 'evaluable', 2, null),
    (sb, 'AB-045', 'Sin sobreinventarios en almacén', 'Sobreinventarios', 45, 'evaluable', 1, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'AB-04', 'Cocina: equipos, utensilios e instalaciones', 4, 2) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Equipos', 1, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-046', 'Equipos de cocina funcionando', 'Funcionamiento', 46, 'evaluable', 2, null),
    (sb, 'AB-047', 'Equipos de cocina limpios', 'Limpieza', 47, 'evaluable', 2, null),
    (sb, 'AB-048', 'Equipos de cocina en buena condición física', 'Condición física', 48, 'evaluable', 1, null),
    (sb, 'AB-049', 'Equipos de cocina operan de forma segura', 'Seguridad', 49, 'evaluable', 3, null),
    (sb, 'AB-050', 'Mantenimiento preventivo de equipos al día', 'Mantenimiento preventivo', 50, 'evaluable', 2, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Utensilios', 2, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-051', 'Utensilios en buena condición', 'Condición', 51, 'evaluable', 1, null),
    (sb, 'AB-052', 'Utensilios limpios', 'Limpieza', 52, 'evaluable', 2, null),
    (sb, 'AB-053', 'Cantidad suficiente de utensilios', 'Cantidad suficiente', 53, 'evaluable', 1, null),
    (sb, 'AB-054', 'Utensilios acomodados correctamente', 'Acomodo', 54, 'evaluable', 1, null),
    (sb, 'AB-055', 'Sin utensilios faltantes o dañados', 'Faltantes o dañados', 55, 'evaluable', 1, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Instalaciones y mantenimiento', 3, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-056', 'Sin fugas de agua', 'Fugas de agua', 56, 'evaluable', 2, null),
    (sb, 'AB-057', 'Sin fugas de gas', 'Fugas de gas', 57, 'evaluable', 3, null),
    (sb, 'AB-058', 'Contactos y cables en condiciones seguras', 'Contactos y cables', 58, 'evaluable', 3, null),
    (sb, 'AB-059', 'Iluminación de cocina funcionando', 'Iluminación', 59, 'evaluable', 1, null),
    (sb, 'AB-060', 'Drenajes funcionando y limpios', 'Drenajes', 60, 'evaluable', 2, null),
    (sb, 'AB-061', 'Extracción funcionando', 'Extracción', 61, 'evaluable', 2, null),
    (sb, 'AB-062', 'Campana limpia y funcionando', 'Campana', 62, 'evaluable', 2, null),
    (sb, 'AB-063', 'Problemas reportados en auditorías previas atendidos', 'Seguimiento de problemas previamente reportados', 63, 'evaluable', 2, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'AB-05', 'Producción de cocina', 5, 2) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Producción', 1, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-064', 'Producciones completas para el turno', 'Producciones completas', 64, 'evaluable', 2, null),
    (sb, 'AB-065', 'Cantidad producida acorde a la necesidad', 'Cantidad acorde a necesidad', 65, 'evaluable', 1, null),
    (sb, 'AB-066', 'Producción sin atrasos', 'Atrasos', 66, 'evaluable', 1, null),
    (sb, 'AB-067', 'Sin faltantes de producción', 'Faltantes', 67, 'evaluable', 2, null),
    (sb, 'AB-068', 'Sin sobreproducción', 'Sobreproducción', 68, 'evaluable', 1, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Recetas y estandarización', 2, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-069', 'Se usa la receta oficial', 'Receta oficial', 69, 'evaluable', 2, null),
    (sb, 'AB-070', 'Ingredientes conforme a receta', 'Ingredientes', 70, 'evaluable', 2, null),
    (sb, 'AB-071', 'Gramajes conforme a receta', 'Gramajes', 71, 'evaluable', 2, null),
    (sb, 'AB-072', 'Cantidades conforme a receta', 'Cantidades', 72, 'evaluable', 2, null),
    (sb, 'AB-073', 'Método de preparación conforme a receta', 'Método', 73, 'evaluable', 2, null),
    (sb, 'AB-074', 'Tiempos de preparación conforme a receta', 'Tiempos', 74, 'evaluable', 1, null),
    (sb, 'AB-075', 'Temperaturas de cocción/conservación conforme a receta', 'Temperaturas', 75, 'evaluable', 3, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Rendimientos', 3, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-076', 'Rendimiento estándar del producto revisado', 'Rendimiento estándar', 76, 'dato', 0, '% o unidades'),
    (sb, 'AB-077', 'Rendimiento real obtenido', 'Rendimiento real', 77, 'dato', 0, '% o unidades'),
    (sb, 'AB-078', 'Desviación de rendimiento dentro de tolerancia', 'Desviación', 78, 'evaluable', 2, null),
    (sb, 'AB-079', 'Causa de la desviación', 'Causa', 79, 'dato', 0, 'texto'),
    (sb, 'AB-080', 'Acción correctiva de la desviación', 'Acción correctiva', 80, 'dato', 0, 'texto');
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Registros', 4, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-081', 'Registro diario de producción completo', 'Registro diario', 81, 'evaluable', 2, null),
    (sb, 'AB-082', 'Producción etiquetada', 'Etiquetado', 82, 'evaluable', 2, null),
    (sb, 'AB-083', 'Producción registrada consistente con Parrot', 'Consistencia con Parrot', 83, 'evaluable', 2, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'AB-06', 'Calidad de alimentos', 6, 2) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-084', 'Sabor conforme a estándar', 'Sabor', 84, 'evaluable', 2, null),
    (sb, 'AB-085', 'Textura conforme a estándar', 'Textura', 85, 'evaluable', 2, null),
    (sb, 'AB-086', 'Color/cocción conforme a estándar', 'Color/cocción', 86, 'evaluable', 2, null),
    (sb, 'AB-087', 'Temperatura de servicio correcta', 'Temperatura', 87, 'medicion', 2, '°C · estándar por platillo por confirmar'),
    (sb, 'AB-088', 'Insumos utilizados en buen estado', 'Estado de insumos', 88, 'evaluable', 3, null),
    (sb, 'AB-089', 'Montaje conforme a estándar', 'Montaje', 89, 'evaluable', 1, null),
    (sb, 'AB-090', 'Porción conforme a estándar', 'Porción', 90, 'evaluable', 2, null),
    (sb, 'AB-091', 'Gramaje conforme a estándar', 'Gramaje', 91, 'evaluable', 2, null),
    (sb, 'AB-092', 'Ingredientes conforme a estándar', 'Ingredientes', 92, 'evaluable', 2, null),
    (sb, 'AB-093', 'Aderezos conforme a estándar', 'Aderezos', 93, 'evaluable', 1, null),
    (sb, 'AB-094', 'Salsas conforme a estándar', 'Salsas', 94, 'evaluable', 1, null),
    (sb, 'AB-095', 'Complementos conforme a estándar', 'Complementos', 95, 'evaluable', 1, null),
    (sb, 'AB-096', 'Prueba aleatoria de platillo contra estándar Cofki aprobada', 'Pruebas aleatorias contra estándar Cofki', 96, 'evaluable', 2, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'AB-07', 'Barra', 7, 2) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Mise en place', 1, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-097', 'Estación de barra completa', 'Estación completa', 97, 'evaluable', 2, null),
    (sb, 'AB-098', 'Insumos suficientes en barra', 'Insumos suficientes', 98, 'evaluable', 2, null),
    (sb, 'AB-099', 'Frutas en buen estado y suficientes', 'Frutas', 99, 'evaluable', 2, null),
    (sb, 'AB-100', 'Leches en buen estado, vigentes y suficientes', 'Leches', 100, 'evaluable', 3, null),
    (sb, 'AB-101', 'Jarabes suficientes y vigentes', 'Jarabes', 101, 'evaluable', 1, null),
    (sb, 'AB-102', 'Toppings suficientes y vigentes', 'Toppings', 102, 'evaluable', 1, null),
    (sb, 'AB-103', 'Complementos de barra suficientes', 'Complementos', 103, 'evaluable', 1, null),
    (sb, 'AB-104', 'Insumos de barra etiquetados', 'Etiquetado', 104, 'evaluable', 2, null),
    (sb, 'AB-105', 'Rotación PEP en barra cumplida', 'PEP', 105, 'evaluable', 2, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Recetas', 2, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-106', 'Dosificación conforme a receta', 'Dosificación', 106, 'evaluable', 2, null),
    (sb, 'AB-107', 'Gramajes de barra conforme a receta', 'Gramajes', 107, 'evaluable', 2, null),
    (sb, 'AB-108', 'Medidas conforme a receta', 'Medidas', 108, 'evaluable', 2, null),
    (sb, 'AB-109', 'Se usa la receta oficial de barra', 'Receta oficial', 109, 'evaluable', 2, null),
    (sb, 'AB-110', 'Tiempos de preparación de barra conforme a receta', 'Tiempos', 110, 'evaluable', 1, null),
    (sb, 'AB-111', 'Método de preparación de barra conforme a receta', 'Método', 111, 'evaluable', 2, null),
    (sb, 'AB-112', 'Preparación consistente entre baristas', 'Consistencia entre baristas', 112, 'evaluable', 2, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Calidad', 3, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-113', 'Sabor de bebidas conforme a estándar', 'Sabor', 113, 'evaluable', 2, null),
    (sb, 'AB-114', 'Temperatura de bebidas conforme a estándar', 'Temperatura', 114, 'medicion', 2, '°C · estándar por bebida por confirmar'),
    (sb, 'AB-115', 'Textura de bebidas conforme a estándar', 'Textura', 115, 'evaluable', 1, null),
    (sb, 'AB-116', 'Presentación de bebidas conforme a estándar', 'Presentación', 116, 'evaluable', 1, null),
    (sb, 'AB-117', 'Porción de bebidas conforme a estándar', 'Porción', 117, 'evaluable', 2, null),
    (sb, 'AB-118', 'Bebidas consistentes entre preparaciones', 'Consistencia', 118, 'evaluable', 1, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Velocidad', 4, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-119', 'Tiempo de preparación de bebidas dentro del estándar', 'Tiempo de preparación', 119, 'medicion', 2, 'minutos · estándar por confirmar'),
    (sb, 'AB-120', 'Sin pedidos atrasados en barra', 'Pedidos atrasados', 120, 'evaluable', 1, null),
    (sb, 'AB-121', 'Sin remakes en barra durante la observación', 'Remakes', 121, 'evaluable', 1, null),
    (sb, 'AB-122', 'Barra coordinada con cocina y servicio', 'Coordinación con cocina y servicio', 122, 'evaluable', 1, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'AB-08', 'Equipos y mantenimiento de barra', 8, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-123', 'Cafetera funcionando y en buen estado', 'Cafetera', 123, 'evaluable', 3, null),
    (sb, 'AB-124', 'Molino funcionando y calibrado', 'Molino', 124, 'evaluable', 2, null),
    (sb, 'AB-125', 'Licuadoras funcionando y en buen estado', 'Licuadoras', 125, 'evaluable', 2, null),
    (sb, 'AB-126', 'Refrigeradores de barra funcionando', 'Refrigeradores', 126, 'evaluable', 3, null),
    (sb, 'AB-127', 'Máquina de hielo funcionando y limpia', 'Máquina de hielo', 127, 'evaluable', 3, null),
    (sb, 'AB-128', 'Equipos de agua/filtración funcionando y con filtros vigentes', 'Equipos de agua/filtración', 128, 'evaluable', 3, null),
    (sb, 'AB-129', 'Equipos de barra limpios', 'Limpieza', 129, 'evaluable', 2, null),
    (sb, 'AB-130', 'Mantenimiento preventivo de barra al día', 'Mantenimiento preventivo', 130, 'evaluable', 2, null),
    (sb, 'AB-131', 'Descalcificación realizada según programa', 'Descalcificación', 131, 'evaluable', 2, null),
    (sb, 'AB-132', 'Contactos de barra en condiciones seguras', 'Contactos', 132, 'evaluable', 3, null),
    (sb, 'AB-133', 'Cables de barra en condiciones seguras', 'Cables', 133, 'evaluable', 3, null),
    (sb, 'AB-134', 'Sin fugas en barra', 'Fugas', 134, 'evaluable', 2, null),
    (sb, 'AB-135', 'Sin fallas recurrentes en equipos de barra', 'Fallas recurrentes', 135, 'evaluable', 2, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'AB-09', 'Inventarios A&B', 9, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-136', 'Inventario físico de cocina realizado', 'Inventario físico cocina', 136, 'evaluable', 2, null),
    (sb, 'AB-137', 'Inventario físico de barra realizado', 'Inventario físico barra', 137, 'evaluable', 2, null),
    (sb, 'AB-138', 'Inventario físico cuadra contra Parrot', 'Comparación contra Parrot', 138, 'evaluable', 3, null),
    (sb, 'AB-139', 'Sin faltantes relevantes contra Parrot', 'Faltantes', 139, 'evaluable', 2, null),
    (sb, 'AB-140', 'Sin sobreinventarios relevantes', 'Sobreinventarios', 140, 'evaluable', 1, null),
    (sb, 'AB-141', 'Productos críticos con existencia suficiente', 'Productos críticos', 141, 'evaluable', 3, null),
    (sb, 'AB-142', 'Café: existencia correcta', 'Café', 142, 'evaluable', 2, null),
    (sb, 'AB-143', 'Leches: existencia correcta', 'Leches', 143, 'evaluable', 2, null),
    (sb, 'AB-144', 'Frutas: existencia correcta', 'Frutas', 144, 'evaluable', 1, null),
    (sb, 'AB-145', 'Jarabes: existencia correcta', 'Jarabes', 145, 'evaluable', 1, null),
    (sb, 'AB-146', 'Toppings: existencia correcta', 'Toppings', 146, 'evaluable', 1, null),
    (sb, 'AB-147', 'Bebidas: existencia correcta', 'Bebidas', 147, 'evaluable', 1, null),
    (sb, 'AB-148', 'Desechables: existencia correcta', 'Desechables', 148, 'evaluable', 1, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'AB-10', 'Mermas y rendimientos', 10, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-149', 'Mermas registradas correctamente', 'Mermas registradas', 149, 'evaluable', 2, null),
    (sb, 'AB-150', 'Sin mermas no registradas', 'Mermas no registradas', 150, 'evaluable', 3, null),
    (sb, 'AB-151', 'Principales causas de merma', 'Principales causas', 151, 'dato', 0, 'texto'),
    (sb, 'AB-152', 'Merma por caducidad bajo control', 'Caducidad', 152, 'evaluable', 2, null),
    (sb, 'AB-153', 'Merma por sobreproducción bajo control', 'Sobreproducción', 153, 'evaluable', 1, null),
    (sb, 'AB-154', 'Merma por mala preparación bajo control', 'Mala preparación', 154, 'evaluable', 1, null),
    (sb, 'AB-155', 'Merma por producto dañado bajo control', 'Producto dañado', 155, 'evaluable', 1, null),
    (sb, 'AB-156', 'Remakes/errores bajo control', 'Remakes / errores', 156, 'evaluable', 1, null),
    (sb, 'AB-157', 'Consumo real consistente con ventas', 'Consumo real vs ventas', 157, 'evaluable', 3, null),
    (sb, 'AB-158', 'Uso de insumos conforme a receta', 'Uso conforme a receta', 158, 'evaluable', 2, null),
    (sb, 'AB-159', 'Desviaciones de consumo dentro de tolerancia', 'Desviaciones', 159, 'evaluable', 2, null),
    (sb, 'AB-160', 'Productos con merma elevada', 'Productos con merma elevada', 160, 'dato', 0, 'texto (lista de productos)');

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'AB-11', 'Parrot y controles', 11, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-161', 'Inventarios registrados en Parrot', 'Inventarios registrados', 161, 'evaluable', 3, null),
    (sb, 'AB-162', 'Producciones registradas en Parrot', 'Producciones registradas', 162, 'evaluable', 2, null),
    (sb, 'AB-163', 'Mermas registradas en Parrot', 'Mermas registradas', 163, 'evaluable', 2, null),
    (sb, 'AB-164', 'Sin movimientos pendientes en Parrot', 'Movimientos pendientes', 164, 'evaluable', 2, null),
    (sb, 'AB-165', 'Operación física consistente con el sistema', 'Consistencia entre operación física y sistema', 165, 'evaluable', 3, null),
    (sb, 'AB-166', 'Diferencias físico vs sistema identificadas', 'Diferencias', 166, 'dato', 0, 'texto / monto'),
    (sb, 'AB-167', 'Causas de las diferencias', 'Causas', 167, 'dato', 0, 'texto'),
    (sb, 'AB-168', 'Diferencias corregidas en el sistema', 'Corrección', 168, 'evaluable', 2, null),
    (sb, 'AB-169', 'Diferencias anteriores con seguimiento', 'Seguimiento', 169, 'evaluable', 2, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'AB-12', 'Limpieza y sanitización', 12, 2) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Cocina', 1, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-170', 'Mesas de cocina limpias y sanitizadas', 'Mesas', 170, 'evaluable', 3, null),
    (sb, 'AB-171', 'Paredes de cocina limpias', 'Paredes', 171, 'evaluable', 1, null),
    (sb, 'AB-172', 'Pisos de cocina limpios', 'Pisos', 172, 'evaluable', 2, null),
    (sb, 'AB-173', 'Repisas limpias', 'Repisas', 173, 'evaluable', 1, null),
    (sb, 'AB-174', 'Debajo/detrás de equipos limpio', 'Debajo/detrás de equipos', 174, 'evaluable', 2, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Equipos', 2, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-175', 'Equipos limpios por dentro y por fuera', 'Limpieza interior/exterior', 175, 'evaluable', 2, null),
    (sb, 'AB-176', 'Equipos de cocción limpios', 'Cocción', 176, 'evaluable', 2, null),
    (sb, 'AB-177', 'Equipos de refrigeración limpios', 'Refrigeración', 177, 'evaluable', 2, null),
    (sb, 'AB-178', 'Equipos de producción limpios', 'Producción', 178, 'evaluable', 2, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Barra', 3, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-179', 'Superficies de barra limpias y sanitizadas', 'Superficies', 179, 'evaluable', 3, null),
    (sb, 'AB-180', 'Equipos de barra limpios', 'Equipos', 180, 'evaluable', 2, null),
    (sb, 'AB-181', 'Tarjas de barra limpias', 'Tarjas', 181, 'evaluable', 2, null),
    (sb, 'AB-182', 'Refrigeración de barra limpia', 'Refrigeración', 182, 'evaluable', 2, null),
    (sb, 'AB-183', 'Área de preparación de barra limpia', 'Área de preparación', 183, 'evaluable', 2, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Lavado', 4, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-184', 'Tarjas de lavado limpias', 'Tarjas', 184, 'evaluable', 2, null),
    (sb, 'AB-185', 'Drenajes de lavado limpios y funcionando', 'Drenajes', 185, 'evaluable', 2, null),
    (sb, 'AB-186', 'Jabón disponible', 'Jabón', 186, 'evaluable', 3, null),
    (sb, 'AB-187', 'Sanitizante disponible y en concentración correcta', 'Sanitizante', 187, 'evaluable', 3, null),
    (sb, 'AB-188', 'Trapos/esponjas limpios y en buen estado', 'Trapos/esponjas', 188, 'evaluable', 2, null),
    (sb, 'AB-189', 'Procedimiento de lavado correcto', 'Procedimientos', 189, 'evaluable', 2, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'AB-13', 'Servicio y flujo A&B', 13, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-190', 'Comandas correctas', 'Comanda correcta', 190, 'evaluable', 2, null),
    (sb, 'AB-191', 'Cocina recibe la información correcta', 'Cocina recibe información correcta', 191, 'evaluable', 2, null),
    (sb, 'AB-192', 'Barra recibe la información correcta', 'Barra recibe información correcta', 192, 'evaluable', 2, null),
    (sb, 'AB-193', 'Modificaciones comunicadas correctamente', 'Modificaciones comunicadas', 193, 'evaluable', 2, null),
    (sb, 'AB-194', 'Salida de alimentos y bebidas coordinada', 'Alimentos y bebidas coordinados', 194, 'evaluable', 1, null),
    (sb, 'AB-195', 'Sin pedidos atrasados', 'Pedidos atrasados', 195, 'evaluable', 1, null),
    (sb, 'AB-196', 'Sin pedidos incorrectos', 'Pedidos incorrectos', 196, 'evaluable', 2, null),
    (sb, 'AB-197', 'Sin remakes durante la observación', 'Remakes', 197, 'evaluable', 1, null),
    (sb, 'AB-198', 'Sin devoluciones durante la observación', 'Devoluciones', 198, 'evaluable', 1, null),
    (sb, 'AB-199', 'Coordinación correcta con meseros y nannies', 'Coordinación con meseros y nannies', 199, 'evaluable', 1, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'AB-14', 'Procesos y estandarización', 14, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-200', 'Recepción de materia prima conforme a estándar', 'Recepción de materia prima', 200, 'evaluable', 2, null),
    (sb, 'AB-201', 'Almacenamiento conforme a estándar', 'Almacenamiento', 201, 'evaluable', 2, null),
    (sb, 'AB-202', 'Producción conforme a estándar', 'Producción', 202, 'evaluable', 2, null),
    (sb, 'AB-203', 'Conservación conforme a estándar', 'Conservación', 203, 'evaluable', 2, null),
    (sb, 'AB-204', 'Preparación conforme a estándar', 'Preparación', 204, 'evaluable', 2, null),
    (sb, 'AB-205', 'Montaje conforme a estándar', 'Montaje', 205, 'evaluable', 1, null),
    (sb, 'AB-206', 'Entrega conforme a estándar', 'Entrega', 206, 'evaluable', 1, null),
    (sb, 'AB-207', 'Limpieza durante la operación conforme a estándar', 'Limpieza durante operación', 207, 'evaluable', 2, null),
    (sb, 'AB-208', 'Cierre conforme a estándar', 'Cierre', 208, 'evaluable', 2, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'AB-15', 'Capacitación', 15, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'AB-209', 'Personal conoce las recetas', 'Conocimiento de recetas', 209, 'evaluable', 2, null),
    (sb, 'AB-210', 'Personal conoce los estándares', 'Estándares', 210, 'evaluable', 2, null),
    (sb, 'AB-211', 'Personal conoce las prácticas de inocuidad', 'Inocuidad', 211, 'evaluable', 3, null),
    (sb, 'AB-212', 'Personal maneja correctamente los equipos', 'Manejo de equipos', 212, 'evaluable', 2, null),
    (sb, 'AB-213', 'Personal nuevo capacitado', 'Personal nuevo', 213, 'evaluable', 2, null),
    (sb, 'AB-214', 'Necesidades de capacitación detectadas', 'Necesidades de capacitación', 214, 'dato', 0, 'texto'),
    (sb, 'AB-215', 'Sin errores recurrentes del personal', 'Errores recurrentes', 215, 'evaluable', 2, null);

  update public.template_versions set status = 'publicada', published_at = now() where id = v;
end $$;

do $$
declare v int; s int; sb int;
begin
  insert into public.template_versions(audit_type_id, version, status, notes)
  values ((select id from public.audit_types where code = 'FRONT'), 1, 'borrador', 'v1 de prueba — pendiente de aprobación')
  returning id into v;

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'FR-01', 'Personal Front', 1, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-001', 'Presentación personal adecuada', 'Presentación', 1, 'evaluable', 1, null),
    (sb, 'FR-002', 'Higiene personal adecuada', 'Higiene', 2, 'evaluable', 2, null),
    (sb, 'FR-003', 'Uniforme completo, limpio y en buen estado', 'Uniforme', 3, 'evaluable', 2, null),
    (sb, 'FR-004', 'Actitud positiva y de servicio', 'Actitud', 4, 'evaluable', 2, null),
    (sb, 'FR-005', 'Trato amable al cliente y al equipo', 'Trato', 5, 'evaluable', 2, null),
    (sb, 'FR-006', 'Celular usado solo conforme a la política', 'Uso de celular', 6, 'evaluable', 1, null),
    (sb, 'FR-007', 'Personal llega y opera en su horario asignado', 'Puntualidad', 7, 'evaluable', 2, null),
    (sb, 'FR-008', 'Cada colaborador cumple sus funciones asignadas', 'Funciones', 8, 'evaluable', 1, null),
    (sb, 'FR-009', 'Personal productivo durante el turno', 'Productividad', 9, 'evaluable', 1, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'FR-02', 'Recepción y bienvenida', 2, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-010', 'Tiempo de recepción dentro del estándar', 'Tiempo de recepción', 10, 'medicion', 2, 'minutos · estándar por confirmar'),
    (sb, 'FR-011', 'Saludo conforme a estándar', 'Saludo', 11, 'evaluable', 2, null),
    (sb, 'FR-012', 'Actitud en la recepción', 'Actitud', 12, 'evaluable', 1, null),
    (sb, 'FR-013', 'Asignación de mesa correcta', 'Asignación de mesa', 13, 'evaluable', 1, null),
    (sb, 'FR-014', 'Lista de espera gestionada correctamente', 'Lista de espera', 14, 'evaluable', 1, null),
    (sb, 'FR-015', 'Tiempos de espera comunicados al cliente', 'Comunicación de tiempos', 15, 'evaluable', 1, null),
    (sb, 'FR-016', 'Hostess conoce el menú', 'Conocimiento del menú', 16, 'evaluable', 1, null),
    (sb, 'FR-017', 'Se informan las promociones vigentes', 'Información de promociones', 17, 'evaluable', 1, null),
    (sb, 'FR-018', 'Se informa sobre nannies y área infantil', 'Información de nannies/área infantil', 18, 'evaluable', 2, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'FR-03', 'Servicio en mesa', 3, 2) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-019', 'Toma de orden correcta', 'Toma de orden', 19, 'evaluable', 2, null),
    (sb, 'FR-020', 'Mesero conoce el menú', 'Conocimiento del menú', 20, 'evaluable', 2, null),
    (sb, 'FR-021', 'Modificaciones registradas correctamente', 'Modificaciones', 21, 'evaluable', 2, null),
    (sb, 'FR-022', 'Se realiza venta sugestiva', 'Venta sugestiva', 22, 'evaluable', 1, null),
    (sb, 'FR-023', 'Seguimiento a la mesa durante el servicio', 'Seguimiento', 23, 'evaluable', 1, null),
    (sb, 'FR-024', 'Necesidades del cliente atendidas', 'Atención de necesidades', 24, 'evaluable', 2, null),
    (sb, 'FR-025', 'Retiro de loza oportuno', 'Retiro de loza', 25, 'evaluable', 1, null),
    (sb, 'FR-026', 'Entrega correcta a la mesa', 'Entrega correcta', 26, 'evaluable', 2, null),
    (sb, 'FR-027', 'Se verifica la satisfacción del cliente', 'Verificación de satisfacción', 27, 'evaluable', 1, null),
    (sb, 'FR-028', 'Cuenta entregada correcta y a tiempo', 'Cuenta', 28, 'evaluable', 2, null),
    (sb, 'FR-029', 'Despedida conforme a estándar', 'Despedida', 29, 'evaluable', 1, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'FR-04', 'Experiencia del cliente', 4, 2) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-030', 'Trato al cliente conforme a estándar', 'Trato', 30, 'evaluable', 2, null),
    (sb, 'FR-031', 'Ambiente adecuado (música, temperatura, iluminación)', 'Ambiente', 31, 'evaluable', 1, null),
    (sb, 'FR-032', 'Comodidad del cliente', 'Comodidad', 32, 'evaluable', 1, null),
    (sb, 'FR-033', 'Limpieza visible para el cliente', 'Limpieza visible', 33, 'evaluable', 2, null),
    (sb, 'FR-034', 'Necesidades especiales atendidas (alergias, accesibilidad, bebés)', 'Necesidades especiales', 34, 'evaluable', 2, null),
    (sb, 'FR-035', 'Quejas registradas', 'Quejas', 35, 'evaluable', 2, null),
    (sb, 'FR-036', 'Quejas resueltas', 'Resolución', 36, 'evaluable', 2, null),
    (sb, 'FR-037', 'Quejas con seguimiento', 'Seguimiento', 37, 'evaluable', 1, null),
    (sb, 'FR-038', 'Observación directa / cliente incógnito sin hallazgos', 'Cliente incógnito / observación directa', 38, 'evaluable', 2, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'FR-05', 'Caja', 5, 3) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Apertura', 1, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-039', 'Fondo de caja correcto', 'Fondo', 39, 'evaluable', 3, null),
    (sb, 'FR-040', 'Responsable de caja asignado', 'Responsable', 40, 'evaluable', 2, null),
    (sb, 'FR-041', 'Accesos a caja controlados', 'Accesos', 41, 'evaluable', 3, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Cobros', 2, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-042', 'Cobros en efectivo correctos', 'Efectivo', 42, 'evaluable', 3, null),
    (sb, 'FR-043', 'Cobros con tarjeta correctos', 'Tarjetas', 43, 'evaluable', 3, null),
    (sb, 'FR-044', 'Terminales funcionando y conciliadas', 'Terminales', 44, 'evaluable', 2, null),
    (sb, 'FR-045', 'Cobros correctos contra consumo', 'Cobros correctos', 45, 'evaluable', 3, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Excepciones', 3, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-046', 'Descuentos autorizados y registrados', 'Descuentos', 46, 'evaluable', 3, null),
    (sb, 'FR-047', 'Cortesías autorizadas y registradas', 'Cortesías', 47, 'evaluable', 3, null),
    (sb, 'FR-048', 'Cancelaciones autorizadas y registradas', 'Cancelaciones', 48, 'evaluable', 3, null),
    (sb, 'FR-049', 'Devoluciones autorizadas y registradas', 'Devoluciones', 49, 'evaluable', 3, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Propinas', 4, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-050', 'Propinas registradas correctamente', 'Registro', 50, 'evaluable', 2, null),
    (sb, 'FR-051', 'Proceso de propinas conforme a estándar', 'Proceso', 51, 'evaluable', 2, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Cierre', 5, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-052', 'Corte de caja realizado correctamente', 'Corte', 52, 'evaluable', 3, null),
    (sb, 'FR-053', 'Efectivo cuadra contra sistema', 'Efectivo vs sistema', 53, 'evaluable', 3, null),
    (sb, 'FR-054', 'Terminales cuadran contra sistema', 'Terminales vs sistema', 54, 'evaluable', 3, null),
    (sb, 'FR-055', 'Diferencia de caja', 'Diferencias', 55, 'medicion', 3, '$ MXN · estándar: $0'),
    (sb, 'FR-056', 'Evidencia del corte conservada', 'Evidencia', 56, 'evaluable', 2, null),
    (sb, 'FR-057', 'Diferencias anteriores con seguimiento', 'Seguimiento', 57, 'evaluable', 2, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'FR-06', 'Reservaciones, eventos y Playdates', 6, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-058', 'Reservaciones/eventos registrados', 'Registro', 58, 'evaluable', 2, null),
    (sb, 'FR-059', 'Reservaciones confirmadas', 'Confirmación', 59, 'evaluable', 1, null),
    (sb, 'FR-060', 'Mesas asignadas para reservaciones', 'Mesas', 60, 'evaluable', 1, null),
    (sb, 'FR-061', 'Información del evento completa', 'Información', 61, 'evaluable', 2, null),
    (sb, 'FR-062', 'Comunicación del evento al equipo', 'Comunicación', 62, 'evaluable', 2, null),
    (sb, 'FR-063', 'Montaje del evento conforme a lo acordado', 'Montaje', 63, 'evaluable', 2, null),
    (sb, 'FR-064', 'Cocina informada y preparada para el evento', 'Cocina', 64, 'evaluable', 1, null),
    (sb, 'FR-065', 'Barra informada y preparada para el evento', 'Barra', 65, 'evaluable', 1, null),
    (sb, 'FR-066', 'Nannies informadas y preparadas para el evento', 'Nannies', 66, 'evaluable', 2, null),
    (sb, 'FR-067', 'Cobro del evento correcto', 'Cobro', 67, 'evaluable', 2, null),
    (sb, 'FR-068', 'No-shows registrados y gestionados', 'No-shows', 68, 'evaluable', 1, null),
    (sb, 'FR-069', 'Cambios gestionados y comunicados', 'Cambios', 69, 'evaluable', 1, null),
    (sb, 'FR-070', 'Cancelaciones gestionadas y comunicadas', 'Cancelaciones', 70, 'evaluable', 1, null),
    (sb, 'FR-071', 'Incidencias del evento registradas y atendidas', 'Incidencias', 71, 'evaluable', 2, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'FR-07', 'Nannies', 7, 3) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-072', 'Presentación de nannies adecuada', 'Presentación', 72, 'evaluable', 1, null),
    (sb, 'FR-073', 'Nannies puntuales', 'Puntualidad', 73, 'evaluable', 2, null),
    (sb, 'FR-074', 'Cobertura de nannies suficiente para los niños presentes', 'Cobertura', 74, 'evaluable', 3, null),
    (sb, 'FR-075', 'Actitud de nannies adecuada', 'Actitud', 75, 'evaluable', 2, null),
    (sb, 'FR-076', 'Nannies capacitadas', 'Capacitación', 76, 'evaluable', 2, null),
    (sb, 'FR-077', 'Recepción de niños conforme a protocolo', 'Recepción de niños', 77, 'evaluable', 3, null),
    (sb, 'FR-078', 'Control de niños dentro del área', 'Control', 78, 'evaluable', 3, null),
    (sb, 'FR-079', 'Identificación de padres/responsables al entregar', 'Identificación de padres/responsables', 79, 'evaluable', 3, null),
    (sb, 'FR-080', 'Supervisión constante de los niños', 'Supervisión', 80, 'evaluable', 3, null),
    (sb, 'FR-081', 'Capacidad del área respetada', 'Capacidad', 81, 'evaluable', 3, null),
    (sb, 'FR-082', 'Reglas del área aplicadas', 'Reglas', 82, 'evaluable', 2, null),
    (sb, 'FR-083', 'Actividades programadas realizadas', 'Actividades', 83, 'evaluable', 1, null),
    (sb, 'FR-084', 'Materiales de actividades suficientes y en buen estado', 'Materiales', 84, 'evaluable', 1, null),
    (sb, 'FR-085', 'Comunicación correcta con padres', 'Comunicación con padres', 85, 'evaluable', 2, null),
    (sb, 'FR-086', 'Incidentes registrados y atendidos', 'Incidentes', 86, 'evaluable', 3, null),
    (sb, 'FR-087', 'Escalamiento de incidentes conforme a protocolo', 'Escalamiento', 87, 'evaluable', 3, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'FR-08', 'Área infantil', 8, 3) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-088', 'Área infantil limpia', 'Limpieza', 88, 'evaluable', 2, null),
    (sb, 'FR-089', 'Juegos limpios y en buen estado', 'Juegos', 89, 'evaluable', 2, null),
    (sb, 'FR-090', 'Mesas del área infantil en buen estado', 'Mesas', 90, 'evaluable', 1, null),
    (sb, 'FR-091', 'Sillas del área infantil en buen estado', 'Sillas', 91, 'evaluable', 1, null),
    (sb, 'FR-092', 'Tapetes en buen estado', 'Tapetes', 92, 'evaluable', 2, null),
    (sb, 'FR-093', 'Materiales en buen estado', 'Materiales', 93, 'evaluable', 1, null),
    (sb, 'FR-094', 'Área infantil ordenada', 'Orden', 94, 'evaluable', 1, null),
    (sb, 'FR-095', 'Sin piezas sueltas', 'Piezas sueltas', 95, 'evaluable', 3, null),
    (sb, 'FR-096', 'Sin bordes peligrosos', 'Bordes peligrosos', 96, 'evaluable', 3, null),
    (sb, 'FR-097', 'Puertas del área funcionando y seguras', 'Puertas', 97, 'evaluable', 3, null),
    (sb, 'FR-098', 'Barreras en buen estado', 'Barreras', 98, 'evaluable', 3, null),
    (sb, 'FR-099', 'Capacidad del área respetada', 'Capacidad', 99, 'evaluable', 3, null),
    (sb, 'FR-100', 'Iluminación del área infantil adecuada', 'Iluminación', 100, 'evaluable', 1, null),
    (sb, 'FR-101', 'Clima del área infantil adecuado', 'Clima', 101, 'evaluable', 1, null),
    (sb, 'FR-102', 'Ventilación adecuada', 'Ventilación', 102, 'evaluable', 1, null),
    (sb, 'FR-103', 'Contactos protegidos', 'Contactos', 103, 'evaluable', 3, null),
    (sb, 'FR-104', 'Sin riesgos visibles en el área infantil', 'Riesgos', 104, 'evaluable', 3, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'FR-09', 'Limpieza Front', 9, 2) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-105', 'Salón limpio', 'Salón', 105, 'evaluable', 2, null),
    (sb, 'FR-106', 'Mesas limpias', 'Mesas', 106, 'evaluable', 2, null),
    (sb, 'FR-107', 'Sillas limpias', 'Sillas', 107, 'evaluable', 1, null),
    (sb, 'FR-108', 'Bancas limpias', 'Bancas', 108, 'evaluable', 1, null),
    (sb, 'FR-109', 'Sillones limpios', 'Sillones', 109, 'evaluable', 1, null),
    (sb, 'FR-110', 'Pisos limpios', 'Pisos', 110, 'evaluable', 2, null),
    (sb, 'FR-111', 'Paredes limpias', 'Paredes', 111, 'evaluable', 1, null),
    (sb, 'FR-112', 'Ventanas limpias', 'Ventanas', 112, 'evaluable', 1, null),
    (sb, 'FR-113', 'Puertas limpias', 'Puertas', 113, 'evaluable', 1, null),
    (sb, 'FR-114', 'Decoración limpia', 'Decoración', 114, 'evaluable', 1, null),
    (sb, 'FR-115', 'Estaciones de servicio limpias', 'Estaciones', 115, 'evaluable', 2, null),
    (sb, 'FR-116', 'Baños limpios y abastecidos', 'Baños', 116, 'evaluable', 3, null),
    (sb, 'FR-117', 'Área infantil limpia', 'Área infantil', 117, 'evaluable', 2, null),
    (sb, 'FR-118', 'Exterior limpio', 'Exterior', 118, 'evaluable', 1, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'FR-10', 'Mantenimiento Front', 10, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Salón', 1, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-119', 'Mobiliario del salón en buen estado', 'Mobiliario', 119, 'evaluable', 1, null),
    (sb, 'FR-120', 'Pisos del salón en buen estado', 'Pisos', 120, 'evaluable', 1, null),
    (sb, 'FR-121', 'Paredes del salón en buen estado', 'Paredes', 121, 'evaluable', 1, null),
    (sb, 'FR-122', 'Techos/plafones en buen estado', 'Techos/plafones', 122, 'evaluable', 1, null),
    (sb, 'FR-123', 'Pintura en buen estado', 'Pintura', 123, 'evaluable', 1, null),
    (sb, 'FR-124', 'Puertas del salón funcionando', 'Puertas', 124, 'evaluable', 1, null),
    (sb, 'FR-125', 'Ventanas en buen estado', 'Ventanas', 125, 'evaluable', 1, null),
    (sb, 'FR-126', 'Cristales sin daños', 'Cristales', 126, 'evaluable', 2, null),
    (sb, 'FR-127', 'Espejos en buen estado', 'Espejos', 127, 'evaluable', 1, null),
    (sb, 'FR-128', 'Iluminación del salón funcionando', 'Iluminación', 128, 'evaluable', 1, null),
    (sb, 'FR-129', 'Contactos del salón en buen estado y seguros', 'Contactos', 129, 'evaluable', 2, null),
    (sb, 'FR-130', 'Clima del salón funcionando', 'Clima', 130, 'evaluable', 2, null),
    (sb, 'FR-131', 'Sin humedad ni filtraciones en salón', 'Humedad/filtraciones', 131, 'evaluable', 2, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Baños', 2, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-132', 'Sanitarios funcionando', 'Sanitarios', 132, 'evaluable', 2, null),
    (sb, 'FR-133', 'Lavabos funcionando', 'Lavabos', 133, 'evaluable', 2, null),
    (sb, 'FR-134', 'Llaves funcionando', 'Llaves', 134, 'evaluable', 1, null),
    (sb, 'FR-135', 'Desagües funcionando', 'Desagües', 135, 'evaluable', 2, null),
    (sb, 'FR-136', 'Puertas de baños funcionando', 'Puertas', 136, 'evaluable', 1, null),
    (sb, 'FR-137', 'Iluminación de baños funcionando', 'Iluminación', 137, 'evaluable', 1, null),
    (sb, 'FR-138', 'Ventilación de baños funcionando', 'Ventilación', 138, 'evaluable', 1, null),
    (sb, 'FR-139', 'Sin fugas en baños', 'Fugas', 139, 'evaluable', 2, null),
    (sb, 'FR-140', 'Sin humedad en baños', 'Humedad', 140, 'evaluable', 1, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Área infantil', 3, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-141', 'Juegos del área infantil en buen estado', 'Juegos', 141, 'evaluable', 3, null),
    (sb, 'FR-142', 'Estructuras firmes y seguras', 'Estructuras', 142, 'evaluable', 3, null),
    (sb, 'FR-143', 'Resbaladillas en buen estado', 'Resbaladillas', 143, 'evaluable', 3, null),
    (sb, 'FR-144', 'Tapetes del área infantil en buen estado', 'Tapetes', 144, 'evaluable', 2, null),
    (sb, 'FR-145', 'Protecciones completas y en buen estado', 'Protecciones', 145, 'evaluable', 3, null),
    (sb, 'FR-146', 'Tornillería completa y apretada', 'Tornillos', 146, 'evaluable', 3, null),
    (sb, 'FR-147', 'Sin piezas sueltas en juegos', 'Piezas sueltas', 147, 'evaluable', 3, null),
    (sb, 'FR-148', 'Bordes protegidos', 'Bordes', 148, 'evaluable', 3, null),
    (sb, 'FR-149', 'Puertas/barreras del área infantil funcionando', 'Puertas/barreras', 149, 'evaluable', 3, null),
    (sb, 'FR-150', 'Clima del área infantil funcionando', 'Clima', 150, 'evaluable', 1, null),
    (sb, 'FR-151', 'Contactos del área infantil protegidos', 'Contactos', 151, 'evaluable', 3, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Exterior', 4, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-152', 'Fachada en buen estado', 'Fachada', 152, 'evaluable', 1, null),
    (sb, 'FR-153', 'Letreros en buen estado e iluminados', 'Letreros', 153, 'evaluable', 1, null),
    (sb, 'FR-154', 'Iluminación exterior funcionando', 'Iluminación', 154, 'evaluable', 1, null),
    (sb, 'FR-155', 'Accesos en buen estado', 'Accesos', 155, 'evaluable', 2, null),
    (sb, 'FR-156', 'Banquetas en buen estado', 'Banquetas', 156, 'evaluable', 1, null),
    (sb, 'FR-157', 'Jardinería en buen estado', 'Jardinería', 157, 'evaluable', 1, null),
    (sb, 'FR-158', 'Terraza en buen estado', 'Terraza', 158, 'evaluable', 1, null),
    (sb, 'FR-159', 'Mobiliario exterior en buen estado', 'Mobiliario', 159, 'evaluable', 1, null),
    (sb, 'FR-160', 'Cámaras/control de acceso exterior funcionando', 'Cámaras/control de acceso', 160, 'evaluable', 2, null);
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'Equipos Front', 5, false) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-161', 'Terminales funcionando', 'Terminales', 161, 'evaluable', 2, null),
    (sb, 'FR-162', 'Computadoras/tablets funcionando', 'Computadoras/tablets', 162, 'evaluable', 2, null),
    (sb, 'FR-163', 'Impresoras funcionando', 'Impresoras', 163, 'evaluable', 2, null),
    (sb, 'FR-164', 'Pantallas funcionando', 'Pantallas', 164, 'evaluable', 1, null),
    (sb, 'FR-165', 'Bocinas funcionando', 'Bocinas', 165, 'evaluable', 1, null),
    (sb, 'FR-166', 'Teléfonos funcionando', 'Teléfonos', 166, 'evaluable', 1, null),
    (sb, 'FR-167', 'Wi-Fi funcionando', 'Wi-Fi', 167, 'evaluable', 1, null),
    (sb, 'FR-168', 'Cámaras funcionando', 'Cámaras', 168, 'evaluable', 2, null),
    (sb, 'FR-169', 'Música funcionando', 'Música', 169, 'evaluable', 1, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'FR-11', 'Seguridad', 11, 3) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-170', 'Extintores vigentes, accesibles y señalizados', 'Extintores', 170, 'evaluable', 3, null),
    (sb, 'FR-171', 'Rutas de evacuación señalizadas y libres', 'Rutas de evacuación', 171, 'evaluable', 3, null),
    (sb, 'FR-172', 'Salidas de emergencia libres y funcionando', 'Salidas de emergencia', 172, 'evaluable', 3, null),
    (sb, 'FR-173', 'Iluminación de emergencia funcionando', 'Iluminación de emergencia', 173, 'evaluable', 2, null),
    (sb, 'FR-174', 'Botiquín completo y vigente', 'Botiquín', 174, 'evaluable', 2, null),
    (sb, 'FR-175', 'Cámaras de seguridad funcionando y grabando', 'Cámaras', 175, 'evaluable', 2, null),
    (sb, 'FR-176', 'Puertas de seguridad funcionando', 'Puertas', 176, 'evaluable', 2, null),
    (sb, 'FR-177', 'Sin riesgos visibles en la sucursal', 'Riesgos visibles', 177, 'evaluable', 3, null),
    (sb, 'FR-178', 'Seguridad infantil garantizada', 'Seguridad infantil', 178, 'evaluable', 3, null),
    (sb, 'FR-179', 'Capacidad del área infantil respetada', 'Capacidad del área infantil', 179, 'evaluable', 3, null),
    (sb, 'FR-180', 'Incidentes de seguridad registrados y atendidos', 'Incidentes', 180, 'evaluable', 3, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'FR-12', 'Coordinación Front ↔ A&B', 12, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-181', 'Comandas correctas hacia cocina y barra', 'Comandas', 181, 'evaluable', 2, null),
    (sb, 'FR-182', 'Modificaciones comunicadas a cocina y barra', 'Modificaciones', 182, 'evaluable', 2, null),
    (sb, 'FR-183', 'Tiempos de salida dentro del estándar', 'Tiempos', 183, 'evaluable', 1, null),
    (sb, 'FR-184', 'Salida de platillos y bebidas coordinada', 'Coordinación de salida', 184, 'evaluable', 1, null),
    (sb, 'FR-185', 'Sin pedidos atrasados', 'Pedidos atrasados', 185, 'evaluable', 1, null),
    (sb, 'FR-186', 'Sin errores en pedidos', 'Errores', 186, 'evaluable', 2, null),
    (sb, 'FR-187', 'Sin remakes durante la observación', 'Remakes', 187, 'evaluable', 1, null),
    (sb, 'FR-188', 'Sin devoluciones durante la observación', 'Devoluciones', 188, 'evaluable', 1, null),
    (sb, 'FR-189', 'Comunicación Front ↔ A&B efectiva', 'Comunicación', 189, 'evaluable', 1, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'FR-13', 'Ventas y productividad', 13, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-190', 'Ventas del periodo', 'Ventas', 190, 'dato', 0, '$ MXN'),
    (sb, 'FR-191', 'Ticket promedio', 'Ticket promedio', 191, 'dato', 0, '$ MXN'),
    (sb, 'FR-192', 'Mix alimentos/bebidas', 'Mix alimentos/bebidas', 192, 'dato', 0, '% alimentos / % bebidas'),
    (sb, 'FR-193', 'Ocupación', 'Ocupación', 193, 'dato', 0, '%'),
    (sb, 'FR-194', 'Rotación de mesas', 'Rotación', 194, 'dato', 0, 'veces por turno'),
    (sb, 'FR-195', 'Venta sugestiva aplicada por el equipo', 'Venta sugestiva', 195, 'evaluable', 1, null),
    (sb, 'FR-196', 'Se ofrecen productos adicionales', 'Productos adicionales', 196, 'evaluable', 1, null),
    (sb, 'FR-197', 'Horas pico identificadas', 'Horas pico', 197, 'dato', 0, 'texto'),
    (sb, 'FR-198', 'Oportunidades de venta detectadas', 'Oportunidades', 198, 'dato', 0, 'texto');

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'FR-14', 'Procesos y estándares', 14, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-199', 'Llegada del cliente conforme a estándar', 'Llegada', 199, 'evaluable', 1, null),
    (sb, 'FR-200', 'Recepción conforme a estándar', 'Recepción', 200, 'evaluable', 1, null),
    (sb, 'FR-201', 'Asignación de mesa conforme a estándar', 'Mesa', 201, 'evaluable', 1, null),
    (sb, 'FR-202', 'Toma de orden conforme a estándar', 'Orden', 202, 'evaluable', 1, null),
    (sb, 'FR-203', 'Preparación conforme a tiempos estándar', 'Preparación', 203, 'evaluable', 1, null),
    (sb, 'FR-204', 'Entrega conforme a estándar', 'Entrega', 204, 'evaluable', 1, null),
    (sb, 'FR-205', 'Seguimiento conforme a estándar', 'Seguimiento', 205, 'evaluable', 1, null),
    (sb, 'FR-206', 'Cobro conforme a estándar', 'Cobro', 206, 'evaluable', 2, null),
    (sb, 'FR-207', 'Despedida conforme a estándar', 'Despedida', 207, 'evaluable', 1, null);

  insert into public.audit_sections(template_version_id, code, name, sort, weight) values (v, 'FR-15', 'Capacitación', 15, 1) returning id into s;
  insert into public.audit_subsections(section_id, name, sort, is_default) values (s, 'General', 1, true) returning id into sb;
  insert into public.audit_items(subsection_id, code, text, original_text, sort, item_type, weight, unit) values
    (sb, 'FR-208', 'Personal conoce el menú', 'Menú', 208, 'evaluable', 2, null),
    (sb, 'FR-209', 'Personal conoce el estándar de servicio', 'Servicio', 209, 'evaluable', 2, null),
    (sb, 'FR-210', 'Personal capacitado en caja', 'Caja', 210, 'evaluable', 2, null),
    (sb, 'FR-211', 'Personal capacitado en reservaciones', 'Reservaciones', 211, 'evaluable', 1, null),
    (sb, 'FR-212', 'Nannies capacitadas en protocolo', 'Nannies', 212, 'evaluable', 2, null),
    (sb, 'FR-213', 'Personal capacitado en seguridad infantil', 'Seguridad infantil', 213, 'evaluable', 3, null),
    (sb, 'FR-214', 'Personal capacitado en manejo de quejas', 'Quejas', 214, 'evaluable', 2, null),
    (sb, 'FR-215', 'Personal capacitado en sistemas (Parrot, terminales)', 'Sistemas', 215, 'evaluable', 2, null),
    (sb, 'FR-216', 'Personal nuevo capacitado', 'Personal nuevo', 216, 'evaluable', 2, null),
    (sb, 'FR-217', 'Sin errores recurrentes del personal', 'Errores recurrentes', 217, 'evaluable', 2, null);

  update public.template_versions set status = 'publicada', published_at = now() where id = v;
end $$;

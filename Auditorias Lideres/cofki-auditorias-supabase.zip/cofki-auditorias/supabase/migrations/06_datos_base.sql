-- =====================================================================
-- Cofki Auditorías · 06 · Datos base (roles, sucursales, tipos, configuración)
-- =====================================================================

insert into public.roles (code, name) values
  ('lider_ab',    'Líder de Alimentos y Bebidas'),
  ('lider_front', 'Líder de Servicio, Caja y Nannies'),
  ('socio',       'Socio / Administrador');

insert into public.branches (code, name, sort) values
  ('AURORA', 'Aurora',        1),
  ('GM3',    'GM3',           2),
  ('SERENA', 'Pueblo Serena', 3);

insert into public.audit_types (code, name, target_min_minutes, target_max_minutes, sort) values
  ('AB',    'Alimentos y Bebidas',         180, 240, 1),
  ('FRONT', 'Servicio, Caja y Nannies',    180, 240, 2);

insert into public.scoring_config (key, value, description) values
  ('parcial_factor',          0.5, 'Valor de "Cumple parcialmente" (0.5 = 50 %)'),
  ('advertencia_minutos',     180, 'Si la auditoría dura menos, se advierte al cerrar'),
  ('dias_proxima_vencer',       3, 'Días antes de la fecha compromiso para alertar'),
  ('caida_importante_puntos',  10, 'Caída vs. semana anterior que dispara alerta'),
  ('recurrente_semanas',        2, 'Semanas seguidas con No cumple = problema recurrente'),
  ('peso_sucursal_AB',        0.5, 'Peso de A&B en la calificación de sucursal'),
  ('peso_sucursal_FRONT',     0.5, 'Peso de Front en la calificación de sucursal');

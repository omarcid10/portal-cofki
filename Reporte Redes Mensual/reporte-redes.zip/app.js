/* ============================================================
   REPORTE DE REDES · cofki — versión local
   Todo se guarda en este navegador (localStorage). No depende de
   Google Sheets ni de ningún servidor. Usa "Exportar respaldo" para
   guardar una copia y "Importar respaldo" para restaurarla o pasarla
   a otro navegador/computadora.
   ============================================================ */

const STORAGE_KEYS = {
  cuentas: 'reporteRedes_cuentas',
  datos: 'reporteRedes_datos'
};

const SEED_CUENTAS = [{"ID": 1, "Red": "Instagram", "Cuenta": "cofkicafe", "Etiqueta": "Cofki", "Tipo": "Propia", "Activo": true}, {"ID": 2, "Red": "Instagram", "Cuenta": "losbenditoschilaquiles", "Etiqueta": "Benditos Chilaquiles", "Tipo": "Propia", "Activo": true}, {"ID": 3, "Red": "Instagram", "Cuenta": "districtmex", "Etiqueta": "District", "Tipo": "Propia", "Activo": true}, {"ID": 4, "Red": "Instagram", "Cuenta": "michilakil.mx", "Etiqueta": "MiChilakil", "Tipo": "Propia", "Activo": true}, {"ID": 5, "Red": "Instagram", "Cuenta": "spaghettomx", "Etiqueta": "Spaghetto", "Tipo": "Propia", "Activo": true}, {"ID": 6, "Red": "Instagram", "Cuenta": "hulahoop_playground", "Etiqueta": "HulaHoop", "Tipo": "Competencia", "Activo": true}, {"ID": 7, "Red": "Instagram", "Cuenta": "casapandamx", "Etiqueta": "Casa Panda", "Tipo": "Competencia", "Activo": true}, {"ID": 8, "Red": "Instagram", "Cuenta": "ommanimx", "Etiqueta": "Ommani", "Tipo": "Competencia", "Activo": true}, {"ID": 9, "Red": "Instagram", "Cuenta": "kalicoffeeroasters", "Etiqueta": "Kali", "Tipo": "Competencia", "Activo": true}, {"ID": 10, "Red": "Instagram", "Cuenta": "breadpanaderos", "Etiqueta": "Bread", "Tipo": "Competencia", "Activo": true}, {"ID": 11, "Red": "Instagram", "Cuenta": "Hoopla_Kids", "Etiqueta": "Hoopla Kids", "Tipo": "Competencia", "Activo": true}, {"ID": 12, "Red": "Instagram", "Cuenta": "TapiocaLab", "Etiqueta": "TapiocaLab", "Tipo": "Competencia", "Activo": true}, {"ID": 13, "Red": "Instagram", "Cuenta": "Tempo", "Etiqueta": "Tempo", "Tipo": "Competencia", "Activo": true}, {"ID": 14, "Red": "Instagram", "Cuenta": "Tetecolohcafe", "Etiqueta": "Tetecolohcafe", "Tipo": "Competencia", "Activo": true}, {"ID": 15, "Red": "Instagram", "Cuenta": "caligoroasters", "Etiqueta": "Caligo", "Tipo": "Competencia", "Activo": true}, {"ID": 16, "Red": "Instagram", "Cuenta": "pexcamx", "Etiqueta": "Pexca", "Tipo": "Competencia", "Activo": true}, {"ID": 17, "Red": "Instagram", "Cuenta": "playticamx", "Etiqueta": "Playtica", "Tipo": "Competencia", "Activo": true}, {"ID": 18, "Red": "Instagram", "Cuenta": "championplayground", "Etiqueta": "Champions", "Tipo": "Competencia", "Activo": true}, {"ID": 19, "Red": "Instagram", "Cuenta": "wunder_playground", "Etiqueta": "Wunder Playground", "Tipo": "Competencia", "Activo": true}, {"ID": 20, "Red": "Instagram", "Cuenta": "bubucafe_mx", "Etiqueta": "Bubu Café", "Tipo": "Competencia", "Activo": true}, {"ID": 21, "Red": "Instagram", "Cuenta": "cafetilandia", "Etiqueta": "Cafetilandia", "Tipo": "Competencia", "Activo": true}, {"ID": 22, "Red": "Instagram", "Cuenta": "happycups.mx", "Etiqueta": "Happy Cups", "Tipo": "Competencia", "Activo": true}, {"ID": 23, "Red": "Instagram", "Cuenta": "littlegoosemty_", "Etiqueta": "Little Goose", "Tipo": "Competencia", "Activo": true}, {"ID": 24, "Red": "Instagram", "Cuenta": "lunara.ludoteca", "Etiqueta": "Lunara", "Tipo": "Competencia", "Activo": true}, {"ID": 25, "Red": "Instagram", "Cuenta": "maximosland", "Etiqueta": "Maximos Land", "Tipo": "Competencia", "Activo": true}, {"ID": 26, "Red": "Instagram", "Cuenta": "casapiccolomty", "Etiqueta": "Casa Piccolo", "Tipo": "Competencia", "Activo": true}, {"ID": 27, "Red": "Instagram", "Cuenta": "nooknook.mx", "Etiqueta": "Nook Nook", "Tipo": "Competencia", "Activo": true}, {"ID": 28, "Red": "Instagram", "Cuenta": "casa.colora", "Etiqueta": "Casa Colora", "Tipo": "Competencia", "Activo": true}, {"ID": 29, "Red": "Instagram", "Cuenta": "pingoli.mty", "Etiqueta": "Pingoli", "Tipo": "Competencia", "Activo": true}, {"ID": 30, "Red": "Instagram", "Cuenta": "azul.quedito.mty", "Etiqueta": "Azul Quedito", "Tipo": "Competencia", "Activo": true}, {"ID": 31, "Red": "Instagram", "Cuenta": "pookies.playground", "Etiqueta": "Pookies Playground", "Tipo": "Competencia", "Activo": true}, {"ID": 32, "Red": "Facebook", "Cuenta": "Cofki FB", "Etiqueta": "Cofki", "Tipo": "Propia", "Activo": true}, {"ID": 33, "Red": "TikTok", "Cuenta": "Cofki TikTok", "Etiqueta": "Cofki", "Tipo": "Propia", "Activo": true}, {"ID": 34, "Red": "TikTok", "Cuenta": "Bubu TikTok", "Etiqueta": "Bubu", "Tipo": "Competencia", "Activo": true}, {"ID": 35, "Red": "TikTok", "Cuenta": "Cafetilandia TikTok", "Etiqueta": "Cafetilandia", "Tipo": "Competencia", "Activo": true}, {"ID": 36, "Red": "TikTok", "Cuenta": "Casa Piccolo TikTok", "Etiqueta": "Casa Piccolo", "Tipo": "Competencia", "Activo": true}, {"ID": 37, "Red": "TikTok", "Cuenta": "Happy Cups TikTok", "Etiqueta": "Happy Cups", "Tipo": "Competencia", "Activo": true}, {"ID": 38, "Red": "Google", "Cuenta": "Cofki GM", "Etiqueta": "Cofki GM", "Tipo": "Propia", "Activo": true}, {"ID": 39, "Red": "Google", "Cuenta": "Cofki VO", "Etiqueta": "Cofki VO", "Tipo": "Propia", "Activo": true}, {"ID": 40, "Red": "Google", "Cuenta": "Cofki Serena", "Etiqueta": "Cofki Serena", "Tipo": "Propia", "Activo": true}, {"ID": 41, "Red": "Google", "Cuenta": "Bubu Google", "Etiqueta": "Bubu", "Tipo": "Competencia", "Activo": true}, {"ID": 42, "Red": "Google", "Cuenta": "Cafetilandia Google", "Etiqueta": "Cafetilandia", "Tipo": "Competencia", "Activo": true}, {"ID": 43, "Red": "Google", "Cuenta": "Casa Piccolo Google", "Etiqueta": "Casa Piccolo", "Tipo": "Competencia", "Activo": true}, {"ID": 44, "Red": "Google", "Cuenta": "Lunara Google", "Etiqueta": "Lunara", "Tipo": "Competencia", "Activo": true}, {"ID": 45, "Red": "Google", "Cuenta": "Little Goose Google", "Etiqueta": "Little Goose", "Tipo": "Competencia", "Activo": true}, {"ID": 46, "Red": "Google", "Cuenta": "Pingoli Google", "Etiqueta": "Pingoli", "Tipo": "Competencia", "Activo": true}];
const SEED_DATOS = [{"Mes": "2025-10", "CuentaID": 1, "Seguidores": 37758, "Interacciones": 4683, "Visualizaciones": 893530, "Alcance": 220273, "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 6, "Seguidores": 24300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 7, "Seguidores": 15500, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 8, "Seguidores": 40900, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 9, "Seguidores": 59700, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 10, "Seguidores": 52200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 11, "Seguidores": 10900, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 13, "Seguidores": 10300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 14, "Seguidores": 17700, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 16, "Seguidores": 4640, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 2, "Seguidores": 1567, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 17, "Seguidores": 63600, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 18, "Seguidores": 31700, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 19, "Seguidores": 3654, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 20, "Seguidores": 7248, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 3, "Seguidores": 73, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 4, "Seguidores": 30, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 21, "Seguidores": 2463, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 22, "Seguidores": 5643, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 23, "Seguidores": 2660, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 24, "Seguidores": 1967, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 25, "Seguidores": 1377, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 5, "Seguidores": 19, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 26, "Seguidores": 947, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 32, "Seguidores": 16402, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": 16402, "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 33, "Seguidores": 569, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 34, "Seguidores": 623, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-10", "CuentaID": 35, "Seguidores": 99, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 1, "Seguidores": 38771, "Interacciones": 5617, "Visualizaciones": 747389, "Alcance": 203990, "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 6, "Seguidores": 24300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 7, "Seguidores": 15500, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 8, "Seguidores": 41000, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 9, "Seguidores": 60400, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 10, "Seguidores": 52800, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 11, "Seguidores": 11000, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 13, "Seguidores": 10300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 14, "Seguidores": 17700, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 16, "Seguidores": 4674, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 2, "Seguidores": 1577, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 17, "Seguidores": 63900, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 18, "Seguidores": 35600, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 19, "Seguidores": 3700, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 20, "Seguidores": 7338, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 3, "Seguidores": 72, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 4, "Seguidores": 30, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 21, "Seguidores": 2587, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 22, "Seguidores": 6042, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 23, "Seguidores": 2928, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 24, "Seguidores": 2053, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 25, "Seguidores": 2667, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 5, "Seguidores": 23, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 26, "Seguidores": 3023, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 32, "Seguidores": 16405, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": 16405, "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 33, "Seguidores": 595, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 34, "Seguidores": 621, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 35, "Seguidores": 106, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-11", "CuentaID": 36, "Seguidores": 9, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 1, "Seguidores": 39847, "Interacciones": 6163, "Visualizaciones": 695520, "Alcance": 201861, "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 6, "Seguidores": 24300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 7, "Seguidores": 15500, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 8, "Seguidores": 41300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 9, "Seguidores": 60900, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 10, "Seguidores": 53200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 11, "Seguidores": 11000, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 13, "Seguidores": 10300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 14, "Seguidores": 17600, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 16, "Seguidores": 4725, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 2, "Seguidores": 1583, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 17, "Seguidores": 64100, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 18, "Seguidores": 36300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 19, "Seguidores": 3721, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 20, "Seguidores": 7395, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 3, "Seguidores": 72, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 4, "Seguidores": 30, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 21, "Seguidores": 2643, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 22, "Seguidores": 6113, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 23, "Seguidores": 3159, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 24, "Seguidores": 2178, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 25, "Seguidores": 3107, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 5, "Seguidores": 25, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 26, "Seguidores": 3391, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 27, "Seguidores": 330, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 32, "Seguidores": 16467, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": 16467, "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 33, "Seguidores": 618, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 34, "Seguidores": 620, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 35, "Seguidores": 108, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2025-12", "CuentaID": 36, "Seguidores": 17, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 1, "Seguidores": 40914, "Interacciones": 5414, "Visualizaciones": 645053, "Alcance": 208842, "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 6, "Seguidores": 24200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 7, "Seguidores": 15600, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 8, "Seguidores": 41300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 9, "Seguidores": 61100, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 10, "Seguidores": 54000, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 11, "Seguidores": 11100, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 13, "Seguidores": 10300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 14, "Seguidores": 17600, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 16, "Seguidores": 4769, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 2, "Seguidores": 1580, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 17, "Seguidores": 64200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 18, "Seguidores": 37300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 19, "Seguidores": 3728, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 20, "Seguidores": 7504, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 3, "Seguidores": 71, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 4, "Seguidores": 31, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 21, "Seguidores": 2797, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 22, "Seguidores": 6247, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 23, "Seguidores": 3398, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 24, "Seguidores": 2413, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 25, "Seguidores": 3986, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 5, "Seguidores": 30, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 26, "Seguidores": 3564, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 27, "Seguidores": 611, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 32, "Seguidores": 16480, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": 16480, "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 33, "Seguidores": 635, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 34, "Seguidores": 617, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 35, "Seguidores": 108, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-01", "CuentaID": 36, "Seguidores": 18, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 1, "Seguidores": 41867, "Interacciones": 4918, "Visualizaciones": 647403, "Alcance": 203435, "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 6, "Seguidores": 24200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 7, "Seguidores": 15600, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 8, "Seguidores": 41600, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 9, "Seguidores": 61900, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 10, "Seguidores": 55900, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 11, "Seguidores": 11100, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 13, "Seguidores": 10300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 14, "Seguidores": 17500, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 16, "Seguidores": 4934, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 2, "Seguidores": 1580, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 17, "Seguidores": 64600, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 18, "Seguidores": 39800, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 19, "Seguidores": 3783, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 20, "Seguidores": 7602, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 3, "Seguidores": 71, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 4, "Seguidores": 31, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 21, "Seguidores": 2936, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 22, "Seguidores": 6351, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 23, "Seguidores": 3586, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 24, "Seguidores": 2618, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 25, "Seguidores": 4053, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 5, "Seguidores": 30, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 26, "Seguidores": 3783, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 27, "Seguidores": 1067, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 32, "Seguidores": 16500, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": 16500, "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 33, "Seguidores": 657, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 34, "Seguidores": 615, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 35, "Seguidores": 105, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-02", "CuentaID": 36, "Seguidores": 54, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 1, "Seguidores": 42781, "Interacciones": 5132, "Visualizaciones": 687482, "Alcance": 208372, "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 6, "Seguidores": 24200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 7, "Seguidores": 15700, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 8, "Seguidores": 42000, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 9, "Seguidores": 62600, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 10, "Seguidores": 56400, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 11, "Seguidores": 11200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 13, "Seguidores": 10300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 14, "Seguidores": 17500, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 16, "Seguidores": 4939, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 2, "Seguidores": 1607, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 17, "Seguidores": 64900, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 18, "Seguidores": 42000, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 19, "Seguidores": 3839, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 20, "Seguidores": 7658, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 3, "Seguidores": 74, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 4, "Seguidores": 33, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 21, "Seguidores": 3012, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 22, "Seguidores": 6401, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 23, "Seguidores": 3732, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 24, "Seguidores": 2721, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 25, "Seguidores": 4178, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 5, "Seguidores": 44, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 26, "Seguidores": 3917, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 27, "Seguidores": 1369, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 32, "Seguidores": 16519, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": 16519, "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 33, "Seguidores": 878, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 34, "Seguidores": 614, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 35, "Seguidores": 105, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 36, "Seguidores": 57, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-03", "CuentaID": 37, "Seguidores": 22, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 1, "Seguidores": 43592, "Interacciones": 4780, "Visualizaciones": 563802, "Alcance": 177606, "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 6, "Seguidores": 24100, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 7, "Seguidores": 15800, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 8, "Seguidores": 42200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 9, "Seguidores": 63600, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 10, "Seguidores": 56800, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 11, "Seguidores": 11200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 13, "Seguidores": 10400, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 14, "Seguidores": 17400, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 16, "Seguidores": 4979, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 2, "Seguidores": 1601, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 17, "Seguidores": 65300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 18, "Seguidores": 43700, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 19, "Seguidores": 3839, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 20, "Seguidores": 7784, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 3, "Seguidores": 74, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 4, "Seguidores": 34, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 21, "Seguidores": 3092, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 22, "Seguidores": 6456, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 23, "Seguidores": 4025, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 24, "Seguidores": 2845, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 25, "Seguidores": 4661, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 5, "Seguidores": 48, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 26, "Seguidores": 4472, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 27, "Seguidores": 1581, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 28, "Seguidores": 257, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 32, "Seguidores": 16537, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": 16537, "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 33, "Seguidores": 1033, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 34, "Seguidores": 614, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 35, "Seguidores": 113, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 36, "Seguidores": 284, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-04", "CuentaID": 37, "Seguidores": 22, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 1, "Seguidores": 44282, "Interacciones": 5898, "Visualizaciones": 551782, "Alcance": 169015, "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 6, "Seguidores": 24100, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 7, "Seguidores": 15800, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 8, "Seguidores": 42400, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 9, "Seguidores": 64000, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 10, "Seguidores": 57200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 11, "Seguidores": 11200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 13, "Seguidores": 10500, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 14, "Seguidores": 17400, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 16, "Seguidores": 4963, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 2, "Seguidores": 1604, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 17, "Seguidores": 66600, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 18, "Seguidores": 44700, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 19, "Seguidores": 3964, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 20, "Seguidores": 7894, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 3, "Seguidores": 74, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 4, "Seguidores": 34, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 21, "Seguidores": 3194, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 22, "Seguidores": 6539, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 23, "Seguidores": 4763, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 24, "Seguidores": 2886, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 25, "Seguidores": 4770, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 5, "Seguidores": 49, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 26, "Seguidores": 4697, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 27, "Seguidores": 1776, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 28, "Seguidores": 4072, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 32, "Seguidores": 16550, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": 16550, "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 33, "Seguidores": 1119, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 34, "Seguidores": 610, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 35, "Seguidores": 113, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 36, "Seguidores": 318, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 37, "Seguidores": 22, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 38, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 315, "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 39, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 128, "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 41, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 73, "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 42, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 54, "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 43, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 24, "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 44, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 110, "ActualizadoEn": ""}, {"Mes": "2026-05", "CuentaID": 45, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 28, "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 1, "Seguidores": 45073, "Interacciones": 8392, "Visualizaciones": 493481, "Alcance": 137094, "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 6, "Seguidores": 24000, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 7, "Seguidores": 15900, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 8, "Seguidores": 42500, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 9, "Seguidores": 64700, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 10, "Seguidores": 57600, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 11, "Seguidores": 11200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 13, "Seguidores": 10600, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 14, "Seguidores": 17300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 16, "Seguidores": 4942, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 2, "Seguidores": 1610, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 17, "Seguidores": 67400, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 18, "Seguidores": 46200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 19, "Seguidores": 4011, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 20, "Seguidores": 7972, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 3, "Seguidores": 75, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 4, "Seguidores": 37, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 21, "Seguidores": 3261, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 22, "Seguidores": 6683, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 23, "Seguidores": 5180, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 24, "Seguidores": 2965, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 25, "Seguidores": 4874, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 5, "Seguidores": 67, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 26, "Seguidores": 4788, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 27, "Seguidores": 1934, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 28, "Seguidores": 6619, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 29, "Seguidores": 768, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 30, "Seguidores": 638, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 32, "Seguidores": 16536, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": 16536, "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 33, "Seguidores": 1201, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 34, "Seguidores": 610, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 35, "Seguidores": 112, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 36, "Seguidores": 348, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 37, "Seguidores": 22, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 38, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 318, "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 39, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 167, "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 41, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 74, "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 42, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 55, "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 43, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 24, "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 44, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 113, "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 45, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 29, "ActualizadoEn": ""}, {"Mes": "2026-06", "CuentaID": 46, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 0, "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 1, "Seguidores": 45744, "Interacciones": 11421, "Visualizaciones": 481197, "Alcance": 211432, "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 6, "Seguidores": 24000, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 7, "Seguidores": 15900, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 8, "Seguidores": 42700, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 9, "Seguidores": 65100, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 10, "Seguidores": 57800, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 11, "Seguidores": 11200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 13, "Seguidores": 10700, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 14, "Seguidores": 17200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 16, "Seguidores": 4928, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 2, "Seguidores": 1610, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 17, "Seguidores": 69500, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 18, "Seguidores": 47600, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 19, "Seguidores": 4058, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 20, "Seguidores": 7996, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 3, "Seguidores": 75, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 4, "Seguidores": 36, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 21, "Seguidores": 3293, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 22, "Seguidores": 6952, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 23, "Seguidores": 5338, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 24, "Seguidores": 3021, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 25, "Seguidores": 4927, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 5, "Seguidores": 68, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 26, "Seguidores": 4873, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 27, "Seguidores": 2065, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 28, "Seguidores": 7519, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 29, "Seguidores": 1238, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 30, "Seguidores": 663, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 31, "Seguidores": 2535, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 32, "Seguidores": 16813, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": 16813, "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 33, "Seguidores": 1260, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 34, "Seguidores": 611, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 35, "Seguidores": 111, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 36, "Seguidores": 354, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 37, "Seguidores": 25, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 38, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 336, "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 39, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 208, "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 41, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 75, "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 42, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 57, "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 43, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 29, "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 44, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 115, "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 45, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 32, "ActualizadoEn": ""}, {"Mes": "2026-07", "CuentaID": 46, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 0, "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 1, "Seguidores": 46646, "Interacciones": 6290, "Visualizaciones": 572402, "Alcance": 179024, "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 6, "Seguidores": 24000, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 7, "Seguidores": 15900, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 8, "Seguidores": 42700, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 9, "Seguidores": 65100, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 10, "Seguidores": 58300, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 11, "Seguidores": 11200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 13, "Seguidores": 10600, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 14, "Seguidores": 17100, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 16, "Seguidores": 4910, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 2, "Seguidores": 1603, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 17, "Seguidores": 72000, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 18, "Seguidores": 48900, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 19, "Seguidores": 4092, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 20, "Seguidores": 8083, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 3, "Seguidores": 75, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 4, "Seguidores": 36, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 21, "Seguidores": 3355, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 22, "Seguidores": 6909, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 23, "Seguidores": 5447, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 24, "Seguidores": 3101, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 25, "Seguidores": 5074, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 5, "Seguidores": 70, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 26, "Seguidores": 5001, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 27, "Seguidores": 2193, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 28, "Seguidores": 8393, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 29, "Seguidores": 1851, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 30, "Seguidores": 798, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 31, "Seguidores": 2710, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 32, "Seguidores": 16882, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": 16882, "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 33, "Seguidores": 1310, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 34, "Seguidores": 607, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 35, "Seguidores": 110, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 36, "Seguidores": 359, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 37, "Seguidores": 27, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 38, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 360, "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 39, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 220, "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 41, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 77, "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 42, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 57, "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 43, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 35, "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 44, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 115, "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 45, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 34, "ActualizadoEn": ""}, {"Mes": "2026-08", "CuentaID": 46, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 0, "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 1, "Seguidores": 47004, "Interacciones": 6229, "Visualizaciones": 545571, "Alcance": 148337, "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 6, "Seguidores": 24000, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 7, "Seguidores": 15900, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 8, "Seguidores": 42900, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 9, "Seguidores": 65700, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 10, "Seguidores": 58900, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 11, "Seguidores": 11200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 13, "Seguidores": 10700, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 14, "Seguidores": 17100, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 16, "Seguidores": 4901, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 2, "Seguidores": 1615, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 17, "Seguidores": 73400, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 18, "Seguidores": 49200, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 19, "Seguidores": 4115, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 20, "Seguidores": 4124, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 3, "Seguidores": 77, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 4, "Seguidores": 37, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 21, "Seguidores": 3401, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 22, "Seguidores": 6856, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 23, "Seguidores": 5578, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 24, "Seguidores": 3127, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 25, "Seguidores": 5162, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 5, "Seguidores": 77, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 26, "Seguidores": 5594, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 27, "Seguidores": 2292, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 28, "Seguidores": 8570, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 29, "Seguidores": 2428, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 30, "Seguidores": 1251, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 31, "Seguidores": 3080, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 32, "Seguidores": 17240, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": 17240, "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 33, "Seguidores": 1373, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 34, "Seguidores": 607, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 35, "Seguidores": 109, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 36, "Seguidores": 365, "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": "", "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 38, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 377, "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 39, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 255, "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 40, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 9, "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 41, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 81, "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 42, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 60, "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 43, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 55, "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 44, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 118, "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 45, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 36, "ActualizadoEn": ""}, {"Mes": "2026-09", "CuentaID": 46, "Seguidores": "", "Interacciones": "", "Visualizaciones": "", "Alcance": "", "MeGusta": "", "Comentarios": 3, "ActualizadoEn": ""}];

const RED_ORDER = ['Instagram', 'Facebook', 'TikTok', 'Google'];
const RED_COLORS = {
  Instagram: '#FFA726',
  Facebook: '#00BFA5',
  TikTok: '#424242',
  Google: '#FF5252'
};
const RED_FIELDS = {
  Instagram: [
    { key: 'seguidores', label: 'Seguidores', ownOnly: false },
    { key: 'interacciones', label: 'Interacc.', ownOnly: true },
    { key: 'visualizaciones', label: 'Visualiz.', ownOnly: true },
    { key: 'alcance', label: 'Alcance', ownOnly: true }
  ],
  Facebook: [
    { key: 'seguidores', label: 'Seguidores', ownOnly: false },
    { key: 'meGusta', label: 'Me gusta', ownOnly: true },
    { key: 'alcance', label: 'Alcance', ownOnly: true },
    { key: 'interacciones', label: 'Interacc.', ownOnly: true }
  ],
  TikTok: [
    { key: 'seguidores', label: 'Seguidores', ownOnly: false }
  ],
  Google: [
    { key: 'comentarios', label: 'Comentarios', ownOnly: false }
  ]
};
const DATA_FIELD_MAP = {
  seguidores: 'Seguidores',
  interacciones: 'Interacciones',
  visualizaciones: 'Visualizaciones',
  alcance: 'Alcance',
  meGusta: 'MeGusta',
  comentarios: 'Comentarios'
};

let STATE = { cuentas: [], datos: [] };
let CHARTS = {};

// ---------------- utils ----------------
function $(sel) { return document.querySelector(sel); }
function $all(sel) { return Array.from(document.querySelectorAll(sel)); }

function currentMonthValue() {
  const d = new Date();
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
}
function prevMonthValue(mes) {
  const [y, m] = mes.split('-').map(Number);
  const d = new Date(y, m - 2, 1);
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
}
function monthLabel(mes) {
  const [y, m] = mes.split('-').map(Number);
  const d = new Date(y, m - 1, 1);
  return d.toLocaleDateString('es-MX', { month: 'short', year: '2-digit' }).replace('.', '');
}
function fmtNum(n) {
  if (n === '' || n === null || n === undefined || isNaN(n)) return '—';
  return Number(n).toLocaleString('es-MX');
}
function showToast(msg, isErr) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'toast show' + (isErr ? ' err' : '');
  setTimeout(() => { t.className = 'toast'; }, 2600);
}
function setStatus(text, kind) {
  const el = $('#statusPill');
  el.textContent = text;
  el.className = 'status' + (kind ? ' ' + kind : '');
}

// ---------------- storage (localStorage) ----------------
function loadState() {
  try {
    const rawCuentas = localStorage.getItem(STORAGE_KEYS.cuentas);
    const rawDatos = localStorage.getItem(STORAGE_KEYS.datos);
    if (rawCuentas && rawDatos) {
      STATE.cuentas = JSON.parse(rawCuentas);
      STATE.datos = JSON.parse(rawDatos);
    } else {
      STATE.cuentas = JSON.parse(JSON.stringify(SEED_CUENTAS));
      STATE.datos = JSON.parse(JSON.stringify(SEED_DATOS));
      persist();
    }
  } catch (err) {
    STATE.cuentas = JSON.parse(JSON.stringify(SEED_CUENTAS));
    STATE.datos = JSON.parse(JSON.stringify(SEED_DATOS));
    persist();
  }
}
function persist() {
  localStorage.setItem(STORAGE_KEYS.cuentas, JSON.stringify(STATE.cuentas));
  localStorage.setItem(STORAGE_KEYS.datos, JSON.stringify(STATE.datos));
}

function cuentasActivasPorRed(red) {
  return STATE.cuentas
    .filter(c => c.Red === red && (c.Activo === true || c.Activo === 'TRUE' || c.Activo === 'true'))
    .sort((a, b) => {
      if (a.Tipo !== b.Tipo) return a.Tipo === 'Propia' ? -1 : 1;
      return String(a.Etiqueta).localeCompare(String(b.Etiqueta));
    });
}
function datoDe(mes, cuentaId) {
  return STATE.datos.find(d => String(d.Mes) === String(mes) && Number(d.CuentaID) === Number(cuentaId));
}
function mesesDisponibles() {
  const set = new Set(STATE.datos.map(d => String(d.Mes)));
  set.add(currentMonthValue());
  return Array.from(set).sort();
}

// ---------------- tabs ----------------
function initTabs() {
  $all('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      $all('.tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      $all('.view').forEach(v => v.classList.add('hidden'));
      $('#view-' + btn.dataset.tab).classList.remove('hidden');
      if (btn.dataset.tab === 'dashboard') renderDashboard();
      if (btn.dataset.tab === 'competencia') renderCompetencia();
      if (btn.dataset.tab === 'catalogo') renderCatalogo();
    });
  });
}

// ---------------- captura ----------------
function initCaptura() {
  $('#mesSelect').value = currentMonthValue();
  $('#mesSelect').addEventListener('change', renderCaptura);
  $('#btnGuardarMes').addEventListener('click', guardarMes);
  $('#btnCopyPrev').addEventListener('click', copiarMesAnterior);
  renderCaptura();
}

function renderCaptura() {
  const mes = $('#mesSelect').value || currentMonthValue();
  const wrap = $('#capturaGroups');
  wrap.innerHTML = '';

  RED_ORDER.forEach(red => {
    const cuentas = cuentasActivasPorRed(red);
    if (!cuentas.length) return;
    const fields = RED_FIELDS[red];

    const group = document.createElement('div');
    group.className = 'red-group';
    group.dataset.red = red;

    const head = document.createElement('div');
    head.className = 'red-group-head';
    head.innerHTML = `<span class="red-dot" style="background:${RED_COLORS[red]}"></span>
      <h3>${red}</h3><span class="count">${cuentas.length} cuentas</span>`;
    group.appendChild(head);

    const colTemplate = `1.4fr 100px repeat(${fields.length}, 100px)`;
    const fieldHeader = document.createElement('div');
    fieldHeader.className = 'field-header';
    fieldHeader.style.gridTemplateColumns = colTemplate;
    fieldHeader.innerHTML = `<span>Cuenta</span><span></span>` +
      fields.map(f => `<span>${f.label}</span>`).join('');
    group.appendChild(fieldHeader);

    cuentas.forEach(c => {
      const isPropia = c.Tipo === 'Propia';
      const dato = datoDe(mes, c.ID) || {};
      const row = document.createElement('div');
      row.className = 'account-row' + (isPropia ? ' propia' : '');
      row.style.gridTemplateColumns = colTemplate;
      row.dataset.cuentaId = c.ID;

      let html = `<div class="account-name">${c.Etiqueta}</div>
        <div><span class="pill ${isPropia ? 'propia' : 'competencia'}">${c.Tipo}</span></div>`;

      fields.forEach(f => {
        if (f.ownOnly && !isPropia) {
          html += `<div></div>`;
        } else {
          const val = dato[DATA_FIELD_MAP[f.key]];
          html += `<div><span class="field-label">${f.label}</span>
            <input type="number" inputmode="numeric" data-field="${f.key}"
              value="${val !== undefined && val !== '' ? val : ''}" placeholder="—" /></div>`;
        }
      });
      row.innerHTML = html;
      group.appendChild(row);
    });

    wrap.appendChild(group);
  });
}

function copiarMesAnterior() {
  const mes = $('#mesSelect').value || currentMonthValue();
  const anterior = prevMonthValue(mes);
  let copied = 0;
  $all('#capturaGroups .account-row').forEach(row => {
    const cuentaId = row.dataset.cuentaId;
    const dato = datoDe(anterior, cuentaId);
    if (!dato) return;
    row.querySelectorAll('input[data-field]').forEach(input => {
      const key = input.dataset.field;
      const val = dato[DATA_FIELD_MAP[key]];
      if (val !== undefined && val !== '' && !input.value) {
        input.value = val;
        copied++;
      }
    });
  });
  showToast(copied ? `Se copiaron ${copied} valores de ${monthLabel(anterior)}` : `No hay datos guardados para ${monthLabel(anterior)}`, !copied);
}

function guardarMes() {
  const mes = $('#mesSelect').value;
  if (!mes) { showToast('Elige un mes', true); return; }

  let count = 0;
  $all('#capturaGroups .account-row').forEach(row => {
    const cuentaId = Number(row.dataset.cuentaId);
    const entry = { Mes: mes, CuentaID: cuentaId };
    let hasValue = false;
    row.querySelectorAll('input[data-field]').forEach(input => {
      const key = input.dataset.field;
      const dbKey = DATA_FIELD_MAP[key];
      if (input.value !== '') hasValue = true;
      entry[dbKey] = input.value === '' ? '' : Number(input.value);
    });
    if (!hasValue) return;
    count++;

    const idx = STATE.datos.findIndex(d => String(d.Mes) === String(mes) && Number(d.CuentaID) === cuentaId);
    if (idx >= 0) {
      STATE.datos[idx] = Object.assign({}, STATE.datos[idx], entry);
    } else {
      entry.ActualizadoEn = new Date().toISOString();
      STATE.datos.push(entry);
    }
  });

  if (!count) { showToast('No hay datos para guardar', true); return; }

  persist();
  renderCaptura();
  $('#saveMsg').textContent = `Guardado ✓ (${count} cuentas, ${monthLabel(mes)})`;
  showToast('Mes guardado correctamente');
}

// ---------------- dashboard ----------------
function renderDashboard() {
  const meses = mesesDisponibles();
  const mesActual = meses[meses.length - 1];
  const mesAnterior = meses.length > 1 ? meses[meses.length - 2] : null;

  const propias = STATE.cuentas.filter(c => c.Tipo === 'Propia' && (c.Activo === true || c.Activo === 'TRUE'));
  const cofkiIG = propias.find(c => c.Red === 'Instagram' && c.Etiqueta === 'Cofki');

  const cards = $('#cardsPropias');
  cards.innerHTML = '';

  function addCard(label, actual, anterior) {
    const div = document.createElement('div');
    div.className = 'metric-card';
    const a = Number(actual) || 0;
    const b = Number(anterior) || 0;
    const diff = a - b;
    let cls = 'flat', arrow = '·';
    if (diff > 0) { cls = 'up'; arrow = '▲'; }
    if (diff < 0) { cls = 'down'; arrow = '▼'; }
    div.innerHTML = `<div class="label">${label}</div>
      <div class="value">${fmtNum(actual)}</div>
      <div class="delta ${cls}">${arrow} ${diff !== 0 ? fmtNum(Math.abs(diff)) : 'sin cambio'} vs. mes anterior</div>`;
    cards.appendChild(div);
  }

  if (cofkiIG) {
    const dAct = datoDe(mesActual, cofkiIG.ID) || {};
    const dAnt = mesAnterior ? (datoDe(mesAnterior, cofkiIG.ID) || {}) : {};
    addCard('Cofki · Seguidores IG', dAct.Seguidores, dAnt.Seguidores);
    addCard('Cofki · Interacciones IG', dAct.Interacciones, dAnt.Interacciones);
    addCard('Cofki · Visualizaciones IG', dAct.Visualizaciones, dAnt.Visualizaciones);
    addCard('Cofki · Alcance IG', dAct.Alcance, dAnt.Alcance);
  }
  const fbCofki = propias.find(c => c.Red === 'Facebook');
  if (fbCofki) {
    const dAct = datoDe(mesActual, fbCofki.ID) || {};
    const dAnt = mesAnterior ? (datoDe(mesAnterior, fbCofki.ID) || {}) : {};
    addCard('Cofki · Seguidores FB', dAct.Seguidores, dAnt.Seguidores);
  }
  const totalGoogle = propias.filter(c => c.Red === 'Google');
  if (totalGoogle.length) {
    let sumAct = 0, sumAnt = 0;
    totalGoogle.forEach(c => {
      sumAct += Number((datoDe(mesActual, c.ID) || {}).Comentarios) || 0;
      sumAnt += Number((mesAnterior ? (datoDe(mesAnterior, c.ID) || {}) : {}).Comentarios) || 0;
    });
    addCard('Comentarios Google (todas las sucursales)', sumAct, sumAnt);
  }

  renderPerBrandCharts(meses, propias.filter(c => c.Red === 'Instagram'));
  renderCofkiActivityCharts(meses, cofkiIG);
  renderChartFbTiktok(meses, propias.filter(c => c.Red === 'Facebook' || c.Red === 'TikTok'));
  renderChartGoogle(meses, propias.filter(c => c.Red === 'Google'));
}

function destroyChart(key) {
  if (CHARTS[key]) { CHARTS[key].destroy(); delete CHARTS[key]; }
}

function miniLineOptions() {
  const opts = baseLineOptions();
  opts.plugins.legend.display = false;
  return opts;
}

function renderPerBrandCharts(meses, cuentas) {
  Object.keys(CHARTS).filter(k => k.startsWith('brand_')).forEach(destroyChart);
  const wrap = $('#perBrandGrid');
  wrap.innerHTML = '';
  const palette = ['#00BFA5', '#FFA726', '#FF5252', '#424242', '#757575'];
  cuentas.forEach((c, i) => {
    const canvasId = 'brandChart_' + c.ID;
    const card = document.createElement('div');
    card.className = 'chart-card';
    card.innerHTML = `<div class="chart-card-head"><h3>${c.Etiqueta} · Seguidores IG</h3></div><canvas id="${canvasId}" height="220"></canvas>`;
    wrap.appendChild(card);
    const ctx = document.getElementById(canvasId);
    const color = palette[i % palette.length];
    CHARTS['brand_' + c.ID] = new Chart(ctx, {
      type: 'line',
      data: {
        labels: meses.map(monthLabel),
        datasets: [{
          label: c.Etiqueta,
          data: meses.map(m => (datoDe(m, c.ID) || {}).Seguidores ?? null),
          borderColor: color,
          backgroundColor: color,
          tension: 0.3,
          spanGaps: true
        }]
      },
      options: miniLineOptions()
    });
  });
}

function renderCofkiActivityCharts(meses, cofkiIG) {
  ['Interacciones', 'Visualizaciones', 'Alcance'].forEach(k => destroyChart('cofkiAct_' + k));
  const wrap = $('#cofkiActivityGrid');
  wrap.innerHTML = '';
  if (!cofkiIG) return;
  const metrics = [
    { key: 'Interacciones', label: 'Interacciones', color: '#00BFA5' },
    { key: 'Visualizaciones', label: 'Visualizaciones', color: '#FFA726' },
    { key: 'Alcance', label: 'Alcance', color: '#FF5252' }
  ];
  metrics.forEach(m => {
    const canvasId = 'cofkiActChart_' + m.key;
    const card = document.createElement('div');
    card.className = 'chart-card';
    card.innerHTML = `<div class="chart-card-head"><h3>${m.label}</h3></div><canvas id="${canvasId}" height="220"></canvas>`;
    wrap.appendChild(card);
    const ctx = document.getElementById(canvasId);
    CHARTS['cofkiAct_' + m.key] = new Chart(ctx, {
      type: 'line',
      data: {
        labels: meses.map(monthLabel),
        datasets: [{
          label: m.label,
          data: meses.map(mm => (datoDe(mm, cofkiIG.ID) || {})[m.key] ?? null),
          borderColor: m.color,
          backgroundColor: m.color,
          tension: 0.3,
          spanGaps: true
        }]
      },
      options: miniLineOptions()
    });
  });
}

function renderChartFbTiktok(meses, cuentas) {
  destroyChart('fbTiktok');
  const ctx = $('#chartFbTiktok');
  const palette = ['#00BFA5', '#424242'];
  const datasets = cuentas.map((c, i) => ({
    label: c.Red + ' · ' + c.Etiqueta,
    data: meses.map(m => (datoDe(m, c.ID) || {}).Seguidores ?? null),
    borderColor: palette[i % palette.length],
    backgroundColor: palette[i % palette.length],
    tension: 0.3,
    spanGaps: true
  }));
  CHARTS.fbTiktok = new Chart(ctx, {
    type: 'line',
    data: { labels: meses.map(monthLabel), datasets },
    options: baseLineOptions()
  });
}

function renderChartGoogle(meses, cuentas) {
  destroyChart('google');
  const ctx = $('#chartGoogle');
  const palette = ['#FF5252', '#FFA726', '#00BFA5'];
  const datasets = cuentas.map((c, i) => ({
    label: c.Etiqueta,
    data: meses.map(m => (datoDe(m, c.ID) || {}).Comentarios ?? null),
    borderColor: palette[i % palette.length],
    backgroundColor: palette[i % palette.length],
    tension: 0.3,
    spanGaps: true
  }));
  CHARTS.google = new Chart(ctx, {
    type: 'line',
    data: { labels: meses.map(monthLabel), datasets },
    options: baseLineOptions()
  });
}

function baseLineOptions() {
  return {
    responsive: true,
    interaction: { mode: 'index', intersect: false },
    plugins: {
      legend: { position: 'bottom', labels: { font: { family: 'Montserrat', size: 11 }, boxWidth: 10 } }
    },
    scales: {
      x: { grid: { display: false }, ticks: { font: { family: 'Montserrat', size: 11 } } },
      y: { grid: { color: 'rgba(66,66,66,0.08)' }, ticks: { font: { family: 'Montserrat', size: 11 } } }
    }
  };
}

// ---------------- competencia ----------------
function initCompetencia() {
  $('#mesCompSelect').addEventListener('change', renderCompetencia);
}

function yoyMonthValue(mes) {
  const [y, m] = mes.split('-').map(Number);
  return (y - 1) + '-' + String(m).padStart(2, '0');
}

function renderCompetencia() {
  const meses = mesesDisponibles();
  if (!meses.length) return;
  const select = $('#mesCompSelect');
  if (!select.value) select.value = meses[meses.length - 1];
  const mes = select.value;
  const anterior = prevMonthValue(mes);
  const anioAnterior = yoyMonthValue(mes);

  const cuentas = cuentasActivasPorRed('Instagram');
  const rows = cuentas.map(c => {
    const act = Number((datoDe(mes, c.ID) || {}).Seguidores);
    const ant = Number((datoDe(anterior, c.ID) || {}).Seguidores);
    const anioAct = Number((datoDe(anioAnterior, c.ID) || {}).Seguidores);
    const hasBothMes = !isNaN(act) && !isNaN(ant) && ant > 0;
    const hasBothAnio = !isNaN(act) && !isNaN(anioAct) && anioAct > 0;
    return {
      etiqueta: c.Etiqueta,
      tipo: c.Tipo,
      act: isNaN(act) ? null : act,
      ant: isNaN(ant) ? null : ant,
      diff: hasBothMes ? act - ant : null,
      pct: hasBothMes ? ((act - ant) / ant) * 100 : null,
      anioAct: isNaN(anioAct) ? null : anioAct,
      diffAnio: hasBothAnio ? act - anioAct : null,
      pctAnio: hasBothAnio ? ((act - anioAct) / anioAct) * 100 : null
    };
  }).filter(r => r.act !== null || r.ant !== null);

  // ordenado por número de seguidores actuales (mayor a menor)
  rows.sort((a, b) => (b.act ?? -Infinity) - (a.act ?? -Infinity));

  const tbody = $('#tablaCompetencia tbody');
  tbody.innerHTML = rows.map(r => `
    <tr class="${r.tipo === 'Propia' ? 'propia-row' : ''}">
      <td>${r.etiqueta}</td>
      <td><span class="pill ${r.tipo === 'Propia' ? 'propia' : 'competencia'}">${r.tipo}</span></td>
      <td class="num">${fmtNum(r.act)}</td>
      <td class="num">${fmtNum(r.ant)}</td>
      <td class="num ${r.diff > 0 ? 'up' : r.diff < 0 ? 'down' : ''}">${r.diff === null ? '—' : (r.diff > 0 ? '+' : '') + fmtNum(r.diff)}</td>
      <td class="num ${r.pct > 0 ? 'up' : r.pct < 0 ? 'down' : ''}">${r.pct === null ? '—' : (r.pct > 0 ? '+' : '') + r.pct.toFixed(1) + '%'}</td>
      <td class="num">${fmtNum(r.anioAct)}</td>
      <td class="num ${r.diffAnio > 0 ? 'up' : r.diffAnio < 0 ? 'down' : ''}">${r.diffAnio === null ? '—' : (r.diffAnio > 0 ? '+' : '') + fmtNum(r.diffAnio)}</td>
      <td class="num ${r.pctAnio > 0 ? 'up' : r.pctAnio < 0 ? 'down' : ''}">${r.pctAnio === null ? '—' : (r.pctAnio > 0 ? '+' : '') + r.pctAnio.toFixed(1) + '%'}</td>
    </tr>`).join('');

  // la gráfica de barras sí se ordena por % de crecimiento mensual (para resaltar quién crece más rápido)
  destroyChart('competencia');
  const ctx = $('#chartCompetencia');
  const chartRows = rows.filter(r => r.pct !== null).slice().sort((a, b) => b.pct - a.pct).slice(0, 25);
  CHARTS.competencia = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: chartRows.map(r => r.etiqueta),
      datasets: [{
        label: '% crecimiento de seguidores',
        data: chartRows.map(r => Number(r.pct.toFixed(1))),
        backgroundColor: chartRows.map(r => r.tipo === 'Propia' ? '#FFA726' : (r.pct >= 0 ? '#00BFA5' : '#FF5252'))
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      plugins: { legend: { display: false } },
      scales: {
        x: { grid: { color: 'rgba(66,66,66,0.08)' }, ticks: { font: { family: 'Montserrat', size: 11 } } },
        y: { grid: { display: false }, ticks: { font: { family: 'Montserrat', size: 11 } } }
      }
    }
  });
}

function renderCatalogo() {
  const wrap = $('#catalogoGroups');
  wrap.innerHTML = '';
  RED_ORDER.forEach(red => {
    const cuentas = STATE.cuentas.filter(c => c.Red === red)
      .sort((a, b) => Number(b.Activo) - Number(a.Activo) || String(a.Etiqueta).localeCompare(String(b.Etiqueta)));
    if (!cuentas.length) return;

    const group = document.createElement('div');
    group.className = 'red-group';

    const head = document.createElement('div');
    head.className = 'red-group-head';
    head.innerHTML = `<span class="red-dot" style="background:${RED_COLORS[red]}"></span>
      <h3>${red}</h3><span class="count">${cuentas.length} cuentas</span>`;
    group.appendChild(head);

    cuentas.forEach(c => {
      const isActive = c.Activo === true || c.Activo === 'TRUE';
      const row = document.createElement('div');
      row.className = 'cat-row' + (isActive ? '' : ' inactive');
      row.innerHTML = `
        <input data-cat="cuenta" value="${c.Cuenta}" />
        <input data-cat="etiqueta" value="${c.Etiqueta}" />
        <select data-cat="tipo">
          <option value="Propia" ${c.Tipo === 'Propia' ? 'selected' : ''}>Propia</option>
          <option value="Competencia" ${c.Tipo === 'Competencia' ? 'selected' : ''}>Competencia</option>
        </select>
        <button class="btn small ghost" data-action="save">Guardar</button>
        <button class="btn small ${isActive ? 'danger' : 'primary'}" data-action="toggle">${isActive ? 'Desactivar' : 'Activar'}</button>
      `;
      row.querySelector('[data-action="save"]').addEventListener('click', () => {
        const cuenta = row.querySelector('[data-cat="cuenta"]').value.trim();
        const etiqueta = row.querySelector('[data-cat="etiqueta"]').value.trim();
        const tipo = row.querySelector('[data-cat="tipo"]').value;
        const idx = STATE.cuentas.findIndex(x => x.ID === c.ID);
        if (idx >= 0) {
          STATE.cuentas[idx] = Object.assign({}, STATE.cuentas[idx], { Cuenta: cuenta, Etiqueta: etiqueta, Tipo: tipo });
          persist();
          renderCatalogo();
          showToast('Cuenta actualizada');
        }
      });
      row.querySelector('[data-action="toggle"]').addEventListener('click', () => {
        const idx = STATE.cuentas.findIndex(x => x.ID === c.ID);
        if (idx >= 0) {
          STATE.cuentas[idx].Activo = !isActive;
          persist();
          renderCatalogo();
          showToast(isActive ? 'Cuenta desactivada' : 'Cuenta activada');
        }
      });
      group.appendChild(row);
    });

    wrap.appendChild(group);
  });
}

function initCatalogo() {
  $('#btnAddCuenta').addEventListener('click', () => {
    const red = $('#nuevaRed').value;
    const cuenta = $('#nuevaCuenta').value.trim();
    const etiqueta = $('#nuevaEtiqueta').value.trim();
    const tipo = $('#nuevoTipo').value;
    if (!cuenta || !etiqueta) { showToast('Falta usuario o nombre para mostrar', true); return; }
    const maxId = STATE.cuentas.reduce((m, c) => Math.max(m, Number(c.ID) || 0), 0);
    STATE.cuentas.push({ ID: maxId + 1, Red: red, Cuenta: cuenta, Etiqueta: etiqueta, Tipo: tipo, Activo: true });
    persist();
    $('#nuevaCuenta').value = '';
    $('#nuevaEtiqueta').value = '';
    renderCatalogo();
    showToast('Cuenta agregada');
  });
}

// ---------------- respaldo (export / import) ----------------
function exportarRespaldo() {
  const blob = new Blob([JSON.stringify({ cuentas: STATE.cuentas, datos: STATE.datos }, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  const fecha = new Date().toISOString().slice(0, 10);
  a.href = url;
  a.download = `reporte-redes-respaldo-${fecha}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  showToast('Respaldo descargado');
}

function importarRespaldo(file) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const parsed = JSON.parse(reader.result);
      if (!Array.isArray(parsed.cuentas) || !Array.isArray(parsed.datos)) throw new Error('Formato inválido');
      STATE.cuentas = parsed.cuentas;
      STATE.datos = parsed.datos;
      persist();
      renderCaptura();
      showToast(`Respaldo importado (${parsed.cuentas.length} cuentas, ${parsed.datos.length} registros)`);
    } catch (err) {
      showToast('No se pudo leer el archivo: ' + err.message, true);
    }
  };
  reader.readAsText(file);
}

function initRespaldo() {
  $('#btnExportar').addEventListener('click', exportarRespaldo);
  $('#inputImportar').addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) importarRespaldo(file);
    e.target.value = '';
  });
}

// ---------------- exportar a PDF ----------------
async function exportarPDF(sectionId, filename, btn) {
  const el = document.getElementById(sectionId);
  const originalText = btn.textContent;
  btn.disabled = true;
  btn.textContent = 'Generando PDF…';
  try {
    const canvas = await html2canvas(el, { scale: 2, backgroundColor: '#FBFAF7', useCORS: true });
    const { jsPDF } = window.jspdf;
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const imgWidth = pageWidth;
    const imgHeight = (canvas.height * imgWidth) / canvas.width;
    const imgData = canvas.toDataURL('image/png');

    let heightLeft = imgHeight;
    let position = 0;
    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;
    while (heightLeft > 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }
    pdf.save(filename);
    showToast('PDF descargado');
  } catch (err) {
    showToast('No se pudo generar el PDF: ' + err.message, true);
  } finally {
    btn.disabled = false;
    btn.textContent = originalText;
  }
}

function initPDF() {
  $('#btnPdfDashboard').addEventListener('click', (e) => {
    const fecha = new Date().toISOString().slice(0, 10);
    exportarPDF('view-dashboard', `cofki-nuestro-crecimiento-${fecha}.pdf`, e.currentTarget);
  });
  $('#btnPdfCompetencia').addEventListener('click', (e) => {
    const mes = $('#mesCompSelect').value || currentMonthValue();
    exportarPDF('view-competencia', `cofki-vs-competencia-${mes}.pdf`, e.currentTarget);
  });
}

// ---------------- boot ----------------
function boot() {
  loadState();
  initTabs();
  initCompetencia();
  initCatalogo();
  initRespaldo();
  initPDF();
  initCaptura();
  setStatus('Guardado en este navegador', 'ok');
}

boot();

/* ============================================================
   COFKI CHECKLIST OPERATIVO — Frontend logic (v3)
   3 niveles: piso (sin login), líder (lectura 3 sucursales),
   dirección/admin (todo + aprobación remota de respaldo)
   ============================================================ */

const STORAGE_KEYS = {
  TOKEN: 'cofki_token', USER: 'cofki_user',
  GUEST_SUC: 'cofki_guest_sucursal', GUEST_NOMBRE: 'cofki_guest_nombre',
  BOOT_CACHE: 'cofki_boot_cache'
};
const el = (id) => document.getElementById(id);
const todayISO = () => new Date().toISOString().slice(0, 10);

const EVIDENCIA_LABELS = {
  cocina: 'Cocina', refrigeradores: 'Refrigeradores', barra: 'Barra',
  salon: 'Salón', banos: 'Baños', exterior: 'Exterior / limpieza'
};

// ---------- estado global ----------
let APP_MODE = null; // 'guest' | 'auth'
let AUTH = { token: null, user: null };
let GUEST = { sucursal_id: null, nombre: '' };
let BOOT = { sucursales: [], areas: [] };
let viewStack = [];
let current = { view: null, params: null };

// ---------- toast / modal ----------
function showToast(msg) {
  const t = el('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2400);
}
function showModal(html) {
  el('modal-box').innerHTML = html;
  el('modal-overlay').classList.add('show');
}
function hideModal() { el('modal-overlay').classList.remove('show'); }
el('modal-overlay').addEventListener('click', (e) => { if (e.target.id === 'modal-overlay') hideModal(); });

// ---------- API ----------
async function api(action, data) {
  data = data || {};
  data.action = action;
  if (APP_MODE === 'auth') data.token = data.token || AUTH.token;
  const res = await fetch(COFKI_CONFIG.API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
    body: JSON.stringify(data)
  });
  if (!res.ok) throw new Error('Error de red (' + res.status + ')');
  return res.json();
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function takePhoto() {
  return new Promise((resolve, reject) => {
    const input = el('file-input');
    input.value = '';
    input.onchange = async () => {
      const file = input.files[0];
      if (!file) { reject(new Error('cancelado')); return; }
      try {
        const base64 = await fileToBase64(file);
        resolve({ base64, filename: file.name, mimeType: file.type || 'image/jpeg' });
      } catch (e) { reject(e); }
    };
    input.click();
  });
}

// ---------- boot cache (sucursales/areas — no cambian seguido) ----------
function getCachedBoot() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.BOOT_CACHE);
    if (!raw) return null;
    const obj = JSON.parse(raw);
    return (obj && obj.sucursales && obj.areas) ? obj : null;
  } catch (e) { return null; }
}
function cacheBoot() {
  try { localStorage.setItem(STORAGE_KEYS.BOOT_CACHE, JSON.stringify({ sucursales: BOOT.sucursales, areas: BOOT.areas })); } catch (e) {}
}
async function ensureBootPublico() {
  if (BOOT.sucursales && BOOT.sucursales.length) return;
  try {
    const r = await api('bootPublico', {});
    if (r.ok) { BOOT.sucursales = r.sucursales; BOOT.areas = r.areas; cacheBoot(); }
  } catch (e) {}
}

// ---------- sesión (líder / admin) ----------
function getToken() { return localStorage.getItem(STORAGE_KEYS.TOKEN); }
function getUser() { try { return JSON.parse(localStorage.getItem(STORAGE_KEYS.USER)); } catch (e) { return null; } }
function saveSession(token, user) {
  localStorage.setItem(STORAGE_KEYS.TOKEN, token);
  localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  AUTH.token = token; AUTH.user = user;
}
function clearSession() {
  localStorage.removeItem(STORAGE_KEYS.TOKEN);
  localStorage.removeItem(STORAGE_KEYS.USER);
  AUTH = { token: null, user: null };
}

// ---------- pantallas de nivel superior ----------
function hideAllScreens() {
  ['loading', 'mode-screen', 'sucursal-picker-screen', 'login-screen', 'app-screen'].forEach((id) => { el(id).style.display = 'none'; });
}
function showMode() { hideAllScreens(); el('mode-screen').style.display = 'flex'; }
function showLogin() { hideAllScreens(); el('login-screen').style.display = 'flex'; el('login-error').style.display = 'none'; }
async function showSucursalPicker() {
  await ensureBootPublico();
  hideAllScreens();
  el('sucursal-picker-screen').style.display = 'flex';
  const list = el('sucursal-picker-list');
  list.innerHTML = BOOT.sucursales.map((s) => `
    <div class="picker-item" data-suc="${s.id}">
      <span class="name">${escapeHtml_(s.nombre)}</span>
      <span class="code">${escapeHtml_(s.codigo)}</span>
    </div>`).join('');
  list.querySelectorAll('[data-suc]').forEach((item) => item.addEventListener('click', () => {
    const sucId = item.dataset.suc;
    localStorage.setItem(STORAGE_KEYS.GUEST_SUC, sucId);
    GUEST.sucursal_id = sucId;
    GUEST.nombre = localStorage.getItem(STORAGE_KEYS.GUEST_NOMBRE) || '';
    showApp('guest');
  }));
}
function showApp(mode) {
  APP_MODE = mode;
  hideAllScreens();
  el('app-screen').style.display = 'flex';
  el('bottom-nav').style.display = mode === 'guest' ? 'none' : 'flex';
  el('logout-btn').textContent = mode === 'guest' ? '↺' : '⏻';
  el('logout-btn').title = mode === 'guest' ? 'Cambiar sucursal' : 'Cerrar sesión';
  goTo('home', {}, { replace: true, resetStack: true });
}

// ---------- boot ----------
async function boot() {
  const cached = getCachedBoot();
  if (cached) BOOT = cached;

  const guestSuc = localStorage.getItem(STORAGE_KEYS.GUEST_SUC);
  if (guestSuc) {
    GUEST.sucursal_id = guestSuc;
    GUEST.nombre = localStorage.getItem(STORAGE_KEYS.GUEST_NOMBRE) || '';
    await ensureBootPublico();
    showApp('guest');
    return;
  }

  const token = getToken();
  if (token) {
    AUTH.token = token;
    try {
      const r = await api('bootSesion', { token });
      if (r.ok) {
        saveSession(token, r.user);
        BOOT.sucursales = r.sucursales; BOOT.areas = r.areas; cacheBoot();
        showApp('auth');
        return;
      }
      clearSession();
    } catch (e) {
      const cachedUser = getUser();
      if (cachedUser) { AUTH.user = cachedUser; showApp('auth'); showToast('Sin conexión — mostrando última sesión guardada'); return; }
      clearSession();
    }
  }

  showMode();
}

el('mode-piso-btn').addEventListener('click', showSucursalPicker);
el('mode-login-btn').addEventListener('click', showLogin);
el('picker-back-btn').addEventListener('click', showMode);
el('login-back-btn').addEventListener('click', showMode);

el('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const usuario = el('usuario').value.trim();
  const password = el('password').value;
  const btn = el('login-btn');
  const errBox = el('login-error');
  errBox.style.display = 'none';
  btn.disabled = true; btn.textContent = 'Entrando…';
  APP_MODE = 'auth';
  try {
    const r = await api('login', { usuario, password });
    if (r.ok) {
      saveSession(r.token, r.user);
      BOOT.sucursales = r.sucursales; BOOT.areas = r.areas; cacheBoot();
      showApp('auth');
    } else { errBox.textContent = r.error || 'No se pudo iniciar sesión'; errBox.style.display = 'block'; }
  } catch (err) { errBox.textContent = 'No hay conexión con el servidor.'; errBox.style.display = 'block'; }
  finally { btn.disabled = false; btn.textContent = 'Entrar'; }
});

el('logout-btn').addEventListener('click', async () => {
  if (APP_MODE === 'guest') {
    localStorage.removeItem(STORAGE_KEYS.GUEST_SUC);
    GUEST = { sucursal_id: null, nombre: '' };
    showMode();
    return;
  }
  const token = getToken();
  clearSession();
  showMode();
  try { await api('logout', { token }); } catch (e) {}
});

el('back-btn').addEventListener('click', goBack);

document.querySelectorAll('.bottom-nav button[data-tab]').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.bottom-nav button').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    const tab = btn.dataset.tab;
    if (tab === 'dashboard') goTo('home', {}, { replace: true, resetStack: true });
    if (tab === 'historico') goTo('historico', {}, { replace: true, resetStack: true });
    if (tab === 'perfil') goTo('perfil', {}, { replace: true, resetStack: true });
  });
});

// ---------- router ----------
function goTo(view, params, opts) {
  opts = opts || {};
  if (opts.resetStack) viewStack = [];
  else if (current.view) viewStack.push(current);
  current = { view, params: params || {} };
  render();
}
function goBack() {
  const prev = viewStack.pop();
  if (prev) { current = prev; render(); }
  else goTo('home', {}, { replace: true, resetStack: true });
}
function setTopbar(title, subtitle, showBack) {
  el('topbar-title').textContent = title;
  el('topbar-subtitle').textContent = subtitle || '';
  el('back-btn').style.display = showBack ? 'flex' : 'none';
}

function render() {
  const main = el('main-content');
  main.innerHTML = '<div style="display:flex;justify-content:center;padding:60px 0;"><div class="spinner"></div></div>';
  const fn = {
    home: renderHome,
    dashboardHoy: renderDashboardHoy,
    sucursalDetalle: renderSucursalDetalle,
    checklist: renderChecklist,
    caja: renderCaja,
    validarSitio: renderValidarSitio,
    validarCajaSitio: renderValidarCajaSitio,
    aprobacion: renderAprobacion,
    aprobacionCaja: renderAprobacionCaja,
    pendientes: renderPendientes,
    historico: renderHistorico,
    perfil: renderPerfil,
    usuarios: renderUsuarios
  }[current.view];
  if (!fn) { main.innerHTML = errorBlock_('Vista no encontrada'); return; }
  fn(current.params);
}

function errorBlock_(msg) { return '<div class="error-box" style="display:block;">' + escapeHtml_(msg || 'Ocurrió un error') + '</div>'; }
function escapeHtml_(str) { const d = document.createElement('div'); d.textContent = str == null ? '' : String(str); return d.innerHTML; }
function roleLabel(rol) { return { admin: 'Dirección', lider: 'Líder' }[rol] || rol; }
function sucursalNombre(id) { return (BOOT.sucursales.filter((s) => s.id === id)[0] || {}).nombre || id; }
function areaNombre(id) { return (BOOT.areas.filter((a) => a.id === id)[0] || {}).nombre || id; }
function estadoEmoji(estado) { return { completo: '🟢', pendiente: '🟡', incidencia: '🔴', no_iniciado: '⚪' }[estado] || '⚪'; }
function statusChip(estado) {
  const labels = { completo: 'Completo', en_progreso: 'En progreso', pendiente: 'Pendiente', incidencia: 'Incidencia', no_iniciado: 'No iniciado' };
  return '<span class="status-chip status-' + estado + '">' + (labels[estado] || estado) + '</span>';
}
function guestNombre_() {
  if (APP_MODE !== 'guest') return undefined;
  return (checklistState && checklistState.nombreCaptura) || (cajaState && cajaState.nombreCaptura) || GUEST.nombre || '';
}

// ============================================================
// HOME (según modo/rol)
// ============================================================
async function renderHome() {
  if (APP_MODE === 'guest') return renderGuestBoard();
  return renderDashboardHoy();
}

// ============================================================
// PISO — sucursal elegida, sin login
// ============================================================
async function renderGuestBoard() {
  setTopbar(sucursalNombre(GUEST.sucursal_id), 'Hoy', false);
  const main = el('main-content');
  try {
    const r = await api('getSucursalDetalle', { sucursal_id: GUEST.sucursal_id, fecha: todayISO() });
    if (!r.ok) { main.innerHTML = errorBlock_(r.error); return; }

    let html = '<div class="section-sub">Toca Apertura o Cierre para llenar el checklist</div>';
    r.areas.forEach((a) => {
      const esCajaCierre = a.area_id === 'AREA-CAJA';
      html += `<div class="area-card">
        <div class="area-card-header"><span class="area-card-title">${escapeHtml_(a.area_nombre)}</span></div>
        <div class="area-buttons">
          ${areaBtnHtml(a.apertura, 'Apertura', `goTo('checklist', {sucursal_id:'${GUEST.sucursal_id}', area_id:'${a.area_id}', tipo:'apertura'})`)}
          ${areaBtnHtml(a.cierre, 'Cierre', esCajaCierre ? `goTo('caja', {sucursal_id:'${GUEST.sucursal_id}'})` : `goTo('checklist', {sucursal_id:'${GUEST.sucursal_id}', area_id:'${a.area_id}', tipo:'cierre'})`)}
        </div>
      </div>`;
    });

    main.innerHTML = html;
    main.querySelectorAll('.area-btn').forEach((btn) => btn.addEventListener('click', () => eval(btn.dataset.action)));
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

function areaBtnHtml(estadoObj, label, action) {
  const cls = estadoObj.estado === 'completo' ? 'state-completo' : estadoObj.estado === 'incidencia' ? 'state-incidencia' : estadoObj.estado === 'en_progreso' ? 'state-en_progreso' : '';
  const icon = estadoObj.aprobado ? ' 🔒' : (estadoObj.enviado ? ' ⏳' : '');
  return `<div class="area-btn ${cls}" data-action="${escapeHtml_(action)}">
    <div class="lbl">${label}${icon}</div>
    <div class="pct">${estadoObj.pct}%</div>
  </div>`;
}

// Para líder/admin: en vez de "entrar a llenar", resuelve el respuesta_id
// existente (si lo hay) y abre la pantalla de revisión de solo lectura.
async function resolveVerChecklist(sucursalId, areaId, tipo) {
  if (areaId === 'AREA-CAJA' && tipo === 'cierre') { goTo('aprobacionCaja', { sucursal_id: sucursalId, fecha: todayISO() }); return; }
  try {
    const r = await api('getSucursalDetalle', { sucursal_id: sucursalId, fecha: todayISO() });
    if (!r.ok) { showToast(r.error); return; }
    const area = r.areas.filter((a) => a.area_id === areaId)[0];
    const slot = area ? (tipo === 'apertura' ? area.apertura : area.cierre) : null;
    if (slot && slot.respuesta_id) goTo('aprobacion', { respuesta_id: slot.respuesta_id });
    else showToast('Ese checklist todavía no se ha iniciado.');
  } catch (e) { showToast('Sin conexión.'); }
}

// ============================================================
// DIRECCIÓN / LÍDER — Operación de hoy (las 3 sucursales)
// ============================================================
async function renderDashboardHoy() {
  setTopbar('COFKI — Operación de hoy', formatDateLong_(todayISO()), false);
  const main = el('main-content');
  try {
    const r = await api('getDashboardHoy', { fecha: todayISO() });
    if (!r.ok) { main.innerHTML = errorBlock_(r.error); return; }

    let html = '<div class="section-title">Las 3 sucursales</div><div class="suc-grid">';
    r.sucursales.forEach((s) => {
      html += `<div class="suc-card" data-goto="sucursalDetalle" data-sucursal="${s.sucursal_id}">
        <div class="suc-header">
          <span class="suc-name">${estadoEmoji(s.estado)} ${escapeHtml_(s.sucursal_nombre)}</span>
          <span class="suc-code">${escapeHtml_(s.sucursal_codigo)}</span>
        </div>
        <div class="metric-row">
          <div class="metric"><div class="num">${s.apertura_pct}%</div><div class="lbl">Apertura</div></div>
          <div class="metric"><div class="num">${s.cierre_pct}%</div><div class="lbl">Cierre</div></div>
          <div class="metric"><div class="num">${s.general_pct}%</div><div class="lbl">General</div></div>
        </div>
      </div>`;
    });
    html += '</div>';

    html += '<div class="section-title">Requiere atención</div>';
    if (r.atencion.length === 0) {
      html += '<div class="atencion-empty">🎉 Nada pendiente por ahora.</div>';
    } else {
      r.atencion.forEach((a, idx) => {
        html += `<div class="atencion-item" data-atencion="${idx}"><span class="txt">${escapeHtml_(a.texto)}</span><span class="chev">›</span></div>`;
      });
    }

    main.innerHTML = html;
    main.querySelectorAll('[data-goto="sucursalDetalle"]').forEach((c) => c.addEventListener('click', () => goTo('sucursalDetalle', { sucursal_id: c.dataset.sucursal })));
    main.querySelectorAll('[data-atencion]').forEach((c) => c.addEventListener('click', () => {
      const item = r.atencion[Number(c.dataset.atencion)];
      if (!item || !item.target) return;
      const t = item.target;
      if (t.view === 'caja') goTo('aprobacionCaja', { sucursal_id: t.sucursal_id, fecha: todayISO() });
      else if (t.view === 'checklist') resolveVerChecklist(t.sucursal_id, t.area_id, t.tipo);
    }));
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

function formatDateLong_(iso) {
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long' });
}

// ============================================================
// SUCURSAL DETALLE (drill-down líder / admin)
// ============================================================
async function renderSucursalDetalle(params) {
  const sucursalId = params.sucursal_id;
  setTopbar(sucursalNombre(sucursalId), 'Áreas de hoy', true);
  const main = el('main-content');
  try {
    const r = await api('getSucursalDetalle', { sucursal_id: sucursalId, fecha: todayISO() });
    if (!r.ok) { main.innerHTML = errorBlock_(r.error); return; }

    let html = '';
    r.areas.forEach((a) => {
      html += `<div class="area-card">
        <div class="area-card-header"><span class="area-card-title">${escapeHtml_(a.area_nombre)}</span></div>
        <div class="area-buttons">
          ${areaBtnHtml(a.apertura, 'Apertura', `resolveVerChecklist('${sucursalId}','${a.area_id}','apertura')`)}
          ${areaBtnHtml(a.cierre, 'Cierre', `resolveVerChecklist('${sucursalId}','${a.area_id}','cierre')`)}
        </div>
      </div>`;
    });

    html += '<div class="section-title">Caja</div>';
    const cajaEstadoTxt = { sin_diferencia: '✅ Sin diferencia', diferencia_reportada: '🔴 Diferencia reportada', pendiente: '⚪ Pendiente' }[r.caja.estado] || 'Pendiente';
    html += `<div class="area-card" data-goto="caja">
      <div class="area-card-header"><span class="area-card-title">${cajaEstadoTxt}</span>${r.caja.aprobado ? '<span class="status-chip status-completo">Validado</span>' : ''}</div>
      <div class="section-sub" style="margin:0;">Evidencias cargadas: ${r.caja.evidencias || 0}</div>
    </div>`;

    html += '<div class="section-title">Inventario diario</div>';
    const invTxt = r.inventario.enviado === null ? '⚪ Aún no reportado' : (r.inventario.enviado ? '✅ Enviado' : '🔴 No enviado — ' + escapeHtml_(r.inventario.motivo || 'sin motivo'));
    html += `<div class="area-card"><div class="area-card-title">${invTxt}</div></div>`;

    main.innerHTML = html;
    main.querySelectorAll('.area-btn').forEach((btn) => btn.addEventListener('click', () => eval(btn.dataset.action)));
    const cajaCard = main.querySelector('[data-goto="caja"]');
    if (cajaCard) cajaCard.addEventListener('click', () => goTo('aprobacionCaja', { sucursal_id: sucursalId, fecha: todayISO() }));
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

// ============================================================
// CHECKLIST — llenar (piso) / revisar (líder-admin vía aprobacion)
// ============================================================
let checklistState = null;

async function renderChecklist(params) {
  const { sucursal_id, area_id, tipo } = params;
  setTopbar(areaNombre(area_id), (tipo === 'apertura' ? 'Apertura' : 'Cierre') + ' — ' + sucursalNombre(sucursal_id), true);
  const main = el('main-content');
  try {
    const r = await api('getOrCreateRespuesta', { sucursal_id, area_id, tipo, fecha: todayISO(), nombre: GUEST.nombre || undefined });
    if (!r.ok) { main.innerHTML = errorBlock_(r.error); return; }

    const sucursal = BOOT.sucursales.filter((s) => s.id === sucursal_id)[0] || {};
    const itemEstadoMap = {};
    r.itemsEstado.forEach((ri) => { itemEstadoMap[ri.item_id] = ri; });
    const fotosByTag = {};
    r.fotos.forEach((f) => { fotosByTag[f.tipo_evidencia] = f.drive_url; });

    checklistState = {
      respuesta: r.respuesta, sucursal_id, area_id, tipo, sucursal,
      items: r.items, itemEstado: itemEstadoMap, fotosByTag,
      nombreCaptura: r.respuesta.capturado_por_nombre || GUEST.nombre || '',
      esAuroraMedidor: area_id === 'AREA-SERV' && tipo === 'apertura' && sucursal.codigo === 'AURORA',
      esInventario: area_id === 'AREA-SERV' && tipo === 'cierre',
      medidor: { lectura: r.respuesta.medidor_lectura || '', fotoUrl: r.respuesta.medidor_foto_url || '', anterior: null },
      inventario: { enviado: typeof r.respuesta.inventario_enviado === 'boolean' ? r.respuesta.inventario_enviado : null, motivo: r.respuesta.inventario_motivo || '' }
    };

    if (checklistState.esAuroraMedidor) {
      const lr = await api('getLecturaAnterior', { sucursal_id });
      if (lr.ok) checklistState.medidor.anterior = lr.anterior;
    }

    if (r.respuesta.enviado && !r.respuesta.aprobado) { renderEsperandoValidacion_(); return; }

    const interactive = APP_MODE === 'guest' && r.respuesta.aprobado !== true;
    renderChecklistBody_(interactive);
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

function renderEsperandoValidacion_() {
  const s = checklistState;
  const main = el('main-content');
  main.innerHTML = `
    <div class="validar-summary">
      <div class="big-pct">${s.respuesta.pct}%</div>
      <div class="section-sub" style="margin:6px 0 0;">Enviado por ${escapeHtml_(s.respuesta.capturado_por_nombre || 'alguien del equipo')}</div>
    </div>
    ${s.respuesta.devuelto ? `<div class="devuelto-banner">🔴 ${escapeHtml_(s.respuesta.motivo_devolucion || '')}</div>` : ''}
    <div class="placeholder-card">
      <div class="big">📝</div>
      Este checklist ya se envió y está esperando que el encargado o subgerente en turno lo revise y lo valide.
    </div>
    ${APP_MODE === 'guest' ? '<button class="btn btn-primary" id="ir-validar-btn" style="margin-top:16px;">Soy el encargado — revisar y validar</button>' : ''}
  `;
  const btn = el('ir-validar-btn');
  if (btn) btn.addEventListener('click', () => goTo('validarSitio', { respuesta_id: s.respuesta.id }));
}

function renderChecklistBody_(interactive) {
  const s = checklistState;
  const main = el('main-content');
  let html = '';

  if (s.respuesta.devuelto) html += `<div class="devuelto-banner">🔴 Este checklist fue devuelto para corrección: <strong>${escapeHtml_(s.respuesta.motivo_devolucion || '')}</strong></div>`;
  if (s.respuesta.aprobado) html += `<div class="aprobado-banner">✅ Validado por ${escapeHtml_(s.respuesta.validado_por_nombre || s.respuesta.aprobado_por || '')} — ya no se puede modificar.</div>`;

  html += `<div class="checklist-header">
    <div class="name">${s.respuesta.pct}% completado ${statusChip(s.respuesta.estado)}</div>
    <div class="progress-bar"><div class="progress-fill" style="width:${s.respuesta.pct}%"></div></div>
  </div>`;

  if (interactive) {
    html += `<div class="extra-block">
      <div class="title">👤 Tu nombre</div>
      <input type="text" id="captura-nombre" placeholder="Escribe tu nombre" value="${escapeHtml_(s.nombreCaptura || '')}">
    </div>`;
  }

  s.items.forEach((item) => {
    const ie = s.itemEstado[item.id];
    const estado = ie ? ie.estado : 'pendiente';
    const fotoUrl = item.evidencia_tag ? s.fotosByTag[item.evidencia_tag] : null;
    html += `<div class="item-row ${interactive ? '' : 'locked'}">
      <div class="item-main" data-check="${item.id}">
        <div class="item-check ${estado === 'ok' ? 'ok' : estado === 'incidencia' ? 'incidencia' : ''}">${estado === 'ok' ? '✓' : estado === 'incidencia' ? '!' : ''}</div>
        <div class="item-text">${escapeHtml_(item.texto)}</div>
      </div>
      ${item.requiere_foto ? `<div class="item-photo-req">📷 Foto obligatoria: ${EVIDENCIA_LABELS[item.evidencia_tag] || item.evidencia_tag}</div>` : ''}
      ${fotoUrl ? `<div class="photo-thumb-row"><img class="photo-thumb" src="${fotoUrl}"></div>` : ''}
      ${interactive ? `<div class="item-actions">
          <button class="item-action-btn ${estado === 'incidencia' ? 'active' : ''}" data-incidencia="${item.id}">⚠ Incidencia</button>
          ${item.requiere_foto ? `<button class="item-action-btn" data-foto="${item.id}">📷 ${fotoUrl ? 'Repetir foto' : 'Tomar foto'}</button>` : ''}
        </div>` : ''}
      ${ie && ie.nota ? `<div class="item-note">"${escapeHtml_(ie.nota)}"</div>` : ''}
    </div>`;
  });

  if (s.esAuroraMedidor) {
    html += `<div class="extra-block">
      <div class="title">💧 Medidor de agua</div>
      <div class="section-sub" style="margin:0 0 10px;">${s.medidor.anterior ? 'Lectura anterior: ' + s.medidor.anterior.lectura + ' (' + s.medidor.anterior.fecha + ')' : 'Sin lecturas previas registradas'}</div>
      <div class="field"><label>Lectura actual</label><input type="number" id="medidor-lectura" inputmode="decimal" value="${s.medidor.lectura}" ${interactive ? '' : 'disabled'}></div>
      ${s.medidor.fotoUrl ? `<div class="photo-thumb-row"><img class="photo-thumb" src="${s.medidor.fotoUrl}"></div>` : ''}
      ${interactive ? `<button class="btn btn-outline btn-sm" id="medidor-foto-btn" type="button">📷 Foto del medidor</button>` : ''}
    </div>`;
  }

  if (s.esInventario) {
    html += `<div class="extra-block">
      <div class="title">📦 ¿Se envió el inventario diario?</div>
      <div class="radio-group">
        <div class="radio-option ${s.inventario.enviado === true ? 'selected' : ''}" data-inv="si">Sí</div>
        <div class="radio-option ${s.inventario.enviado === false ? 'selected danger' : ''}" data-inv="no">No</div>
      </div>
      ${s.inventario.enviado === false ? `<div class="field"><label>Motivo</label><textarea id="inventario-motivo" rows="2" ${interactive ? '' : 'disabled'}>${escapeHtml_(s.inventario.motivo)}</textarea></div>` : ''}
    </div>`;
  }

  if (interactive) {
    html += `<div class="sticky-submit"><button class="btn btn-primary" id="submit-checklist-btn">Enviar checklist</button></div>`;
  }

  main.innerHTML = html;

  if (interactive) {
    const nombreInput = el('captura-nombre');
    if (nombreInput) nombreInput.addEventListener('input', () => { s.nombreCaptura = nombreInput.value; GUEST.nombre = nombreInput.value; });
    main.querySelectorAll('[data-check]').forEach((c) => c.addEventListener('click', () => toggleItemOk_(c.dataset.check)));
    main.querySelectorAll('[data-incidencia]').forEach((c) => c.addEventListener('click', () => openIncidenciaModal_(c.dataset.incidencia)));
    main.querySelectorAll('[data-foto]').forEach((c) => c.addEventListener('click', () => captureItemPhoto_(c.dataset.foto)));
    const invSi = main.querySelector('[data-inv="si"]');
    const invNo = main.querySelector('[data-inv="no"]');
    if (invSi) invSi.addEventListener('click', () => { s.inventario.enviado = true; s.inventario.motivo = ''; renderChecklistBody_(true); });
    if (invNo) invNo.addEventListener('click', () => { s.inventario.enviado = false; renderChecklistBody_(true); });
    const medidorBtn = el('medidor-foto-btn');
    if (medidorBtn) medidorBtn.addEventListener('click', captureMedidorPhoto_);
    const submitBtn = el('submit-checklist-btn');
    if (submitBtn) submitBtn.addEventListener('click', submitChecklist_);
  }
}

async function toggleItemOk_(itemId) {
  const s = checklistState;
  const current = s.itemEstado[itemId] ? s.itemEstado[itemId].estado : 'pendiente';
  const nuevo = current === 'ok' ? 'pendiente' : 'ok';
  s.itemEstado[itemId] = { estado: nuevo, nota: '' };
  renderChecklistBody_(true);
  try {
    const r = await api('saveItemEstado', { respuesta_id: s.respuesta.id, item_id: itemId, estado: nuevo, nombre: guestNombre_() });
    if (r.ok === false) { showToast(r.error); return; }
    if (r.respuesta) { s.respuesta = r.respuesta; renderChecklistBody_(true); }
  } catch (e) { showToast('No se guardó — revisa tu conexión'); }
}

function openIncidenciaModal_(itemId) {
  showModal(`
    <h3>⚠ Reportar incidencia</h3>
    <textarea id="inc-texto" placeholder="Describe qué pasó..."></textarea>
    <div class="modal-actions">
      <button class="btn btn-outline" id="inc-cancel">Cancelar</button>
      <button class="btn btn-danger" id="inc-confirm">Guardar incidencia</button>
    </div>
  `);
  el('inc-cancel').addEventListener('click', hideModal);
  el('inc-confirm').addEventListener('click', async () => {
    const texto = el('inc-texto').value.trim();
    if (!texto) { showToast('Describe la incidencia'); return; }
    try {
      const r = await api('addIncidencia', { respuesta_id: checklistState.respuesta.id, item_id: itemId, texto, nombre: guestNombre_() });
      if (!r.ok) { showToast(r.error); return; }
      checklistState.itemEstado[itemId] = { estado: 'incidencia', nota: texto };
      if (r.respuesta) checklistState.respuesta = r.respuesta;
      hideModal();
      renderChecklistBody_(true);
      showToast('Incidencia registrada');
    } catch (e) { showToast('No se pudo guardar. Revisa tu conexión.'); }
  });
}

async function captureItemPhoto_(itemId) {
  const item = checklistState.items.filter((it) => it.id === itemId)[0];
  try {
    const { base64, filename, mimeType } = await takePhoto();
    showToast('Subiendo foto…');
    const r = await api('uploadFoto', {
      respuesta_id: checklistState.respuesta.id, tipo_evidencia: item.evidencia_tag,
      sucursal_id: checklistState.sucursal_id, area_id: checklistState.area_id,
      item_id: itemId, base64, filename, mimeType, nombre: guestNombre_()
    });
    if (!r.ok) { showToast(r.error); return; }
    checklistState.fotosByTag[item.evidencia_tag] = r.url;
    checklistState.itemEstado[itemId] = { estado: 'ok', nota: '' };
    if (r.respuesta) checklistState.respuesta = r.respuesta;
    renderChecklistBody_(true);
    showToast('Foto guardada ✓');
  } catch (e) { /* cancelado o sin conexión */ }
}

async function captureMedidorPhoto_() {
  try {
    const { base64, filename, mimeType } = await takePhoto();
    showToast('Subiendo foto…');
    const r = await api('uploadFoto', {
      respuesta_id: checklistState.respuesta.id, tipo_evidencia: 'medidor_agua',
      sucursal_id: checklistState.sucursal_id, area_id: checklistState.area_id,
      base64, filename, mimeType, nombre: guestNombre_()
    });
    if (!r.ok) { showToast(r.error); return; }
    checklistState.medidor.fotoUrl = r.url;
    renderChecklistBody_(true);
    showToast('Foto guardada ✓');
  } catch (e) {}
}

async function submitChecklist_() {
  const s = checklistState;
  if (APP_MODE === 'guest' && !s.nombreCaptura) { showToast('Escribe tu nombre antes de enviar'); return; }
  const extra = {};
  if (s.esAuroraMedidor) {
    const lecturaInput = el('medidor-lectura');
    extra.medidor_lectura = lecturaInput ? lecturaInput.value : s.medidor.lectura;
    extra.medidor_foto_url = s.medidor.fotoUrl;
  }
  if (s.esInventario) {
    extra.inventario_enviado = s.inventario.enviado;
    const motivoInput = el('inventario-motivo');
    extra.inventario_motivo = motivoInput ? motivoInput.value.trim() : s.inventario.motivo;
  }
  const btn = el('submit-checklist-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Enviando…'; }
  try {
    const r = await api('submitRespuesta', { respuesta_id: s.respuesta.id, extra, nombre: guestNombre_() });
    if (!r.ok) { showToast(r.error); if (btn) { btn.disabled = false; btn.textContent = 'Enviar checklist'; } return; }
    if (APP_MODE === 'guest' && s.nombreCaptura) localStorage.setItem(STORAGE_KEYS.GUEST_NOMBRE, s.nombreCaptura);
    showToast('Checklist enviado ✓');
    if (APP_MODE === 'guest') goTo('validarSitio', { respuesta_id: s.respuesta.id });
    else goBack();
  } catch (e) { showToast('No se pudo enviar. Revisa tu conexión.'); if (btn) { btn.disabled = false; btn.textContent = 'Enviar checklist'; } }
}

// ============================================================
// VALIDACIÓN EN SITIO — encargado/subgerente en turno (piso)
// ============================================================
async function renderValidarSitio(params) {
  setTopbar('Validación en sitio', '', true);
  const main = el('main-content');
  try {
    const r = await api('getRespuestaDetalle', { respuesta_id: params.respuesta_id });
    if (!r.ok) { main.innerHTML = errorBlock_(r.error); return; }
    const resp = r.respuesta;
    setTopbar(areaNombre(resp.area_id) + ' — ' + (resp.tipo === 'apertura' ? 'Apertura' : 'Cierre'), sucursalNombre(resp.sucursal_id), true);

    if (resp.aprobado) {
      main.innerHTML = `<div class="aprobado-banner">✅ Ya fue validado por ${escapeHtml_(resp.validado_por_nombre || resp.aprobado_por || '')}.</div>`;
      return;
    }

    const itemMap = {}; r.itemsEstado.forEach((ri) => { itemMap[ri.item_id] = ri; });
    const fotosByTag = {}; r.fotos.forEach((f) => { fotosByTag[f.tipo_evidencia] = f.drive_url; });

    let html = `<div class="validar-summary">
      <div class="big-pct">${resp.pct}%</div>
      <div class="rows">
        <div><strong>${r.items.length}</strong>tareas</div>
        <div><strong>${r.fotos.length}</strong>fotos</div>
        <div><strong>${r.incidencias.length}</strong>incidencias</div>
      </div>
      <div class="section-sub" style="margin-top:10px;">Capturado por ${escapeHtml_(resp.capturado_por_nombre || '—')}</div>
    </div>`;

    if (r.incidencias.length) {
      html += '<div class="section-title">Incidencias reportadas</div>';
      r.incidencias.forEach((inc) => { html += `<div class="area-card"><div class="section-sub" style="margin:0;">⚠ ${escapeHtml_(inc.texto)}</div></div>`; });
    }

    html += '<div class="section-title">Checklist</div>';
    r.items.forEach((item) => {
      const ie = itemMap[item.id];
      const estado = ie ? ie.estado : 'pendiente';
      const fotoUrl = item.evidencia_tag ? fotosByTag[item.evidencia_tag] : null;
      html += `<div class="item-row">
        <div class="item-main">
          <div class="item-check ${estado === 'ok' ? 'ok' : estado === 'incidencia' ? 'incidencia' : ''}">${estado === 'ok' ? '✓' : estado === 'incidencia' ? '!' : ''}</div>
          <div class="item-text">${escapeHtml_(item.texto)}</div>
        </div>
        ${fotoUrl ? `<div class="photo-thumb-row"><img class="photo-thumb" src="${fotoUrl}"></div>` : ''}
        ${ie && ie.nota ? `<div class="item-note">"${escapeHtml_(ie.nota)}"</div>` : ''}
      </div>`;
    });

    html += `<div class="extra-block">
      <div class="title">✍️ Validación del encargado / subgerente en turno</div>
      <input type="text" id="validar-nombre" placeholder="Tu nombre">
    </div>`;
    html += `<div class="approve-buttons">
      <button class="btn btn-outline" id="devolver-sitio-btn">Regresar para corregir</button>
      <button class="btn btn-primary" id="validar-sitio-btn">Validar y enviar</button>
    </div>`;

    main.innerHTML = html;

    el('validar-sitio-btn').addEventListener('click', async () => {
      const nombre_encargado = el('validar-nombre').value.trim();
      if (!nombre_encargado) { showToast('Escribe tu nombre para validar'); return; }
      try {
        const rr = await api('validarEnSitio', { respuesta_id: resp.id, nombre_encargado });
        if (!rr.ok) { showToast(rr.error); return; }
        showToast('Validado ✓');
        goTo('home', {}, { replace: true, resetStack: true });
      } catch (e) { showToast('No se pudo validar. Revisa tu conexión.'); }
    });

    el('devolver-sitio-btn').addEventListener('click', () => {
      showModal(`<h3>Regresar para corregir</h3><textarea id="dev-sitio-motivo" placeholder="¿Qué debe corregirse?"></textarea>
        <div class="modal-actions"><button class="btn btn-outline" id="dev-sitio-cancel">Cancelar</button><button class="btn btn-danger" id="dev-sitio-confirm">Regresar</button></div>`);
      el('dev-sitio-cancel').addEventListener('click', hideModal);
      el('dev-sitio-confirm').addEventListener('click', async () => {
        const motivo = el('dev-sitio-motivo').value.trim();
        if (!motivo) { showToast('Indica qué debe corregirse'); return; }
        try {
          const rr = await api('devolverEnSitio', { respuesta_id: resp.id, motivo });
          if (!rr.ok) { showToast(rr.error); return; }
          hideModal(); showToast('Regresado para corrección');
          goTo('checklist', { sucursal_id: resp.sucursal_id, area_id: resp.area_id, tipo: resp.tipo }, { replace: true, resetStack: true });
        } catch (e) { showToast('No se pudo guardar.'); }
      });
    });
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

// ============================================================
// CAJA — formulario simplificado (piso)
// ============================================================
let cajaState = null;

async function renderCaja(params) {
  const sucursalId = params.sucursal_id;
  setTopbar('Caja', sucursalNombre(sucursalId), true);
  const main = el('main-content');
  try {
    const r = await api('getCaja', { sucursal_id: sucursalId, fecha: todayISO() });
    const existente = r.ok ? r.caja : null;
    cajaState = {
      sucursal_id: sucursalId,
      diferencia: existente ? existente.diferencia : null,
      monto: existente ? existente.monto : '',
      explicacion: existente ? existente.explicacion : '',
      fotoArqueoUrl: existente ? existente.foto_arqueo_url : null,
      fotosTerminalUrls: existente && existente.fotos_terminal_urls ? String(existente.fotos_terminal_urls).split(',').filter(Boolean) : [],
      aprobado: existente ? existente.aprobado : false,
      enviado: existente ? true : false,
      nombreCaptura: GUEST.nombre || ''
    };
    if (cajaState.enviado && !cajaState.aprobado) {
      main.innerHTML = `
        <div class="validar-summary"><div class="section-sub" style="margin:0;">Caja enviada, esperando validación del encargado.</div></div>
        <button class="btn btn-primary" id="ir-validar-caja-btn" style="margin-top:16px;">Soy el encargado — revisar y validar</button>`;
      el('ir-validar-caja-btn').addEventListener('click', () => goTo('validarCajaSitio', { sucursal_id: sucursalId, fecha: todayISO() }));
      return;
    }
    renderCajaBody_();
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

function renderCajaBody_() {
  const s = cajaState;
  const interactive = !s.aprobado;
  const main = el('main-content');
  let html = '';

  if (interactive) {
    html += `<div class="extra-block">
      <div class="title">👤 Tu nombre</div>
      <input type="text" id="caja-nombre" placeholder="Escribe tu nombre" value="${escapeHtml_(s.nombreCaptura || '')}">
    </div>`;
  }

  html += `<div class="extra-block">
    <div class="title">¿Existe diferencia de caja?</div>
    <div class="radio-group">
      <div class="radio-option ${s.diferencia === false ? 'selected' : ''}" data-dif="no">No</div>
      <div class="radio-option ${s.diferencia === true ? 'selected danger' : ''}" data-dif="si">Sí</div>
    </div>
    ${s.diferencia === true ? `
      <div class="field"><label>Monto de la diferencia</label><input type="number" inputmode="decimal" id="caja-monto" value="${s.monto}" placeholder="$0.00" ${interactive ? '' : 'disabled'}></div>
      <div class="field"><label>Explicación</label><textarea id="caja-explicacion" rows="3" ${interactive ? '' : 'disabled'}>${escapeHtml_(s.explicacion)}</textarea></div>
    ` : ''}
  </div>`;

  html += `<div class="extra-block">
    <div class="title">📄 Foto del arqueo de caja (Parrot)</div>
    ${s.fotoArqueoUrl ? `<div class="photo-thumb-row"><img class="photo-thumb" src="${s.fotoArqueoUrl}"></div>` : '<div class="section-sub" style="margin:0 0 10px;">Aún no se ha subido</div>'}
    ${interactive ? `<button class="btn btn-outline btn-sm" id="foto-arqueo-btn" type="button">📷 ${s.fotoArqueoUrl ? 'Repetir foto' : 'Tomar foto'}</button>` : ''}
  </div>`;

  html += `<div class="extra-block">
    <div class="title">🧾 Foto(s) de cortes de terminal</div>
    <div class="photo-thumb-row">${s.fotosTerminalUrls.map((u) => `<img class="photo-thumb" src="${u}">`).join('')}</div>
    ${interactive ? `<button class="btn btn-outline btn-sm" id="foto-terminal-btn" type="button" style="margin-top:8px;">📷 Agregar foto de corte</button>` : ''}
  </div>`;

  if (interactive) html += `<div class="sticky-submit"><button class="btn btn-primary" id="submit-caja-btn">Enviar caja del día</button></div>`;

  main.innerHTML = html;

  if (interactive) {
    const nombreInput = el('caja-nombre');
    if (nombreInput) nombreInput.addEventListener('input', () => { s.nombreCaptura = nombreInput.value; GUEST.nombre = nombreInput.value; });
    const difNo = main.querySelector('[data-dif="no"]'); const difSi = main.querySelector('[data-dif="si"]');
    if (difNo) difNo.addEventListener('click', () => { s.diferencia = false; renderCajaBody_(); });
    if (difSi) difSi.addEventListener('click', () => { s.diferencia = true; renderCajaBody_(); });
    const arqueoBtn = el('foto-arqueo-btn');
    if (arqueoBtn) arqueoBtn.addEventListener('click', async () => {
      try {
        const { base64, filename, mimeType } = await takePhoto();
        showToast('Subiendo foto…');
        const r = await api('uploadFoto', { respuesta_id: '', tipo_evidencia: 'caja_arqueo', sucursal_id: s.sucursal_id, area_id: 'AREA-CAJA', base64, filename, mimeType, nombre: guestNombre_() });
        if (!r.ok) { showToast(r.error); return; }
        s.fotoArqueoUrl = r.url; renderCajaBody_(); showToast('Foto guardada ✓');
      } catch (e) {}
    });
    const terminalBtn = el('foto-terminal-btn');
    if (terminalBtn) terminalBtn.addEventListener('click', async () => {
      try {
        const { base64, filename, mimeType } = await takePhoto();
        showToast('Subiendo foto…');
        const r = await api('uploadFoto', { respuesta_id: '', tipo_evidencia: 'caja_terminal', sucursal_id: s.sucursal_id, area_id: 'AREA-CAJA', base64, filename, mimeType, nombre: guestNombre_() });
        if (!r.ok) { showToast(r.error); return; }
        s.fotosTerminalUrls.push(r.url); renderCajaBody_(); showToast('Foto guardada ✓');
      } catch (e) {}
    });
    const submitBtn = el('submit-caja-btn');
    if (submitBtn) submitBtn.addEventListener('click', submitCaja_);
  }
}

async function submitCaja_() {
  const s = cajaState;
  if (!s.nombreCaptura) { showToast('Escribe tu nombre antes de enviar'); return; }
  if (s.diferencia === null) { showToast('Indica si existe diferencia de caja'); return; }
  const montoInput = el('caja-monto'); const expInput = el('caja-explicacion');
  const btn = el('submit-caja-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Enviando…'; }
  try {
    const r = await api('submitCaja', {
      sucursal_id: s.sucursal_id, fecha: todayISO(), diferencia: s.diferencia,
      monto: montoInput ? montoInput.value : s.monto, explicacion: expInput ? expInput.value.trim() : s.explicacion,
      foto_arqueo_url: s.fotoArqueoUrl, fotos_terminal_urls: s.fotosTerminalUrls, nombre: guestNombre_()
    });
    if (!r.ok) { showToast(r.error); if (btn) { btn.disabled = false; btn.textContent = 'Enviar caja del día'; } return; }
    if (s.nombreCaptura) localStorage.setItem(STORAGE_KEYS.GUEST_NOMBRE, s.nombreCaptura);
    showToast('Caja enviada ✓');
    goTo('validarCajaSitio', { sucursal_id: s.sucursal_id, fecha: todayISO() });
  } catch (e) { showToast('No se pudo enviar. Revisa tu conexión.'); if (btn) { btn.disabled = false; btn.textContent = 'Enviar caja del día'; } }
}

// ============================================================
// VALIDACIÓN DE CAJA EN SITIO (piso)
// ============================================================
async function renderValidarCajaSitio(params) {
  setTopbar('Validación de caja', sucursalNombre(params.sucursal_id), true);
  const main = el('main-content');
  try {
    const r = await api('getCaja', { sucursal_id: params.sucursal_id, fecha: params.fecha || todayISO() });
    if (!r.ok || !r.caja) { main.innerHTML = errorBlock_('Aún no hay caja capturada para hoy'); return; }
    const c = r.caja;
    if (c.aprobado) { main.innerHTML = `<div class="aprobado-banner">✅ Caja ya validada.</div>`; return; }
    const fotosTerminal = c.fotos_terminal_urls ? String(c.fotos_terminal_urls).split(',').filter(Boolean) : [];

    let html = `<div class="approve-summary">
      <div style="font-weight:700;margin-bottom:6px;">${c.diferencia ? '🔴 Diferencia reportada' : '✅ Sin diferencia'}</div>
      ${c.diferencia ? `<div class="section-sub" style="margin:0 0 4px;">Monto: $${escapeHtml_(String(c.monto))}</div><div class="section-sub" style="margin:0;">${escapeHtml_(c.explicacion || '')}</div>` : ''}
    </div>`;
    html += '<div class="section-title">Arqueo de caja (Parrot)</div>';
    html += c.foto_arqueo_url ? `<div class="photo-thumb-row"><img class="photo-thumb" style="width:100px;height:100px;" src="${c.foto_arqueo_url}"></div>` : '<div class="section-sub">Sin foto</div>';
    html += '<div class="section-title">Cortes de terminal</div>';
    html += fotosTerminal.length ? `<div class="photo-thumb-row">${fotosTerminal.map((u) => `<img class="photo-thumb" style="width:100px;height:100px;" src="${u}">`).join('')}</div>` : '<div class="section-sub">Sin fotos</div>';

    html += `<div class="extra-block"><div class="title">✍️ Validación del encargado</div><input type="text" id="validarcaja-nombre" placeholder="Tu nombre"></div>`;
    html += `<div class="approve-buttons">
      <button class="btn btn-outline" id="devolver-caja-sitio-btn">Regresar para corregir</button>
      <button class="btn btn-primary" id="validar-caja-sitio-btn">Validar y enviar</button>
    </div>`;

    main.innerHTML = html;

    el('validar-caja-sitio-btn').addEventListener('click', async () => {
      const nombre_encargado = el('validarcaja-nombre').value.trim();
      if (!nombre_encargado) { showToast('Escribe tu nombre para validar'); return; }
      try {
        const rr = await api('validarCajaEnSitio', { caja_id: c.id, nombre_encargado });
        if (!rr.ok) { showToast(rr.error); return; }
        showToast('Caja validada ✓');
        goTo('home', {}, { replace: true, resetStack: true });
      } catch (e) { showToast('No se pudo validar.'); }
    });

    el('devolver-caja-sitio-btn').addEventListener('click', () => {
      showModal(`<h3>Regresar caja</h3><textarea id="devc-sitio-motivo" placeholder="¿Qué debe corregirse?"></textarea>
        <div class="modal-actions"><button class="btn btn-outline" id="devc-sitio-cancel">Cancelar</button><button class="btn btn-danger" id="devc-sitio-confirm">Regresar</button></div>`);
      el('devc-sitio-cancel').addEventListener('click', hideModal);
      el('devc-sitio-confirm').addEventListener('click', async () => {
        const motivo = el('devc-sitio-motivo').value.trim();
        if (!motivo) { showToast('Indica qué debe corregirse'); return; }
        try {
          const rr = await api('devolverCajaEnSitio', { caja_id: c.id, motivo });
          if (!rr.ok) { showToast(rr.error); return; }
          hideModal(); showToast('Regresado para corrección');
          goTo('caja', { sucursal_id: params.sucursal_id }, { replace: true, resetStack: true });
        } catch (e) { showToast('No se pudo guardar.'); }
      });
    });
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión.'); }
}

// ============================================================
// APROBACIÓN REMOTA — respaldo de dirección (checklist normal)
// ============================================================
async function renderAprobacion(params) {
  setTopbar('Revisión', 'Checklist', true);
  const main = el('main-content');
  try {
    const r = await api('getRespuestaDetalle', { respuesta_id: params.respuesta_id });
    if (!r.ok) { main.innerHTML = errorBlock_(r.error); return; }
    const resp = r.respuesta;
    setTopbar(areaNombre(resp.area_id) + ' — ' + (resp.tipo === 'apertura' ? 'Apertura' : 'Cierre'), sucursalNombre(resp.sucursal_id), true);

    const itemMap = {}; r.itemsEstado.forEach((ri) => { itemMap[ri.item_id] = ri; });
    const fotosByTag = {}; r.fotos.forEach((f) => { fotosByTag[f.tipo_evidencia] = f.drive_url; });

    let html = '';
    if (resp.aprobado) html += `<div class="aprobado-banner">✅ Validado por ${escapeHtml_(resp.validado_por_nombre || resp.aprobado_por || '')}${resp.comentario_aprobacion ? ' — ' + escapeHtml_(resp.comentario_aprobacion) : ''}</div>`;
    if (resp.devuelto) html += `<div class="devuelto-banner">🔴 Devuelto: ${escapeHtml_(resp.motivo_devolucion || '')}</div>`;

    html += `<div class="approve-summary">
      <div style="font-weight:700;margin-bottom:6px;">${resp.pct}% completado ${statusChip(resp.estado)}</div>
      <div class="section-sub" style="margin:0;">Capturado por ${escapeHtml_(resp.capturado_por_nombre || '—')} · ${escapeHtml_(resp.enviado_at || 'sin enviar')}</div>
    </div>`;

    if (r.incidencias.length) {
      html += '<div class="section-title">Incidencias reportadas</div>';
      r.incidencias.forEach((inc) => { html += `<div class="area-card"><div class="section-sub" style="margin:0;">⚠ ${escapeHtml_(inc.texto)}</div></div>`; });
    }

    html += '<div class="section-title">Checklist</div>';
    r.items.forEach((item) => {
      const ie = itemMap[item.id];
      const estado = ie ? ie.estado : 'pendiente';
      const fotoUrl = item.evidencia_tag ? fotosByTag[item.evidencia_tag] : null;
      html += `<div class="item-row">
        <div class="item-main">
          <div class="item-check ${estado === 'ok' ? 'ok' : estado === 'incidencia' ? 'incidencia' : ''}">${estado === 'ok' ? '✓' : estado === 'incidencia' ? '!' : ''}</div>
          <div class="item-text">${escapeHtml_(item.texto)}</div>
        </div>
        ${fotoUrl ? `<div class="photo-thumb-row"><img class="photo-thumb" src="${fotoUrl}"></div>` : ''}
        ${ie && ie.nota ? `<div class="item-note">"${escapeHtml_(ie.nota)}"</div>` : ''}
      </div>`;
    });

    if (!resp.aprobado && resp.enviado && AUTH.user.rol === 'admin') {
      html += `<div class="approve-buttons">
        <button class="btn btn-outline" id="devolver-btn">Devolver para corrección</button>
        <button class="btn btn-primary" id="aprobar-btn">Aprobar de forma remota</button>
      </div>`;
    } else if (!resp.aprobado && resp.enviado) {
      html += `<div class="hint-box">Esperando validación en sitio del encargado. Como líder puedes ver el avance, pero solo dirección puede aprobar de forma remota.</div>`;
    }

    main.innerHTML = html;
    const aprobarBtn = el('aprobar-btn');
    if (aprobarBtn) aprobarBtn.addEventListener('click', () => aprobarConComentario_(resp.id));
    const devolverBtn = el('devolver-btn');
    if (devolverBtn) devolverBtn.addEventListener('click', () => devolverConMotivo_(resp.id));
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

function aprobarConComentario_(respuestaId) {
  showModal(`
    <h3>Aprobar de forma remota</h3>
    <textarea id="aprob-comentario" placeholder="Comentario (opcional)"></textarea>
    <div class="modal-actions">
      <button class="btn btn-outline" id="aprob-cancel">Cancelar</button>
      <button class="btn btn-primary" id="aprob-confirm">Confirmar</button>
    </div>
  `);
  el('aprob-cancel').addEventListener('click', hideModal);
  el('aprob-confirm').addEventListener('click', async () => {
    const comentario = el('aprob-comentario').value.trim();
    try {
      const r = await api('aprobarRespuesta', { respuesta_id: respuestaId, comentario });
      if (!r.ok) { showToast(r.error); return; }
      hideModal(); showToast('Aprobado ✓'); goBack();
    } catch (e) { showToast('No se pudo guardar. Revisa tu conexión.'); }
  });
}

function devolverConMotivo_(respuestaId) {
  showModal(`
    <h3>Devolver para corrección</h3>
    <textarea id="dev-motivo" placeholder="¿Qué debe corregirse?"></textarea>
    <div class="modal-actions">
      <button class="btn btn-outline" id="dev-cancel">Cancelar</button>
      <button class="btn btn-danger" id="dev-confirm">Devolver</button>
    </div>
  `);
  el('dev-cancel').addEventListener('click', hideModal);
  el('dev-confirm').addEventListener('click', async () => {
    const motivo = el('dev-motivo').value.trim();
    if (!motivo) { showToast('Indica qué debe corregirse'); return; }
    try {
      const r = await api('devolverRespuesta', { respuesta_id: respuestaId, motivo });
      if (!r.ok) { showToast(r.error); return; }
      hideModal(); showToast('Devuelto para corrección'); goBack();
    } catch (e) { showToast('No se pudo guardar. Revisa tu conexión.'); }
  });
}

// ============================================================
// APROBACIÓN REMOTA — respaldo de dirección (caja)
// ============================================================
async function renderAprobacionCaja(params) {
  setTopbar('Revisión de caja', sucursalNombre(params.sucursal_id), true);
  const main = el('main-content');
  try {
    const r = await api('getCaja', { sucursal_id: params.sucursal_id, fecha: params.fecha || todayISO() });
    if (!r.ok || !r.caja) { main.innerHTML = errorBlock_('Aún no hay caja capturada para hoy'); return; }
    const c = r.caja;
    const fotosTerminal = c.fotos_terminal_urls ? String(c.fotos_terminal_urls).split(',').filter(Boolean) : [];

    let html = '';
    if (c.aprobado) html += `<div class="aprobado-banner">✅ Caja validada.</div>`;
    html += `<div class="approve-summary">
      <div style="font-weight:700;margin-bottom:6px;">${c.diferencia ? '🔴 Diferencia reportada' : '✅ Sin diferencia'}</div>
      ${c.diferencia ? `<div class="section-sub" style="margin:0 0 4px;">Monto: $${escapeHtml_(String(c.monto))}</div><div class="section-sub" style="margin:0;">${escapeHtml_(c.explicacion || '')}</div>` : ''}
    </div>`;

    html += '<div class="section-title">Arqueo de caja (Parrot)</div>';
    html += c.foto_arqueo_url ? `<div class="photo-thumb-row"><img class="photo-thumb" style="width:100px;height:100px;" src="${c.foto_arqueo_url}"></div>` : '<div class="section-sub">Sin foto</div>';

    html += '<div class="section-title">Cortes de terminal</div>';
    html += fotosTerminal.length ? `<div class="photo-thumb-row">${fotosTerminal.map((u) => `<img class="photo-thumb" style="width:100px;height:100px;" src="${u}">`).join('')}</div>` : '<div class="section-sub">Sin fotos</div>';

    if (!c.aprobado && AUTH.user.rol === 'admin') {
      html += `<div class="approve-buttons">
        <button class="btn btn-outline" id="devolver-caja-btn">Devolver para corrección</button>
        <button class="btn btn-primary" id="aprobar-caja-btn">Aprobar de forma remota</button>
      </div>`;
    } else if (!c.aprobado) {
      html += `<div class="hint-box">Esperando validación en sitio. Solo dirección puede aprobar de forma remota.</div>`;
    }

    main.innerHTML = html;
    const aprobarBtn = el('aprobar-caja-btn');
    if (aprobarBtn) aprobarBtn.addEventListener('click', () => aprobarCajaConComentario_(c.id));
    const devolverBtn = el('devolver-caja-btn');
    if (devolverBtn) devolverBtn.addEventListener('click', () => devolverCajaConMotivo_(c.id));
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

function aprobarCajaConComentario_(cajaId) {
  showModal(`<h3>Aprobar caja de forma remota</h3><textarea id="aprobc-comentario" placeholder="Comentario (opcional)"></textarea>
    <div class="modal-actions"><button class="btn btn-outline" id="aprobc-cancel">Cancelar</button><button class="btn btn-primary" id="aprobc-confirm">Confirmar</button></div>`);
  el('aprobc-cancel').addEventListener('click', hideModal);
  el('aprobc-confirm').addEventListener('click', async () => {
    try {
      const r = await api('aprobarCaja', { caja_id: cajaId, comentario: el('aprobc-comentario').value.trim() });
      if (!r.ok) { showToast(r.error); return; }
      hideModal(); showToast('Caja aprobada ✓'); goBack();
    } catch (e) { showToast('No se pudo guardar.'); }
  });
}

function devolverCajaConMotivo_(cajaId) {
  showModal(`<h3>Devolver caja</h3><textarea id="devc-motivo" placeholder="¿Qué debe corregirse?"></textarea>
    <div class="modal-actions"><button class="btn btn-outline" id="devc-cancel">Cancelar</button><button class="btn btn-danger" id="devc-confirm">Devolver</button></div>`);
  el('devc-cancel').addEventListener('click', hideModal);
  el('devc-confirm').addEventListener('click', async () => {
    const motivo = el('devc-motivo').value.trim();
    if (!motivo) { showToast('Indica qué debe corregirse'); return; }
    try {
      const r = await api('devolverCaja', { caja_id: cajaId, motivo });
      if (!r.ok) { showToast(r.error); return; }
      hideModal(); showToast('Devuelta para corrección'); goBack();
    } catch (e) { showToast('No se pudo guardar.'); }
  });
}

// ============================================================
// PENDIENTES (lista completa — líder/admin)
// ============================================================
async function renderPendientes() {
  setTopbar('Pendientes de aprobación', '', true);
  const main = el('main-content');
  try {
    const r = await api('getPendientesAprobacion', {});
    if (!r.ok) { main.innerHTML = errorBlock_(r.error); return; }
    if (!r.pendientes.length) { main.innerHTML = '<div class="atencion-empty">Sin pendientes 🎉</div>'; return; }
    main.innerHTML = r.pendientes.map((p, idx) => `
      <div class="pendiente-card" data-pend="${idx}">
        <span>${escapeHtml_(p.sucursal_nombre)} — ${escapeHtml_(p.area_nombre)} (${p.tipo === 'apertura' ? 'Apertura' : 'Cierre'}) ${p.pct}%</span>
        <span class="chev">›</span>
      </div>`).join('');
    main.querySelectorAll('[data-pend]').forEach((c) => c.addEventListener('click', () => {
      const p = r.pendientes[Number(c.dataset.pend)];
      if (p.area_id === 'AREA-CAJA') goTo('aprobacionCaja', { sucursal_id: p.sucursal_id, fecha: p.fecha });
      else goTo('aprobacion', { respuesta_id: p.respuesta_id });
    }));
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión.'); }
}

// ============================================================
// HISTÓRICO (líder / admin)
// ============================================================
let histFilters = { periodo: '7', sucursal_id: '', area_id: '' };

async function renderHistorico() {
  setTopbar('Histórico', 'Cumplimiento por periodo', false);
  const main = el('main-content');

  let html = '<div class="filter-row">';
  [['1', 'Hoy'], ['7', '7 días'], ['30', '30 días']].forEach(([val, lbl]) => {
    html += `<div class="filter-chip ${histFilters.periodo === val ? 'active' : ''}" data-periodo="${val}">${lbl}</div>`;
  });
  html += '</div>';

  html += '<div class="filter-row">';
  html += `<div class="filter-chip ${!histFilters.sucursal_id ? 'active' : ''}" data-suc="">Todas</div>`;
  BOOT.sucursales.forEach((s) => { html += `<div class="filter-chip ${histFilters.sucursal_id === s.id ? 'active' : ''}" data-suc="${s.id}">${escapeHtml_(s.codigo)}</div>`; });
  html += '</div>';

  html += '<div class="filter-row">';
  html += `<div class="filter-chip ${!histFilters.area_id ? 'active' : ''}" data-area="">Todas las áreas</div>`;
  BOOT.areas.forEach((a) => { html += `<div class="filter-chip ${histFilters.area_id === a.id ? 'active' : ''}" data-area="${a.id}">${escapeHtml_(a.nombre)}</div>`; });
  html += '</div>';

  html += '<div id="hist-chart-container"></div>';
  main.innerHTML = html;

  main.querySelectorAll('[data-periodo]').forEach((c) => c.addEventListener('click', () => { histFilters.periodo = c.dataset.periodo; renderHistorico(); }));
  main.querySelectorAll('[data-suc]').forEach((c) => c.addEventListener('click', () => { histFilters.sucursal_id = c.dataset.suc; renderHistorico(); }));
  main.querySelectorAll('[data-area]').forEach((c) => c.addEventListener('click', () => { histFilters.area_id = c.dataset.area; renderHistorico(); }));

  await loadHistoricoChart_();
}

async function loadHistoricoChart_() {
  const dias = Number(histFilters.periodo);
  const fin = new Date(); const inicio = new Date(); inicio.setDate(inicio.getDate() - (dias - 1));
  const fechaInicio = inicio.toISOString().slice(0, 10); const fechaFin = fin.toISOString().slice(0, 10);

  const box = el('hist-chart-container');
  box.innerHTML = '<div style="display:flex;justify-content:center;padding:30px 0;"><div class="spinner"></div></div>';
  try {
    const r = await api('getHistorico', { sucursal_id: histFilters.sucursal_id || undefined, area_id: histFilters.area_id || undefined, fecha_inicio: fechaInicio, fecha_fin: fechaFin });
    if (!r.ok) { box.innerHTML = errorBlock_(r.error); return; }
    if (!r.serie.length) { box.innerHTML = '<div class="atencion-empty">Sin datos en este periodo todavía.</div>'; return; }

    const bars = r.serie.map((p) => {
      const cls = p.pct >= 90 ? '' : p.pct >= 70 ? 'mid' : 'low';
      const d = new Date(p.fecha + 'T00:00:00');
      const lbl = d.toLocaleDateString('es-MX', { day: '2-digit', month: 'short' });
      return `<div class="chart-bar-col"><div class="chart-bar ${cls}" style="height:${Math.max(p.pct, 2)}%"></div><div class="chart-label">${lbl}</div></div>`;
    }).join('');

    let rows = r.serie.slice().reverse().map((p) => `<div class="hist-row"><span>${p.fecha}</span><span>${p.pct}%</span></div>`).join('');

    box.innerHTML = `<div class="chart-box"><div class="chart-bars">${bars}</div></div><div class="chart-box">${rows}</div>`;
  } catch (e) { box.innerHTML = errorBlock_('Sin conexión.'); }
}

// ============================================================
// PERFIL (líder / admin)
// ============================================================
function renderPerfil() {
  setTopbar('Tu cuenta', '', false);
  const user = AUTH.user;
  let html = `
    <div class="area-card">
      <div class="area-card-title" style="margin-bottom:10px;">${escapeHtml_(user.nombre)}</div>
      <div class="hist-row"><span>Usuario</span><span>${escapeHtml_(user.usuario)}</span></div>
      <div class="hist-row"><span>Rol</span><span>${roleLabel(user.rol)}</span></div>
    </div>
    <button class="btn btn-outline" id="cambiar-pass-btn" style="margin-top:14px;">Cambiar contraseña</button>
  `;
  if (user.rol === 'admin') {
    html += `<button class="btn btn-primary" id="administrar-equipo-btn" style="margin-top:10px;">Administrar equipo</button>`;
  }
  el('main-content').innerHTML = html;

  const equipoBtn = el('administrar-equipo-btn');
  if (equipoBtn) equipoBtn.addEventListener('click', () => goTo('usuarios', {}));

  el('cambiar-pass-btn').addEventListener('click', () => {
    showModal(`<h3>Cambiar contraseña</h3>
      <div class="field"><input type="password" id="nueva-pass" placeholder="Nueva contraseña (mín. 6 caracteres)"></div>
      <div class="modal-actions"><button class="btn btn-outline" id="pass-cancel">Cancelar</button><button class="btn btn-primary" id="pass-confirm">Guardar</button></div>`);
    el('pass-cancel').addEventListener('click', hideModal);
    el('pass-confirm').addEventListener('click', async () => {
      const val = el('nueva-pass').value;
      try {
        const r = await api('changePassword', { newPassword: val });
        if (!r.ok) { showToast(r.error); return; }
        hideModal(); showToast('Contraseña actualizada ✓');
      } catch (e) { showToast('No se pudo actualizar.'); }
    });
  });
}

// ============================================================
// EQUIPO — administración de usuarios (solo admin)
// ============================================================
async function renderUsuarios() {
  setTopbar('Equipo', 'Líderes y dirección', true);
  const main = el('main-content');
  try {
    const r = await api('listUsuarios', {});
    if (!r.ok) { main.innerHTML = errorBlock_(r.error); return; }

    let html = '<button class="btn btn-primary" id="nuevo-usuario-btn" style="margin-bottom:16px;">+ Nuevo usuario</button>';
    if (!r.usuarios.length) {
      html += '<div class="atencion-empty">Aún no hay usuarios registrados.</div>';
    } else {
      r.usuarios.forEach((u, idx) => {
        html += `<div class="area-card">
          <div class="area-card-header">
            <span class="area-card-title">${escapeHtml_(u.nombre)}</span>
            <span class="status-chip ${u.activo === false ? 'status-no_iniciado' : 'status-completo'}">${u.activo === false ? 'Inactivo' : 'Activo'}</span>
          </div>
          <div class="hist-row"><span>Usuario</span><span>${escapeHtml_(u.usuario)}</span></div>
          <div class="hist-row"><span>Rol</span><span>${roleLabel(u.rol)}</span></div>
          <div class="area-buttons" style="margin-top:10px;">
            <button class="btn btn-outline btn-sm" data-editar="${idx}">Editar</button>
            ${u.id !== AUTH.user.id ? `<button class="btn btn-outline btn-sm" data-toggle-activo="${u.id}" data-activo="${u.activo !== false}">${u.activo === false ? 'Reactivar' : 'Quitar acceso'}</button>` : ''}
          </div>
        </div>`;
      });
    }

    main.innerHTML = html;
    el('nuevo-usuario-btn').addEventListener('click', abrirNuevoUsuarioModal_);
    main.querySelectorAll('[data-editar]').forEach((btn) => btn.addEventListener('click', () => abrirEditarUsuarioModal_(r.usuarios[Number(btn.dataset.editar)])));
    main.querySelectorAll('[data-toggle-activo]').forEach((btn) => btn.addEventListener('click', async () => {
      const nuevoActivo = btn.dataset.activo !== 'true';
      try {
        const r2 = await api('updateUsuario', { data: { id: btn.dataset.toggleActivo, activo: nuevoActivo } });
        if (!r2.ok) { showToast(r2.error); return; }
        showToast(nuevoActivo ? 'Acceso reactivado' : 'Acceso retirado');
        renderUsuarios();
      } catch (e) { showToast('No se pudo actualizar.'); }
    }));
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

function abrirNuevoUsuarioModal_() {
  showModal(`
    <h3>Nuevo usuario</h3>
    <div class="field"><label>Nombre completo</label><input type="text" id="nu-nombre"></div>
    <div class="field"><label>Usuario (para iniciar sesión)</label><input type="text" id="nu-usuario" autocapitalize="none"></div>
    <div class="field"><label>Contraseña temporal</label><input type="text" id="nu-password" value="cofki2026"></div>
    <div class="field"><label>Rol</label><select id="nu-rol"><option value="lider">Líder</option><option value="admin">Dirección</option></select></div>
    <div class="modal-actions">
      <button class="btn btn-outline" id="nu-cancel">Cancelar</button>
      <button class="btn btn-primary" id="nu-confirm">Crear usuario</button>
    </div>
  `);
  el('nu-cancel').addEventListener('click', hideModal);
  el('nu-confirm').addEventListener('click', async () => {
    const nombre = el('nu-nombre').value.trim();
    const usuario = el('nu-usuario').value.trim();
    const password = el('nu-password').value;
    const rol = el('nu-rol').value;
    if (!nombre || !usuario || !password) { showToast('Completa nombre, usuario y contraseña'); return; }
    try {
      const r = await api('createUsuario', { data: { nombre, usuario, password, rol } });
      if (!r.ok) { showToast(r.error); return; }
      hideModal();
      showToast('Usuario creado — comparte usuario y contraseña ✓');
      renderUsuarios();
    } catch (e) { showToast('No se pudo crear. Revisa tu conexión.'); }
  });
}

function abrirEditarUsuarioModal_(u) {
  showModal(`
    <h3>Editar usuario</h3>
    <div class="field"><label>Nombre completo</label><input type="text" id="eu-nombre" value="${escapeHtml_(u.nombre)}"></div>
    <div class="field"><label>Usuario (para iniciar sesión)</label><input type="text" value="${escapeHtml_(u.usuario)}" disabled></div>
    <div class="field"><label>Rol</label>
      <select id="eu-rol">
        <option value="lider" ${u.rol === 'lider' ? 'selected' : ''}>Líder</option>
        <option value="admin" ${u.rol === 'admin' ? 'selected' : ''}>Dirección</option>
      </select>
    </div>
    <div class="field"><label>Nueva contraseña (déjalo en blanco para no cambiarla)</label><input type="text" id="eu-password" placeholder="••••••••"></div>
    <div class="modal-actions">
      <button class="btn btn-outline" id="eu-cancel">Cancelar</button>
      <button class="btn btn-primary" id="eu-confirm">Guardar cambios</button>
    </div>
  `);
  el('eu-cancel').addEventListener('click', hideModal);
  el('eu-confirm').addEventListener('click', async () => {
    const nombre = el('eu-nombre').value.trim();
    const password = el('eu-password').value;
    if (!nombre) { showToast('El nombre no puede quedar vacío'); return; }
    if (password && password.length < 6) { showToast('La nueva contraseña debe tener al menos 6 caracteres'); return; }
    const data = { id: u.id, nombre, rol: el('eu-rol').value };
    if (password) data.password = password;
    try {
      const r = await api('updateUsuario', { data });
      if (!r.ok) { showToast(r.error); return; }
      hideModal();
      showToast('Usuario actualizado ✓');
      renderUsuarios();
    } catch (e) { showToast('No se pudo guardar. Revisa tu conexión.'); }
  });
}

// ---------- service worker ----------
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => { navigator.serviceWorker.register('sw.js').catch(() => {}); });
}

boot();

/**
 * CONFIGURACIÓN — Cofki Checklist Operativo
 *
 * Pega aquí la URL de tu Web App de Apps Script después de hacer
 * "Implementar > Nueva implementación" (ver README_DEPLOY.md).
 * Debe terminar en /exec
 */
const COFKI_CONFIG = {
  API_URL: 'https://script.google.com/macros/s/AKfycbzTNSPmaVI7XfCsLG65YBmLpvwwErFe2OVX_onA8_rW0u7TKqbtMfCH41n6pjVPOgJN/exec'
};

/* ============================================================
   COFKI CHECKLIST OPERATIVO — Frontend logic (v2)
   Login, checklists, fotos, caja, aprobaciones, dashboard, histórico
   ============================================================ */

const STORAGE_KEYS = { TOKEN: 'cofki_token', USER: 'cofki_user' };
const el = (id) => document.getElementById(id);
const todayISO = () => new Date().toISOString().slice(0, 10);

const EVIDENCIA_LABELS = {
  cocina: 'Cocina', refrigeradores: 'Refrigeradores', barra: 'Barra',
  salon: 'Salón', banos: 'Baños', exterior: 'Exterior / limpieza'
};

// ---------- estado global de navegación ----------
let AUTH = { token: null, user: null };
let BOOT = { sucursales: [], areas: [] };
let viewStack = [];
let current = { view: null, params: null };

// ---------- toast / modal ----------
function showToast(msg) {
  const t = el('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2400);
}
function showModal(html) {
  el('modal-box').innerHTML = html;
  el('modal-overlay').classList.add('show');
}
function hideModal() { el('modal-overlay').classList.remove('show'); }
el('modal-overlay').addEventListener('click', (e) => { if (e.target.id === 'modal-overlay') hideModal(); });

// ---------- API ----------
async function api(action, data) {
  data = data || {};
  data.action = action;
  data.token = data.token || AUTH.token;
  const res = await fetch(COFKI_CONFIG.API_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'text/plain;charset=utf-8' },
    body: JSON.stringify(data)
  });
  if (!res.ok) throw new Error('Error de red (' + res.status + ')');
  return res.json();
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function takePhoto() {
  return new Promise((resolve, reject) => {
    const input = el('file-input');
    input.value = '';
    input.onchange = async () => {
      const file = input.files[0];
      if (!file) { reject(new Error('cancelado')); return; }
      try {
        const base64 = await fileToBase64(file);
        resolve({ base64, filename: file.name, mimeType: file.type || 'image/jpeg' });
      } catch (e) { reject(e); }
    };
    input.click();
  });
}

// ---------- sesión ----------
function getToken() { return localStorage.getItem(STORAGE_KEYS.TOKEN); }
function getUser() { try { return JSON.parse(localStorage.getItem(STORAGE_KEYS.USER)); } catch (e) { return null; } }
function saveSession(token, user) {
  localStorage.setItem(STORAGE_KEYS.TOKEN, token);
  localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
  AUTH.token = token; AUTH.user = user;
}
function clearSession() {
  localStorage.removeItem(STORAGE_KEYS.TOKEN);
  localStorage.removeItem(STORAGE_KEYS.USER);
  AUTH = { token: null, user: null };
}

// ---------- boot ----------
async function boot() {
  const token = getToken();
  if (!token) { showLogin(); return; }
  AUTH.token = token;
  try {
    const r = await api('validateSession', { token });
    if (!r.ok) { clearSession(); showLogin(); return; }
    saveSession(token, r.user);
    const bs = await api('getBootstrap', {});
    if (bs.ok) { BOOT.sucursales = bs.sucursales; BOOT.areas = bs.areas; }
    showApp();
  } catch (e) {
    const cachedUser = getUser();
    if (cachedUser) { AUTH.user = cachedUser; showApp(); showToast('Sin conexión — mostrando última sesión guardada'); }
    else showLogin();
  }
}

function showLogin() {
  el('loading').style.display = 'none';
  el('app-screen').style.display = 'none';
  el('login-screen').style.display = 'flex';
}
function showApp() {
  el('loading').style.display = 'none';
  el('login-screen').style.display = 'none';
  el('app-screen').style.display = 'flex';
  goTo('home', {}, { replace: true });
}

el('login-form').addEventListener('submit', async (e) => {
  e.preventDefault();
  const usuario = el('usuario').value.trim();
  const password = el('password').value;
  const btn = el('login-btn');
  const errBox = el('login-error');
  errBox.style.display = 'none';
  btn.disabled = true; btn.textContent = 'Entrando…';
  try {
    const r = await api('login', { usuario, password });
    if (r.ok) {
      saveSession(r.token, r.user);
      const bs = await api('getBootstrap', {});
      if (bs.ok) { BOOT.sucursales = bs.sucursales; BOOT.areas = bs.areas; }
      showApp();
    } else { errBox.textContent = r.error || 'No se pudo iniciar sesión'; errBox.style.display = 'block'; }
  } catch (err) { errBox.textContent = 'No hay conexión con el servidor.'; errBox.style.display = 'block'; }
  finally { btn.disabled = false; btn.textContent = 'Entrar'; }
});

el('logout-btn').addEventListener('click', async () => {
  const token = getToken();
  clearSession();
  showLogin();
  try { await api('logout', { token }); } catch (e) {}
});

el('back-btn').addEventListener('click', goBack);

document.querySelectorAll('.bottom-nav button[data-tab]').forEach((btn) => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.bottom-nav button').forEach((b) => b.classList.remove('active'));
    btn.classList.add('active');
    const tab = btn.dataset.tab;
    if (tab === 'dashboard') goTo('home', {}, { replace: true, resetStack: true });
    if (tab === 'historico') goTo('historico', {}, { replace: true, resetStack: true });
    if (tab === 'perfil') goTo('perfil', {}, { replace: true, resetStack: true });
  });
});

// ---------- router ----------
function goTo(view, params, opts) {
  opts = opts || {};
  if (opts.resetStack) viewStack = [];
  else if (current.view) viewStack.push(current);
  current = { view, params: params || {} };
  render();
}
function goBack() {
  const prev = viewStack.pop();
  if (prev) { current = prev; render(); }
  else goTo('home', {}, { replace: true, resetStack: true });
}
function setTopbar(title, subtitle, showBack) {
  el('topbar-title').textContent = title;
  el('topbar-subtitle').textContent = subtitle || '';
  el('back-btn').style.display = showBack ? 'flex' : 'none';
}

function render() {
  const main = el('main-content');
  main.innerHTML = '<div style="display:flex;justify-content:center;padding:60px 0;"><div class="spinner"></div></div>';
  const showBack = viewStack.length > 0;
  const fn = {
    home: renderHome,
    dashboardHoy: renderDashboardHoy,
    sucursalDetalle: renderSucursalDetalle,
    checklist: renderChecklist,
    caja: renderCaja,
    aprobacion: renderAprobacion,
    aprobacionCaja: renderAprobacionCaja,
    pendientes: renderPendientes,
    historico: renderHistorico,
    perfil: renderPerfil
  }[current.view];
  if (!fn) { main.innerHTML = errorBlock_('Vista no encontrada'); return; }
  fn(current.params, showBack);
}

function errorBlock_(msg) { return '<div class="error-box" style="display:block;">' + escapeHtml_(msg || 'Ocurrió un error') + '</div>'; }
function escapeHtml_(str) { const d = document.createElement('div'); d.textContent = str == null ? '' : String(str); return d.innerHTML; }
function roleLabel(rol) { return { admin: 'Dirección', gerente: 'Gerente', colaborador: 'Colaborador' }[rol] || rol; }
function sucursalNombre(id) { return (BOOT.sucursales.filter((s) => s.id === id)[0] || {}).nombre || id; }
function areaNombre(id) { return (BOOT.areas.filter((a) => a.id === id)[0] || {}).nombre || id; }
function estadoDot(estado) { return '<span class="estado-dot estado-' + estado + '"></span>'; }
function estadoEmoji(estado) { return { completo: '🟢', pendiente: '🟡', incidencia: '🔴', no_iniciado: '⚪' }[estado] || '⚪'; }
function statusChip(estado) {
  const labels = { completo: 'Completo', en_progreso: 'En progreso', pendiente: 'Pendiente', incidencia: 'Incidencia', no_iniciado: 'No iniciado' };
  return '<span class="status-chip status-' + estado + '">' + (labels[estado] || estado) + '</span>';
}

// ============================================================
// HOME (según rol)
// ============================================================
async function renderHome() {
  const user = AUTH.user;
  if (user.rol === 'admin') return renderDashboardHoy({}, false);
  if (user.rol === 'gerente') return renderSucursalDetalle({ sucursal_id: user.sucursal_id, esHome: true }, false);
  return renderColaboradorHome();
}

// ============================================================
// COLABORADOR — áreas de su sucursal
// ============================================================
async function renderColaboradorHome() {
  setTopbar('Cofki', AUTH.user.nombre, false);
  const main = el('main-content');
  try {
    const r = await api('getSucursalDetalle', { sucursal_id: AUTH.user.sucursal_id, fecha: todayISO() });
    if (!r.ok) { main.innerHTML = errorBlock_(r.error); return; }
    const misAreas = AUTH.user.areas && AUTH.user.areas.length ? r.areas.filter((a) => AUTH.user.areas.includes(a.area_id)) : r.areas;

    let html = '<div class="section-title">' + escapeHtml_(sucursalNombre(AUTH.user.sucursal_id)) + ' — Hoy</div>';
    html += '<div class="section-sub">Toca Apertura o Cierre para llenar tu checklist</div>';

    misAreas.forEach((a) => {
      const esCajaCierre = a.area_id === 'AREA-CAJA';
      html += `<div class="area-card">
        <div class="area-card-header"><span class="area-card-title">${escapeHtml_(a.area_nombre)}</span></div>
        <div class="area-buttons">
          ${areaBtnHtml(a.apertura, 'Apertura', `goTo('checklist', {sucursal_id:'${AUTH.user.sucursal_id}', area_id:'${a.area_id}', tipo:'apertura'})`)}
          ${areaBtnHtml(a.cierre, 'Cierre', esCajaCierre ? `goTo('caja', {sucursal_id:'${AUTH.user.sucursal_id}'})` : `goTo('checklist', {sucursal_id:'${AUTH.user.sucursal_id}', area_id:'${a.area_id}', tipo:'cierre'})`)}
        </div>
      </div>`;
    });

    main.innerHTML = html;
    main.querySelectorAll('.area-btn').forEach((btn) => btn.addEventListener('click', () => eval(btn.dataset.action)));
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

function areaBtnHtml(estadoObj, label, action) {
  const cls = estadoObj.estado === 'completo' ? 'state-completo' : estadoObj.estado === 'incidencia' ? 'state-incidencia' : estadoObj.estado === 'en_progreso' ? 'state-en_progreso' : '';
  const lockIcon = estadoObj.aprobado ? ' 🔒' : '';
  return `<div class="area-btn ${cls}" data-action="${escapeHtml_(action)}">
    <div class="lbl">${label}${lockIcon}</div>
    <div class="pct">${estadoObj.pct}%</div>
  </div>`;
}

// ============================================================
// DIRECCIÓN — Operación de hoy
// ============================================================
async function renderDashboardHoy() {
  setTopbar('COFKI — Operación de hoy', formatDateLong_(todayISO()), false);
  const main = el('main-content');
  try {
    const r = await api('getDashboardHoy', { fecha: todayISO() });
    if (!r.ok) { main.innerHTML = errorBlock_(r.error); return; }

    let html = '<div class="section-title">Las 3 sucursales</div><div class="suc-grid">';
    r.sucursales.forEach((s) => {
      html += `<div class="suc-card" data-goto="sucursalDetalle" data-sucursal="${s.sucursal_id}">
        <div class="suc-header">
          <span class="suc-name">${estadoEmoji(s.estado)} ${escapeHtml_(s.sucursal_nombre)}</span>
          <span class="suc-code">${escapeHtml_(s.sucursal_codigo)}</span>
        </div>
        <div class="metric-row">
          <div class="metric"><div class="num">${s.apertura_pct}%</div><div class="lbl">Apertura</div></div>
          <div class="metric"><div class="num">${s.cierre_pct}%</div><div class="lbl">Cierre</div></div>
          <div class="metric"><div class="num">${s.general_pct}%</div><div class="lbl">General</div></div>
        </div>
      </div>`;
    });
    html += '</div>';

    html += '<div class="section-title">Requiere atención</div>';
    if (r.atencion.length === 0) {
      html += '<div class="atencion-empty">🎉 Nada pendiente por ahora.</div>';
    } else {
      r.atencion.forEach((a, idx) => {
        html += `<div class="atencion-item" data-atencion="${idx}"><span class="txt">${escapeHtml_(a.texto)}</span><span class="chev">›</span></div>`;
      });
    }

    main.innerHTML = html;
    main.querySelectorAll('[data-goto="sucursalDetalle"]').forEach((c) => c.addEventListener('click', () => goTo('sucursalDetalle', { sucursal_id: c.dataset.sucursal })));
    main.querySelectorAll('[data-atencion]').forEach((c) => c.addEventListener('click', () => {
      const item = r.atencion[Number(c.dataset.atencion)];
      if (item && item.target) goTo(item.target.view, item.target);
    }));
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

function formatDateLong_(iso) {
  const d = new Date(iso + 'T00:00:00');
  return d.toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long' });
}

// ============================================================
// SUCURSAL DETALLE (drill-down admin / home gerente)
// ============================================================
async function renderSucursalDetalle(params) {
  const sucursalId = params.sucursal_id;
  setTopbar(sucursalNombre(sucursalId), 'Áreas de hoy', viewStack.length > 0);
  const main = el('main-content');
  try {
    const r = await api('getSucursalDetalle', { sucursal_id: sucursalId, fecha: todayISO() });
    if (!r.ok) { main.innerHTML = errorBlock_(r.error); return; }

    let html = '';
    r.areas.forEach((a) => {
      const esCajaCierre = a.area_id === 'AREA-CAJA';
      html += `<div class="area-card">
        <div class="area-card-header"><span class="area-card-title">${escapeHtml_(a.area_nombre)}</span></div>
        <div class="area-buttons">
          ${areaBtnHtml(a.apertura, 'Apertura', `goTo('checklist', {sucursal_id:'${sucursalId}', area_id:'${a.area_id}', tipo:'apertura'})`)}
          ${areaBtnHtml(a.cierre, 'Cierre', esCajaCierre ? `goTo('caja', {sucursal_id:'${sucursalId}'})` : `goTo('checklist', {sucursal_id:'${sucursalId}', area_id:'${a.area_id}', tipo:'cierre'})`)}
        </div>
      </div>`;
    });

    html += '<div class="section-title">Caja</div>';
    const cajaEstadoTxt = { sin_diferencia: '✅ Sin diferencia', diferencia_reportada: '🔴 Diferencia reportada', pendiente: '⚪ Pendiente' }[r.caja.estado] || 'Pendiente';
    html += `<div class="area-card" data-goto="caja">
      <div class="area-card-header"><span class="area-card-title">${cajaEstadoTxt}</span>${r.caja.aprobado ? '<span class="status-chip status-completo">Aprobado</span>' : ''}</div>
      <div class="section-sub" style="margin:0;">Evidencias cargadas: ${r.caja.evidencias || 0}</div>
    </div>`;

    html += '<div class="section-title">Inventario diario</div>';
    const invTxt = r.inventario.enviado === null ? '⚪ Aún no reportado' : (r.inventario.enviado ? '✅ Enviado' : '🔴 No enviado — ' + escapeHtml_(r.inventario.motivo || 'sin motivo'));
    html += `<div class="area-card"><div class="area-card-title">${invTxt}</div></div>`;

    if (AUTH.user.rol === 'admin' || AUTH.user.rol === 'gerente') {
      html += `<div class="section-title">Pendientes de aprobación</div><div id="pendientes-mini"></div>`;
    }

    main.innerHTML = html;
    main.querySelectorAll('.area-btn').forEach((btn) => btn.addEventListener('click', () => eval(btn.dataset.action)));
    const cajaCard = main.querySelector('[data-goto="caja"]');
    if (cajaCard) cajaCard.addEventListener('click', () => goTo('caja', { sucursal_id: sucursalId }));

    if (AUTH.user.rol === 'admin' || AUTH.user.rol === 'gerente') {
      const pr = await api('getPendientesAprobacion', {});
      if (pr.ok) {
        const propios = pr.pendientes.filter((p) => p.sucursal_id === sucursalId);
        const box = el('pendientes-mini');
        if (!box) return;
        if (!propios.length) { box.innerHTML = '<div class="atencion-empty">Sin pendientes de aprobación.</div>'; return; }
        box.innerHTML = propios.map((p, idx) => `
          <div class="pendiente-card" data-pend="${idx}">
            <span>${escapeHtml_(p.area_nombre)} — ${p.tipo === 'apertura' ? 'Apertura' : 'Cierre'} (${p.pct}%)</span>
            <span class="chev">›</span>
          </div>`).join('');
        box.querySelectorAll('[data-pend]').forEach((c) => c.addEventListener('click', () => {
          const p = propios[Number(c.dataset.pend)];
          if (p.area_id === 'AREA-CAJA') goTo('aprobacionCaja', { sucursal_id: p.sucursal_id, fecha: p.fecha });
          else goTo('aprobacion', { respuesta_id: p.respuesta_id });
        }));
      }
    }
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

// ============================================================
// CHECKLIST — llenar / ver
// ============================================================
let checklistState = null;

async function renderChecklist(params) {
  const { sucursal_id, area_id, tipo } = params;
  setTopbar(areaNombre(area_id), (tipo === 'apertura' ? 'Apertura' : 'Cierre') + ' — ' + sucursalNombre(sucursal_id), true);
  const main = el('main-content');
  try {
    const r = await api('getOrCreateRespuesta', { sucursal_id, area_id, tipo, fecha: todayISO() });
    if (!r.ok) { main.innerHTML = errorBlock_(r.error); return; }

    const sucursal = BOOT.sucursales.filter((s) => s.id === sucursal_id)[0] || {};
    const itemEstadoMap = {};
    r.itemsEstado.forEach((ri) => { itemEstadoMap[ri.item_id] = ri; });
    const fotosByTag = {};
    r.fotos.forEach((f) => { fotosByTag[f.tipo_evidencia] = f.drive_url; });

    checklistState = {
      respuesta: r.respuesta, sucursal_id, area_id, tipo, sucursal,
      items: r.items, itemEstado: itemEstadoMap, fotosByTag,
      esAuroraMedidor: area_id === 'AREA-SERV' && tipo === 'apertura' && sucursal.codigo === 'AURORA',
      esInventario: area_id === 'AREA-SERV' && tipo === 'cierre',
      medidor: { lectura: r.respuesta.medidor_lectura || '', fotoUrl: r.respuesta.medidor_foto_url || '', anterior: null },
      inventario: { enviado: typeof r.respuesta.inventario_enviado === 'boolean' ? r.respuesta.inventario_enviado : null, motivo: r.respuesta.inventario_motivo || '' }
    };

    const interactive = AUTH.user.rol === 'colaborador' && r.respuesta.aprobado !== true;

    if (checklistState.esAuroraMedidor) {
      const lr = await api('getLecturaAnterior', { sucursal_id });
      if (lr.ok) checklistState.medidor.anterior = lr.anterior;
    }

    renderChecklistBody_(interactive);
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

function renderChecklistBody_(interactive) {
  const s = checklistState;
  const main = el('main-content');
  let html = '';

  if (s.respuesta.devuelto) html += `<div class="devuelto-banner">🔴 Este checklist fue devuelto para corrección: <strong>${escapeHtml_(s.respuesta.motivo_devolucion || '')}</strong></div>`;
  if (s.respuesta.aprobado) html += `<div class="aprobado-banner">✅ Aprobado — este checklist ya no se puede modificar.</div>`;

  html += `<div class="checklist-header">
    <div class="name">${s.respuesta.pct}% completado ${statusChip(s.respuesta.estado)}</div>
    <div class="progress-bar"><div class="progress-fill" style="width:${s.respuesta.pct}%"></div></div>
  </div>`;

  s.items.forEach((item) => {
    const ie = s.itemEstado[item.id];
    const estado = ie ? ie.estado : 'pendiente';
    const fotoUrl = item.evidencia_tag ? s.fotosByTag[item.evidencia_tag] : null;
    html += `<div class="item-row ${interactive ? '' : 'locked'}">
      <div class="item-main">
        <div class="item-check ${estado === 'ok' ? 'ok' : estado === 'incidencia' ? 'incidencia' : ''}" data-check="${item.id}">${estado === 'ok' ? '✓' : estado === 'incidencia' ? '!' : ''}</div>
        <div class="item-text">${escapeHtml_(item.texto)}</div>
      </div>
      ${item.requiere_foto ? `<div class="item-photo-req">📷 Foto obligatoria: ${EVIDENCIA_LABELS[item.evidencia_tag] || item.evidencia_tag}</div>` : ''}
      ${fotoUrl ? `<div class="photo-thumb-row"><img class="photo-thumb" src="${fotoUrl}"></div>` : ''}
      ${interactive ? `<div class="item-actions">
          <button class="item-action-btn ${estado === 'incidencia' ? 'active' : ''}" data-incidencia="${item.id}">⚠ Incidencia</button>
          ${item.requiere_foto ? `<button class="item-action-btn" data-foto="${item.id}">📷 ${fotoUrl ? 'Repetir foto' : 'Tomar foto'}</button>` : ''}
        </div>` : ''}
      ${ie && ie.nota ? `<div class="item-note">"${escapeHtml_(ie.nota)}"</div>` : ''}
    </div>`;
  });

  // Bloque especial: medidor de agua (Aurora, Servicio apertura)
  if (s.esAuroraMedidor) {
    html += `<div class="extra-block">
      <div class="title">💧 Medidor de agua</div>
      <div class="section-sub" style="margin:0 0 10px;">${s.medidor.anterior ? 'Lectura anterior: ' + s.medidor.anterior.lectura + ' (' + s.medidor.anterior.fecha + ')' : 'Sin lecturas previas registradas'}</div>
      <div class="field"><label>Lectura actual</label><input type="number" id="medidor-lectura" inputmode="decimal" value="${s.medidor.lectura}" ${interactive ? '' : 'disabled'}></div>
      ${s.medidor.fotoUrl ? `<div class="photo-thumb-row"><img class="photo-thumb" src="${s.medidor.fotoUrl}"></div>` : ''}
      ${interactive ? `<button class="btn btn-outline btn-sm" id="medidor-foto-btn" type="button">📷 Foto del medidor</button>` : ''}
    </div>`;
  }

  // Bloque especial: inventario diario (Servicio / Salón — Cierre)
  if (s.esInventario) {
    html += `<div class="extra-block">
      <div class="title">📦 ¿Se envió el inventario diario?</div>
      <div class="radio-group">
        <div class="radio-option ${s.inventario.enviado === true ? 'selected' : ''}" data-inv="si">Sí</div>
        <div class="radio-option ${s.inventario.enviado === false ? 'selected danger' : ''}" data-inv="no">No</div>
      </div>
      ${s.inventario.enviado === false ? `<div class="field"><label>Motivo</label><textarea id="inventario-motivo" rows="2" ${interactive ? '' : 'disabled'}>${escapeHtml_(s.inventario.motivo)}</textarea></div>` : ''}
    </div>`;
  }

  if (interactive) {
    html += `<div class="sticky-submit"><button class="btn btn-primary" id="submit-checklist-btn">Enviar checklist</button></div>`;
  } else if (!s.respuesta.aprobado && s.respuesta.enviado && (AUTH.user.rol === 'admin' || AUTH.user.rol === 'gerente')) {
    html += `<div class="sticky-submit"><button class="btn btn-primary" id="go-review-btn">Ir a revisión / aprobación</button></div>`;
  }

  main.innerHTML = html;

  if (interactive) {
    main.querySelectorAll('[data-check]').forEach((c) => c.addEventListener('click', () => toggleItemOk_(c.dataset.check)));
    main.querySelectorAll('[data-incidencia]').forEach((c) => c.addEventListener('click', () => openIncidenciaModal_(c.dataset.incidencia)));
    main.querySelectorAll('[data-foto]').forEach((c) => c.addEventListener('click', () => captureItemPhoto_(c.dataset.foto)));
    const invSi = main.querySelector('[data-inv="si"]');
    const invNo = main.querySelector('[data-inv="no"]');
    if (invSi) invSi.addEventListener('click', () => { s.inventario.enviado = true; s.inventario.motivo = ''; renderChecklistBody_(true); });
    if (invNo) invNo.addEventListener('click', () => { s.inventario.enviado = false; renderChecklistBody_(true); });
    const medidorBtn = el('medidor-foto-btn');
    if (medidorBtn) medidorBtn.addEventListener('click', captureMedidorPhoto_);
    const submitBtn = el('submit-checklist-btn');
    if (submitBtn) submitBtn.addEventListener('click', submitChecklist_);
  }
  const reviewBtn = el('go-review-btn');
  if (reviewBtn) reviewBtn.addEventListener('click', () => goTo('aprobacion', { respuesta_id: s.respuesta.id }));
}

async function toggleItemOk_(itemId) {
  const s = checklistState;
  const current = s.itemEstado[itemId] ? s.itemEstado[itemId].estado : 'pendiente';
  const nuevo = current === 'ok' ? 'pendiente' : 'ok';
  s.itemEstado[itemId] = { estado: nuevo, nota: '' };
  renderChecklistBody_(true);
  try {
    const r = await api('saveItemEstado', { respuesta_id: s.respuesta.id, item_id: itemId, estado: nuevo });
    if (r.ok === false) showToast(r.error);
    await refreshRespuestaProgreso_();
  } catch (e) { showToast('No se guardó — revisa tu conexión'); }
}

function openIncidenciaModal_(itemId) {
  showModal(`
    <h3>⚠ Reportar incidencia</h3>
    <textarea id="inc-texto" placeholder="Describe qué pasó..."></textarea>
    <div class="modal-actions">
      <button class="btn btn-outline" id="inc-cancel">Cancelar</button>
      <button class="btn btn-danger" id="inc-confirm">Guardar incidencia</button>
    </div>
  `);
  el('inc-cancel').addEventListener('click', hideModal);
  el('inc-confirm').addEventListener('click', async () => {
    const texto = el('inc-texto').value.trim();
    if (!texto) { showToast('Describe la incidencia'); return; }
    try {
      const r = await api('addIncidencia', { respuesta_id: checklistState.respuesta.id, item_id: itemId, texto });
      if (!r.ok) { showToast(r.error); return; }
      checklistState.itemEstado[itemId] = { estado: 'incidencia', nota: texto };
      hideModal();
      renderChecklistBody_(true);
      await refreshRespuestaProgreso_();
      showToast('Incidencia registrada');
    } catch (e) { showToast('No se pudo guardar. Revisa tu conexión.'); }
  });
}

async function captureItemPhoto_(itemId) {
  const item = checklistState.items.filter((it) => it.id === itemId)[0];
  try {
    const { base64, filename, mimeType } = await takePhoto();
    showToast('Subiendo foto…');
    const r = await api('uploadFoto', {
      respuesta_id: checklistState.respuesta.id, tipo_evidencia: item.evidencia_tag,
      sucursal_id: checklistState.sucursal_id, area_id: checklistState.area_id,
      base64, filename, mimeType
    });
    if (!r.ok) { showToast(r.error); return; }
    checklistState.fotosByTag[item.evidencia_tag] = r.url;
    checklistState.itemEstado[itemId] = { estado: 'ok', nota: '' };
    await api('saveItemEstado', { respuesta_id: checklistState.respuesta.id, item_id: itemId, estado: 'ok' });
    renderChecklistBody_(true);
    await refreshRespuestaProgreso_();
    showToast('Foto guardada ✓');
  } catch (e) { /* cancelado o sin conexión */ }
}

async function captureMedidorPhoto_() {
  try {
    const { base64, filename, mimeType } = await takePhoto();
    showToast('Subiendo foto…');
    const r = await api('uploadFoto', {
      respuesta_id: checklistState.respuesta.id, tipo_evidencia: 'medidor_agua',
      sucursal_id: checklistState.sucursal_id, area_id: checklistState.area_id,
      base64, filename, mimeType
    });
    if (!r.ok) { showToast(r.error); return; }
    checklistState.medidor.fotoUrl = r.url;
    renderChecklistBody_(true);
    showToast('Foto guardada ✓');
  } catch (e) {}
}

async function refreshRespuestaProgreso_() {
  try {
    const r = await api('getOrCreateRespuesta', { sucursal_id: checklistState.sucursal_id, area_id: checklistState.area_id, tipo: checklistState.tipo, fecha: todayISO() });
    if (r.ok) checklistState.respuesta = r.respuesta;
  } catch (e) {}
}

async function submitChecklist_() {
  const s = checklistState;
  const extra = {};
  if (s.esAuroraMedidor) {
    const lecturaInput = el('medidor-lectura');
    extra.medidor_lectura = lecturaInput ? lecturaInput.value : s.medidor.lectura;
    extra.medidor_foto_url = s.medidor.fotoUrl;
  }
  if (s.esInventario) {
    extra.inventario_enviado = s.inventario.enviado;
    const motivoInput = el('inventario-motivo');
    extra.inventario_motivo = motivoInput ? motivoInput.value.trim() : s.inventario.motivo;
  }
  const btn = el('submit-checklist-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Enviando…'; }
  try {
    const r = await api('submitRespuesta', { respuesta_id: s.respuesta.id, extra });
    if (!r.ok) { showToast(r.error); if (btn) { btn.disabled = false; btn.textContent = 'Enviar checklist'; } return; }
    showToast('Checklist enviado ✓');
    goBack();
  } catch (e) { showToast('No se pudo enviar. Revisa tu conexión.'); if (btn) { btn.disabled = false; btn.textContent = 'Enviar checklist'; } }
}

// ============================================================
// CAJA — formulario simplificado
// ============================================================
let cajaState = null;

async function renderCaja(params) {
  const sucursalId = params.sucursal_id;
  setTopbar('Caja', sucursalNombre(sucursalId), true);
  const main = el('main-content');
  try {
    const r = await api('getCaja', { sucursal_id: sucursalId, fecha: todayISO() });
    const existente = r.ok ? r.caja : null;
    cajaState = {
      sucursal_id: sucursalId,
      diferencia: existente ? existente.diferencia : null,
      monto: existente ? existente.monto : '',
      explicacion: existente ? existente.explicacion : '',
      fotoArqueoUrl: existente ? existente.foto_arqueo_url : null,
      fotosTerminalUrls: existente && existente.fotos_terminal_urls ? String(existente.fotos_terminal_urls).split(',').filter(Boolean) : [],
      aprobado: existente ? existente.aprobado : false
    };
    renderCajaBody_();
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

function renderCajaBody_() {
  const s = cajaState;
  const interactive = AUTH.user.rol === 'colaborador' && !s.aprobado;
  const main = el('main-content');
  let html = '';

  if (s.aprobado) html += `<div class="aprobado-banner">✅ Caja de hoy aprobada por gerencia.</div>`;

  html += `<div class="extra-block">
    <div class="title">¿Existe diferencia de caja?</div>
    <div class="radio-group">
      <div class="radio-option ${s.diferencia === false ? 'selected' : ''}" data-dif="no">No</div>
      <div class="radio-option ${s.diferencia === true ? 'selected danger' : ''}" data-dif="si">Sí</div>
    </div>
    ${s.diferencia === true ? `
      <div class="field"><label>Monto de la diferencia</label><input type="number" inputmode="decimal" id="caja-monto" value="${s.monto}" placeholder="$0.00" ${interactive ? '' : 'disabled'}></div>
      <div class="field"><label>Explicación</label><textarea id="caja-explicacion" rows="3" ${interactive ? '' : 'disabled'}>${escapeHtml_(s.explicacion)}</textarea></div>
    ` : ''}
  </div>`;

  html += `<div class="extra-block">
    <div class="title">📄 Foto del arqueo de caja (Parrot)</div>
    ${s.fotoArqueoUrl ? `<div class="photo-thumb-row"><img class="photo-thumb" src="${s.fotoArqueoUrl}"></div>` : '<div class="section-sub" style="margin:0 0 10px;">Aún no se ha subido</div>'}
    ${interactive ? `<button class="btn btn-outline btn-sm" id="foto-arqueo-btn" type="button">📷 ${s.fotoArqueoUrl ? 'Repetir foto' : 'Tomar foto'}</button>` : ''}
  </div>`;

  html += `<div class="extra-block">
    <div class="title">🧾 Foto(s) de cortes de terminal</div>
    <div class="photo-thumb-row">${s.fotosTerminalUrls.map((u) => `<img class="photo-thumb" src="${u}">`).join('')}</div>
    ${interactive ? `<button class="btn btn-outline btn-sm" id="foto-terminal-btn" type="button" style="margin-top:8px;">📷 Agregar foto de corte</button>` : ''}
  </div>`;

  if (interactive) html += `<div class="sticky-submit"><button class="btn btn-primary" id="submit-caja-btn">Enviar caja del día</button></div>`;
  else if (!s.aprobado && (AUTH.user.rol === 'admin' || AUTH.user.rol === 'gerente')) {
    html += `<div class="sticky-submit"><button class="btn btn-primary" id="go-review-caja-btn">Ir a revisión / aprobación</button></div>`;
  }

  main.innerHTML = html;

  if (interactive) {
    const difNo = main.querySelector('[data-dif="no"]'); const difSi = main.querySelector('[data-dif="si"]');
    if (difNo) difNo.addEventListener('click', () => { s.diferencia = false; renderCajaBody_(); });
    if (difSi) difSi.addEventListener('click', () => { s.diferencia = true; renderCajaBody_(); });
    const arqueoBtn = el('foto-arqueo-btn');
    if (arqueoBtn) arqueoBtn.addEventListener('click', async () => {
      try {
        const { base64, filename, mimeType } = await takePhoto();
        showToast('Subiendo foto…');
        const r = await api('uploadFoto', { respuesta_id: '', tipo_evidencia: 'caja_arqueo', sucursal_id: s.sucursal_id, area_id: 'AREA-CAJA', base64, filename, mimeType });
        if (!r.ok) { showToast(r.error); return; }
        s.fotoArqueoUrl = r.url; renderCajaBody_(); showToast('Foto guardada ✓');
      } catch (e) {}
    });
    const terminalBtn = el('foto-terminal-btn');
    if (terminalBtn) terminalBtn.addEventListener('click', async () => {
      try {
        const { base64, filename, mimeType } = await takePhoto();
        showToast('Subiendo foto…');
        const r = await api('uploadFoto', { respuesta_id: '', tipo_evidencia: 'caja_terminal', sucursal_id: s.sucursal_id, area_id: 'AREA-CAJA', base64, filename, mimeType });
        if (!r.ok) { showToast(r.error); return; }
        s.fotosTerminalUrls.push(r.url); renderCajaBody_(); showToast('Foto guardada ✓');
      } catch (e) {}
    });
    const submitBtn = el('submit-caja-btn');
    if (submitBtn) submitBtn.addEventListener('click', submitCaja_);
  }
  const reviewBtn = el('go-review-caja-btn');
  if (reviewBtn) reviewBtn.addEventListener('click', () => goTo('aprobacionCaja', { sucursal_id: s.sucursal_id, fecha: todayISO() }));
}

async function submitCaja_() {
  const s = cajaState;
  if (s.diferencia === null) { showToast('Indica si existe diferencia de caja'); return; }
  const montoInput = el('caja-monto'); const expInput = el('caja-explicacion');
  const btn = el('submit-caja-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Enviando…'; }
  try {
    const r = await api('submitCaja', {
      sucursal_id: s.sucursal_id, fecha: todayISO(), diferencia: s.diferencia,
      monto: montoInput ? montoInput.value : s.monto, explicacion: expInput ? expInput.value.trim() : s.explicacion,
      foto_arqueo_url: s.fotoArqueoUrl, fotos_terminal_urls: s.fotosTerminalUrls
    });
    if (!r.ok) { showToast(r.error); if (btn) { btn.disabled = false; btn.textContent = 'Enviar caja del día'; } return; }
    showToast('Caja enviada ✓');
    goBack();
  } catch (e) { showToast('No se pudo enviar. Revisa tu conexión.'); if (btn) { btn.disabled = false; btn.textContent = 'Enviar caja del día'; } }
}

// ============================================================
// APROBACIÓN — checklist normal
// ============================================================
async function renderAprobacion(params) {
  setTopbar('Revisión', 'Checklist', true);
  const main = el('main-content');
  try {
    const r = await api('getRespuestaDetalle', { respuesta_id: params.respuesta_id });
    if (!r.ok) { main.innerHTML = errorBlock_(r.error); return; }
    const resp = r.respuesta;
    setTopbar(areaNombre(resp.area_id) + ' — ' + (resp.tipo === 'apertura' ? 'Apertura' : 'Cierre'), sucursalNombre(resp.sucursal_id), true);

    const itemMap = {}; r.itemsEstado.forEach((ri) => { itemMap[ri.item_id] = ri; });
    const fotosByTag = {}; r.fotos.forEach((f) => { fotosByTag[f.tipo_evidencia] = f.drive_url; });

    let html = '';
    if (resp.aprobado) html += `<div class="aprobado-banner">✅ Aprobado por ${escapeHtml_(resp.aprobado_por)} — ${escapeHtml_(resp.comentario_aprobacion || 'sin comentarios')}</div>`;
    if (resp.devuelto) html += `<div class="devuelto-banner">🔴 Devuelto: ${escapeHtml_(resp.motivo_devolucion || '')}</div>`;

    html += `<div class="approve-summary">
      <div style="font-weight:700;margin-bottom:6px;">${resp.pct}% completado ${statusChip(resp.estado)}</div>
      <div class="section-sub" style="margin:0;">Enviado por ${escapeHtml_((r.usuario || {}).nombre || '—')} · ${escapeHtml_(resp.enviado_at || '')}</div>
    </div>`;

    if (r.incidencias.length) {
      html += '<div class="section-title">Incidencias reportadas</div>';
      r.incidencias.forEach((inc) => { html += `<div class="area-card"><div class="section-sub" style="margin:0;">⚠ ${escapeHtml_(inc.texto)}</div></div>`; });
    }

    html += '<div class="section-title">Checklist</div>';
    r.items.forEach((item) => {
      const ie = itemMap[item.id];
      const estado = ie ? ie.estado : 'pendiente';
      const fotoUrl = item.evidencia_tag ? fotosByTag[item.evidencia_tag] : null;
      html += `<div class="item-row">
        <div class="item-main">
          <div class="item-check ${estado === 'ok' ? 'ok' : estado === 'incidencia' ? 'incidencia' : ''}">${estado === 'ok' ? '✓' : estado === 'incidencia' ? '!' : ''}</div>
          <div class="item-text">${escapeHtml_(item.texto)}</div>
        </div>
        ${fotoUrl ? `<div class="photo-thumb-row"><img class="photo-thumb" src="${fotoUrl}"></div>` : ''}
        ${ie && ie.nota ? `<div class="item-note">"${escapeHtml_(ie.nota)}"</div>` : ''}
      </div>`;
    });

    if (!resp.aprobado && resp.enviado && (AUTH.user.rol === 'admin' || AUTH.user.rol === 'gerente')) {
      html += `<div class="approve-buttons">
        <button class="btn btn-outline" id="devolver-btn">Devolver para corrección</button>
        <button class="btn btn-primary" id="aprobar-btn">Dar Visto Bueno</button>
      </div>`;
    }

    main.innerHTML = html;
    const aprobarBtn = el('aprobar-btn');
    if (aprobarBtn) aprobarBtn.addEventListener('click', () => aprobarConComentario_(resp.id));
    const devolverBtn = el('devolver-btn');
    if (devolverBtn) devolverBtn.addEventListener('click', () => devolverConMotivo_(resp.id));
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

function aprobarConComentario_(respuestaId) {
  showModal(`
    <h3>Dar Visto Bueno</h3>
    <textarea id="aprob-comentario" placeholder="Comentario (opcional)"></textarea>
    <div class="modal-actions">
      <button class="btn btn-outline" id="aprob-cancel">Cancelar</button>
      <button class="btn btn-primary" id="aprob-confirm">Confirmar Visto Bueno</button>
    </div>
  `);
  el('aprob-cancel').addEventListener('click', hideModal);
  el('aprob-confirm').addEventListener('click', async () => {
    const comentario = el('aprob-comentario').value.trim();
    try {
      const r = await api('aprobarRespuesta', { respuesta_id: respuestaId, comentario });
      if (!r.ok) { showToast(r.error); return; }
      hideModal(); showToast('Visto Bueno registrado ✓'); goBack();
    } catch (e) { showToast('No se pudo guardar. Revisa tu conexión.'); }
  });
}

function devolverConMotivo_(respuestaId) {
  showModal(`
    <h3>Devolver para corrección</h3>
    <textarea id="dev-motivo" placeholder="¿Qué debe corregirse?"></textarea>
    <div class="modal-actions">
      <button class="btn btn-outline" id="dev-cancel">Cancelar</button>
      <button class="btn btn-danger" id="dev-confirm">Devolver</button>
    </div>
  `);
  el('dev-cancel').addEventListener('click', hideModal);
  el('dev-confirm').addEventListener('click', async () => {
    const motivo = el('dev-motivo').value.trim();
    if (!motivo) { showToast('Indica qué debe corregirse'); return; }
    try {
      const r = await api('devolverRespuesta', { respuesta_id: respuestaId, motivo });
      if (!r.ok) { showToast(r.error); return; }
      hideModal(); showToast('Devuelto para corrección'); goBack();
    } catch (e) { showToast('No se pudo guardar. Revisa tu conexión.'); }
  });
}

// ============================================================
// APROBACIÓN — caja
// ============================================================
async function renderAprobacionCaja(params) {
  setTopbar('Revisión de caja', sucursalNombre(params.sucursal_id), true);
  const main = el('main-content');
  try {
    const r = await api('getCaja', { sucursal_id: params.sucursal_id, fecha: params.fecha || todayISO() });
    if (!r.ok || !r.caja) { main.innerHTML = errorBlock_('Aún no hay caja capturada para hoy'); return; }
    const c = r.caja;
    const fotosTerminal = c.fotos_terminal_urls ? String(c.fotos_terminal_urls).split(',').filter(Boolean) : [];

    let html = '';
    if (c.aprobado) html += `<div class="aprobado-banner">✅ Caja aprobada.</div>`;
    html += `<div class="approve-summary">
      <div style="font-weight:700;margin-bottom:6px;">${c.diferencia ? '🔴 Diferencia reportada' : '✅ Sin diferencia'}</div>
      ${c.diferencia ? `<div class="section-sub" style="margin:0 0 4px;">Monto: $${escapeHtml_(String(c.monto))}</div><div class="section-sub" style="margin:0;">${escapeHtml_(c.explicacion || '')}</div>` : ''}
    </div>`;

    html += '<div class="section-title">Arqueo de caja (Parrot)</div>';
    html += c.foto_arqueo_url ? `<div class="photo-thumb-row"><img class="photo-thumb" style="width:100px;height:100px;" src="${c.foto_arqueo_url}"></div>` : '<div class="section-sub">Sin foto</div>';

    html += '<div class="section-title">Cortes de terminal</div>';
    html += fotosTerminal.length ? `<div class="photo-thumb-row">${fotosTerminal.map((u) => `<img class="photo-thumb" style="width:100px;height:100px;" src="${u}">`).join('')}</div>` : '<div class="section-sub">Sin fotos</div>';

    if (!c.aprobado && (AUTH.user.rol === 'admin' || AUTH.user.rol === 'gerente')) {
      html += `<div class="approve-buttons">
        <button class="btn btn-outline" id="devolver-caja-btn">Devolver para corrección</button>
        <button class="btn btn-primary" id="aprobar-caja-btn">Dar Visto Bueno</button>
      </div>`;
    }

    main.innerHTML = html;
    const aprobarBtn = el('aprobar-caja-btn');
    if (aprobarBtn) aprobarBtn.addEventListener('click', () => aprobarCajaConComentario_(c.id));
    const devolverBtn = el('devolver-caja-btn');
    if (devolverBtn) devolverBtn.addEventListener('click', () => devolverCajaConMotivo_(c.id));
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión. Intenta de nuevo.'); }
}

function aprobarCajaConComentario_(cajaId) {
  showModal(`<h3>Dar Visto Bueno a caja</h3><textarea id="aprobc-comentario" placeholder="Comentario (opcional)"></textarea>
    <div class="modal-actions"><button class="btn btn-outline" id="aprobc-cancel">Cancelar</button><button class="btn btn-primary" id="aprobc-confirm">Confirmar</button></div>`);
  el('aprobc-cancel').addEventListener('click', hideModal);
  el('aprobc-confirm').addEventListener('click', async () => {
    try {
      const r = await api('aprobarCaja', { caja_id: cajaId, comentario: el('aprobc-comentario').value.trim() });
      if (!r.ok) { showToast(r.error); return; }
      hideModal(); showToast('Caja aprobada ✓'); goBack();
    } catch (e) { showToast('No se pudo guardar.'); }
  });
}

function devolverCajaConMotivo_(cajaId) {
  showModal(`<h3>Devolver caja</h3><textarea id="devc-motivo" placeholder="¿Qué debe corregirse?"></textarea>
    <div class="modal-actions"><button class="btn btn-outline" id="devc-cancel">Cancelar</button><button class="btn btn-danger" id="devc-confirm">Devolver</button></div>`);
  el('devc-cancel').addEventListener('click', hideModal);
  el('devc-confirm').addEventListener('click', async () => {
    const motivo = el('devc-motivo').value.trim();
    if (!motivo) { showToast('Indica qué debe corregirse'); return; }
    try {
      const r = await api('devolverCaja', { caja_id: cajaId, motivo });
      if (!r.ok) { showToast(r.error); return; }
      hideModal(); showToast('Devuelta para corrección'); goBack();
    } catch (e) { showToast('No se pudo guardar.'); }
  });
}

// ============================================================
// PENDIENTES (lista completa)
// ============================================================
async function renderPendientes() {
  setTopbar('Pendientes de aprobación', '', true);
  const main = el('main-content');
  try {
    const r = await api('getPendientesAprobacion', {});
    if (!r.ok) { main.innerHTML = errorBlock_(r.error); return; }
    if (!r.pendientes.length) { main.innerHTML = '<div class="atencion-empty">Sin pendientes 🎉</div>'; return; }
    main.innerHTML = r.pendientes.map((p, idx) => `
      <div class="pendiente-card" data-pend="${idx}">
        <span>${escapeHtml_(p.sucursal_nombre)} — ${escapeHtml_(p.area_nombre)} (${p.tipo === 'apertura' ? 'Apertura' : 'Cierre'}) ${p.pct}%</span>
        <span class="chev">›</span>
      </div>`).join('');
    main.querySelectorAll('[data-pend]').forEach((c) => c.addEventListener('click', () => {
      const p = r.pendientes[Number(c.dataset.pend)];
      if (p.area_id === 'AREA-CAJA') goTo('aprobacionCaja', { sucursal_id: p.sucursal_id, fecha: p.fecha });
      else goTo('aprobacion', { respuesta_id: p.respuesta_id });
    }));
  } catch (e) { main.innerHTML = errorBlock_('Sin conexión.'); }
}

// ============================================================
// HISTÓRICO
// ============================================================
let histFilters = { periodo: '7', sucursal_id: '', area_id: '' };

async function renderHistorico() {
  setTopbar('Histórico', 'Cumplimiento por periodo', false);
  const main = el('main-content');
  if (AUTH.user.rol !== 'admin') histFilters.sucursal_id = AUTH.user.sucursal_id;

  let html = '<div class="filter-row">';
  [['1', 'Hoy'], ['7', '7 días'], ['30', '30 días']].forEach(([val, lbl]) => {
    html += `<div class="filter-chip ${histFilters.periodo === val ? 'active' : ''}" data-periodo="${val}">${lbl}</div>`;
  });
  html += '</div>';

  if (AUTH.user.rol === 'admin') {
    html += '<div class="filter-row">';
    html += `<div class="filter-chip ${!histFilters.sucursal_id ? 'active' : ''}" data-suc="">Todas</div>`;
    BOOT.sucursales.forEach((s) => { html += `<div class="filter-chip ${histFilters.sucursal_id === s.id ? 'active' : ''}" data-suc="${s.id}">${escapeHtml_(s.codigo)}</div>`; });
    html += '</div>';
  }

  html += '<div class="filter-row">';
  html += `<div class="filter-chip ${!histFilters.area_id ? 'active' : ''}" data-area="">Todas las áreas</div>`;
  BOOT.areas.forEach((a) => { html += `<div class="filter-chip ${histFilters.area_id === a.id ? 'active' : ''}" data-area="${a.id}">${escapeHtml_(a.nombre)}</div>`; });
  html += '</div>';

  html += '<div id="hist-chart-container"></div>';
  main.innerHTML = html;

  main.querySelectorAll('[data-periodo]').forEach((c) => c.addEventListener('click', () => { histFilters.periodo = c.dataset.periodo; renderHistorico(); }));
  main.querySelectorAll('[data-suc]').forEach((c) => c.addEventListener('click', () => { histFilters.sucursal_id = c.dataset.suc; renderHistorico(); }));
  main.querySelectorAll('[data-area]').forEach((c) => c.addEventListener('click', () => { histFilters.area_id = c.dataset.area; renderHistorico(); }));

  await loadHistoricoChart_();
}

async function loadHistoricoChart_() {
  const dias = Number(histFilters.periodo);
  const fin = new Date(); const inicio = new Date(); inicio.setDate(inicio.getDate() - (dias - 1));
  const fechaInicio = inicio.toISOString().slice(0, 10); const fechaFin = fin.toISOString().slice(0, 10);

  const box = el('hist-chart-container');
  box.innerHTML = '<div style="display:flex;justify-content:center;padding:30px 0;"><div class="spinner"></div></div>';
  try {
    const r = await api('getHistorico', { sucursal_id: histFilters.sucursal_id || undefined, area_id: histFilters.area_id || undefined, fecha_inicio: fechaInicio, fecha_fin: fechaFin });
    if (!r.ok) { box.innerHTML = errorBlock_(r.error); return; }
    if (!r.serie.length) { box.innerHTML = '<div class="atencion-empty">Sin datos en este periodo todavía.</div>'; return; }

    const bars = r.serie.map((p) => {
      const cls = p.pct >= 90 ? '' : p.pct >= 70 ? 'mid' : 'low';
      const d = new Date(p.fecha + 'T00:00:00');
      const lbl = d.toLocaleDateString('es-MX', { day: '2-digit', month: 'short' });
      return `<div class="chart-bar-col"><div class="chart-bar ${cls}" style="height:${Math.max(p.pct, 2)}%"></div><div class="chart-label">${lbl}</div></div>`;
    }).join('');

    let rows = r.serie.slice().reverse().map((p) => `<div class="hist-row"><span>${p.fecha}</span><span>${p.pct}%</span></div>`).join('');

    box.innerHTML = `<div class="chart-box"><div class="chart-bars">${bars}</div></div><div class="chart-box">${rows}</div>`;
  } catch (e) { box.innerHTML = errorBlock_('Sin conexión.'); }
}

// ============================================================
// PERFIL
// ============================================================
function renderPerfil() {
  setTopbar('Tu cuenta', '', false);
  const user = AUTH.user;
  el('main-content').innerHTML = `
    <div class="area-card">
      <div class="area-card-title" style="margin-bottom:10px;">${escapeHtml_(user.nombre)}</div>
      <div class="hist-row"><span>Usuario</span><span>${escapeHtml_(user.usuario)}</span></div>
      <div class="hist-row"><span>Rol</span><span>${roleLabel(user.rol)}</span></div>
      ${user.sucursal_id ? `<div class="hist-row"><span>Sucursal</span><span>${escapeHtml_(sucursalNombre(user.sucursal_id))}</span></div>` : ''}
    </div>
    <button class="btn btn-outline" id="cambiar-pass-btn" style="margin-top:14px;">Cambiar contraseña</button>
  `;
  el('cambiar-pass-btn').addEventListener('click', () => {
    showModal(`<h3>Cambiar contraseña</h3>
      <div class="field"><input type="password" id="nueva-pass" placeholder="Nueva contraseña (mín. 6 caracteres)"></div>
      <div class="modal-actions"><button class="btn btn-outline" id="pass-cancel">Cancelar</button><button class="btn btn-primary" id="pass-confirm">Guardar</button></div>`);
    el('pass-cancel').addEventListener('click', hideModal);
    el('pass-confirm').addEventListener('click', async () => {
      const val = el('nueva-pass').value;
      try {
        const r = await api('changePassword', { newPassword: val });
        if (!r.ok) { showToast(r.error); return; }
        hideModal(); showToast('Contraseña actualizada ✓');
      } catch (e) { showToast('No se pudo actualizar.'); }
    });
  });
}

// ---------- service worker ----------
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => { navigator.serviceWorker.register('sw.js').catch(() => {}); });
}

boot();

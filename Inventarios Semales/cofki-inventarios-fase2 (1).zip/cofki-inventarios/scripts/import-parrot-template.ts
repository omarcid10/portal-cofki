// scripts/import-parrot-template.ts
//
// Importa (o re-importa) la plantilla real de Parrot hacia Supabase:
//   - crea/actualiza `areas` (clave lógica: parrot_sheet_name)
//   - crea/actualiza `items` (clave lógica: parrot_id)
//   - si un item existía antes y ya NO aparece en la plantilla nueva,
//     se marca active = false (nunca se borra, para conservar historial)
//
// Idempotente: se puede correr muchas veces con la misma plantilla (o una
// actualizada) sin duplicar nada.
//
// Uso:
//   npm run import:catalog -- ./ruta/al/reporte-conteo.xlsx
//
// Requiere variables de entorno (ver .env.example):
//   VITE_SUPABASE_URL
//   SUPABASE_SERVICE_ROLE_KEY   <- clave de servicio, NUNCA en el frontend

import 'dotenv/config';
import * as fs from 'node:fs';
import * as XLSX from 'xlsx';
import { createClient } from '@supabase/supabase-js';
import { parseParrotTemplate } from '../src/lib/parrotTemplateParser';

async function main() {
  const filePath = process.argv[2];
  if (!filePath) {
    console.error('Uso: npm run import:catalog -- <ruta-al-archivo.xlsx>');
    process.exit(1);
  }
  if (!fs.existsSync(filePath)) {
    console.error(`No se encontró el archivo: ${filePath}`);
    process.exit(1);
  }

  const supabaseUrl = process.env.VITE_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!supabaseUrl || !serviceKey) {
    console.error('Faltan VITE_SUPABASE_URL y/o SUPABASE_SERVICE_ROLE_KEY en el entorno.');
    process.exit(1);
  }

  const supabase = createClient(supabaseUrl, serviceKey);

  console.log(`Leyendo ${filePath} ...`);
  const buffer = fs.readFileSync(filePath);
  const workbook = XLSX.read(buffer, { type: 'buffer' });

  const { areas, items } = parseParrotTemplate(workbook);

  console.log(`Detectadas ${areas.length} áreas y ${items.length} productos.`);

  // ---------------------------------------------------------------------
  // 1) Upsert de áreas (clave lógica: parrot_sheet_name)
  // ---------------------------------------------------------------------
  const { data: upsertedAreas, error: areasError } = await supabase
    .from('areas')
    .upsert(
      areas.map((a) => ({
        name: a.name,
        category: a.category,
        parrot_sheet_name: a.parrot_sheet_name,
        parrot_area_label: a.parrot_area_label,
        sort_order: a.sort_order,
        active: true,
      })),
      { onConflict: 'parrot_sheet_name' },
    )
    .select('id, parrot_sheet_name');

  if (areasError) {
    console.error('Error al hacer upsert de áreas:', areasError);
    process.exit(1);
  }

  const areaIdBySheet = new Map<string, string>();
  for (const a of upsertedAreas ?? []) {
    areaIdBySheet.set(a.parrot_sheet_name, a.id);
  }
  console.log(`Áreas sincronizadas: ${areaIdBySheet.size}`);

  // ---------------------------------------------------------------------
  // 2) Upsert de items (clave lógica: parrot_id)
  // ---------------------------------------------------------------------
  const itemRows = items.map((it) => {
    const areaId = areaIdBySheet.get(it.parrot_sheet_name);
    if (!areaId) {
      throw new Error(`No se encontró area_id para la hoja "${it.parrot_sheet_name}" (producto ${it.parrot_id}).`);
    }
    return {
      parrot_id: it.parrot_id,
      name: it.name,
      presentation_name: it.presentation_name,
      unit: it.unit,
      area_id: areaId,
      parrot_sheet_name: it.parrot_sheet_name,
      parrot_row: it.parrot_row,
      sort_order: it.sort_order,
      active: true,
    };
  });

  // Se sube en lotes para no exceder límites de payload.
  const BATCH_SIZE = 200;
  let upserted = 0;
  for (let i = 0; i < itemRows.length; i += BATCH_SIZE) {
    const batch = itemRows.slice(i, i + BATCH_SIZE);
    const { error } = await supabase.from('items').upsert(batch, { onConflict: 'parrot_id' });
    if (error) {
      console.error(`Error al hacer upsert de items (lote ${i}-${i + batch.length}):`, error);
      process.exit(1);
    }
    upserted += batch.length;
  }
  console.log(`Productos sincronizados: ${upserted}`);

  // ---------------------------------------------------------------------
  // 3) Desactivar items que ya no están en la plantilla (nunca se borran)
  // ---------------------------------------------------------------------
  const currentParrotIds = items.map((i) => i.parrot_id);
  const { data: existing, error: existingError } = await supabase
    .from('items')
    .select('id, parrot_id, active');

  if (existingError) {
    console.error('Error al leer items existentes:', existingError);
    process.exit(1);
  }

  const toDeactivate = (existing ?? [])
    .filter((row) => row.active && !currentParrotIds.includes(row.parrot_id))
    .map((row) => row.id);

  if (toDeactivate.length > 0) {
    const { error: deactivateError } = await supabase
      .from('items')
      .update({ active: false })
      .in('id', toDeactivate);
    if (deactivateError) {
      console.error('Error al desactivar productos obsoletos:', deactivateError);
      process.exit(1);
    }
    console.log(`Productos marcados como inactivos (ya no están en la plantilla): ${toDeactivate.length}`);
  } else {
    console.log('No hay productos para desactivar.');
  }

  console.log('Importación completada correctamente.');
}

main().catch((err) => {
  console.error('Error inesperado durante la importación:', err);
  process.exit(1);
});

// Tipos del catálogo Parrot (áreas / items), compartidos entre el importador
// y el resto de la app.

export type Category = 'Barra y Servicio' | 'Cocina' | 'Nannies';

export interface ParsedArea {
  name: string; // nombre amigable, ej. "Abarrotes"
  category: Category;
  parrot_sheet_name: string; // nombre EXACTO de hoja (incluye espacios finales si los hay)
  parrot_area_label: string | null; // columna J, texto completo sin truncar
  sort_order: number;
}

export interface ParsedItem {
  parrot_id: string;
  name: string;
  presentation_name: string | null;
  unit: string; // columna E
  parrot_sheet_name: string;
  parrot_row: number; // número de fila real en Excel (1-indexado)
  sort_order: number;
}

export interface ParsedTemplate {
  areas: ParsedArea[];
  items: ParsedItem[];
}

export type Role = 'ADMIN' | 'MANAGER' | 'COUNT_USER';

export interface Branch {
  id: string;
  name: string;
  code: string;
  active: boolean;
}

export interface Profile {
  id: string;
  full_name: string | null;
  role: Role;
  active: boolean;
}

export type Category = 'Barra y Servicio' | 'Cocina' | 'Nannies';

export interface Area {
  id: string;
  name: string;
  category: Category;
  parrot_sheet_name: string;
  parrot_area_label: string | null;
  sort_order: number;
  active: boolean;
}

export interface Item {
  id: string;
  parrot_id: string;
  name: string;
  presentation_name: string | null;
  unit: string;
  area_id: string;
  active: boolean;
  sort_order: number;
}

export type SessionStatus = 'NOT_STARTED' | 'IN_PROGRESS' | 'COMPLETED' | 'EXPORTED';

export interface InventorySession {
  id: string;
  inventory_week_id: string;
  branch_id: string;
  status: SessionStatus;
  started_at: string | null;
  completed_at: string | null;
}

export interface InventoryCount {
  id: string;
  inventory_session_id: string;
  item_id: string;
  quantity: number | null;
  counted_by: string | null;
  counted_at: string | null;
}

export interface AreaProgress {
  areaId: string;
  total: number;
  counted: number;
}

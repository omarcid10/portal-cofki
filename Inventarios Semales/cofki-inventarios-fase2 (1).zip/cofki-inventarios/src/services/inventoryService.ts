import { supabase } from '../lib/supabaseClient';
import type { InventoryCount, InventorySession } from '../types/inventory';

/**
 * Obtiene (o crea, si es la primera vez que alguien cuenta en esta sucursal
 * esta semana) la sesión de inventario activa. Ver
 * supabase/migrations/0005_get_or_create_session.sql para el porqué de este
 * RPC en vez de un simple insert/select.
 */
export async function getOrCreateSession(branchId: string): Promise<InventorySession> {
  const { data, error } = await supabase.rpc('get_or_create_active_session', {
    p_branch_id: branchId,
  });
  if (error) throw error;
  return data as InventorySession;
}

export async function getCountsForSession(sessionId: string): Promise<Map<string, number | null>> {
  const { data, error } = await supabase
    .from('inventory_counts')
    .select('item_id, quantity')
    .eq('inventory_session_id', sessionId);

  if (error) throw error;

  const map = new Map<string, number | null>();
  for (const row of data as Pick<InventoryCount, 'item_id' | 'quantity'>[]) {
    map.set(row.item_id, row.quantity);
  }
  return map;
}

export async function completeSession(sessionId: string): Promise<InventorySession> {
  const { data, error } = await supabase.rpc('complete_inventory_session', {
    p_session_id: sessionId,
  });
  if (error) throw error;
  return data as InventorySession;
}

// ---------------------------------------------------------------------------
// Autosave con protección básica contra pérdida de conexión.
// Si el upsert falla por red, el conteo se guarda en localStorage y se
// reintenta automáticamente al volver la conexión (evento 'online') o al
// volver a abrir la app. Deliberadamente simple: no es una cola offline
// completa, solo evita perder lo que el usuario acaba de capturar.
// ---------------------------------------------------------------------------

const PENDING_KEY = 'cofki_pending_counts';

interface PendingCount {
  sessionId: string;
  itemId: string;
  quantity: number;
  userId: string;
  savedAt: number;
}

function readPending(): PendingCount[] {
  try {
    const raw = localStorage.getItem(PENDING_KEY);
    return raw ? (JSON.parse(raw) as PendingCount[]) : [];
  } catch {
    return [];
  }
}

function writePending(items: PendingCount[]) {
  localStorage.setItem(PENDING_KEY, JSON.stringify(items));
}

function queuePending(entry: PendingCount) {
  const pending = readPending().filter(
    (p) => !(p.sessionId === entry.sessionId && p.itemId === entry.itemId),
  );
  pending.push(entry);
  writePending(pending);
}

function unqueuePending(sessionId: string, itemId: string) {
  writePending(readPending().filter((p) => !(p.sessionId === sessionId && p.itemId === itemId)));
}

export function hasPendingCounts(sessionId: string): boolean {
  return readPending().some((p) => p.sessionId === sessionId);
}

/**
 * Guarda una cantidad capturada. quantity puede ser 0 (válido) — nunca se
 * debe llamar con null/undefined desde la UI (eso significa "no tocar").
 */
export async function upsertCount(
  sessionId: string,
  itemId: string,
  quantity: number,
  userId: string,
): Promise<void> {
  const { error } = await supabase.from('inventory_counts').upsert(
    {
      inventory_session_id: sessionId,
      item_id: itemId,
      quantity,
      counted_by: userId,
      counted_at: new Date().toISOString(),
    },
    { onConflict: 'inventory_session_id,item_id' },
  );

  if (error) {
    // Probablemente sin conexión: se encola para reintentar, no se pierde.
    queuePending({ sessionId, itemId, quantity, userId, savedAt: Date.now() });
    throw error;
  }

  unqueuePending(sessionId, itemId);
}

/** Reintenta todos los conteos pendientes de esta sesión. Se llama al volver la conexión. */
export async function flushPendingCounts(sessionId: string): Promise<{ ok: number; failed: number }> {
  const pending = readPending().filter((p) => p.sessionId === sessionId);
  let ok = 0;
  let failed = 0;

  for (const p of pending) {
    try {
      await upsertCount(p.sessionId, p.itemId, p.quantity, p.userId);
      ok++;
    } catch {
      failed++;
    }
  }

  return { ok, failed };
}

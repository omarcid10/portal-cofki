import { supabase } from '../lib/supabaseClient';
import type { Area, Branch, Item } from '../types/inventory';

export async function getActiveBranches(): Promise<Branch[]> {
  const { data, error } = await supabase
    .from('branches')
    .select('id, name, code, active')
    .eq('active', true)
    .order('name', { ascending: true });

  if (error) throw error;
  return data as Branch[];
}

export async function getBranchByCode(code: string): Promise<Branch | null> {
  const { data, error } = await supabase
    .from('branches')
    .select('id, name, code, active')
    .eq('code', code)
    .eq('active', true)
    .maybeSingle();

  if (error) throw error;
  return data as Branch | null;
}

export async function getAreaById(areaId: string): Promise<Area | null> {
  const { data, error } = await supabase
    .from('areas')
    .select('id, name, category, parrot_sheet_name, parrot_area_label, sort_order, active')
    .eq('id', areaId)
    .maybeSingle();

  if (error) throw error;
  return data as Area | null;
}

export async function getActiveAreas(): Promise<Area[]> {
  const { data, error } = await supabase
    .from('areas')
    .select('id, name, category, parrot_sheet_name, parrot_area_label, sort_order, active')
    .eq('active', true)
    .order('sort_order', { ascending: true });

  if (error) throw error;
  return data as Area[];
}

export async function getActiveItems(): Promise<Item[]> {
  const { data, error } = await supabase
    .from('items')
    .select('id, parrot_id, name, presentation_name, unit, area_id, active, sort_order')
    .eq('active', true)
    .order('sort_order', { ascending: true });

  if (error) throw error;
  return data as Item[];
}

export async function getItemsByArea(areaId: string): Promise<Item[]> {
  const { data, error } = await supabase
    .from('items')
    .select('id, parrot_id, name, presentation_name, unit, area_id, active, sort_order')
    .eq('area_id', areaId)
    .eq('active', true)
    .order('sort_order', { ascending: true });

  if (error) throw error;
  return data as Item[];
}

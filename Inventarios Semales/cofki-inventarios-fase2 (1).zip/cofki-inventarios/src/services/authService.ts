import { supabase } from '../lib/supabaseClient';
import type { Profile } from '../types/inventory';

export async function signIn(email: string, password: string) {
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
}

export async function signOut() {
  await supabase.auth.signOut();
}

export async function getMyProfile(): Promise<Profile | null> {
  const { data: auth } = await supabase.auth.getUser();
  if (!auth.user) return null;

  const { data, error } = await supabase
    .from('profiles')
    .select('id, full_name, role, active')
    .eq('id', auth.user.id)
    .single();

  if (error) throw error;
  return data as Profile;
}

// Parser del archivo Parrot (fuente de verdad).
// Extrae áreas (una por hoja) e items (una por fila de producto).
//
// Reglas clave (ver ANALISIS_EXCEL.md para el detalle completo):
//   - Fila 1: agrupadores. Fila 2: encabezados generales. Fila 3: encabezados
//     de columna. Fila 4 en adelante: productos.
//   - Columna A = ID Parrot (identificador real, NO usar el nombre).
//   - Columna B = Nombre. Columna C = Nombre de presentación.
//   - Columna D = Cantidad física (la que la app debe llenar). NUNCA se lee
//     al importar el catálogo; solo se escribe al exportar.
//   - Columna E = Unidad asociada a la columna D. Esta es la unidad real que
//     se muestra al usuario.
//   - Columna J = "Area de Almacenamiento": texto completo (sin el límite de
//     31 caracteres que trunca los nombres de hoja de Excel). Se usa para
//     derivar el nombre amigable del área.

import * as XLSX from 'xlsx';
import type { Category, ParsedArea, ParsedItem, ParsedTemplate } from '../types/catalog';

const HEADER_ROWS = 3; // filas 1-3 son encabezados; los datos inician en la fila 4 (index 3)

const CATEGORY_PREFIXES: { prefix: string; category: Category }[] = [
  { prefix: 'Barra y servicio', category: 'Barra y Servicio' },
  { prefix: 'Cocina', category: 'Cocina' },
  { prefix: 'Nannies', category: 'Nannies' },
];

function detectCategory(sheetName: string): Category {
  const trimmed = sheetName.trim();
  const found = CATEGORY_PREFIXES.find((c) => trimmed.startsWith(c.prefix));
  if (!found) {
    throw new Error(
      `No se pudo determinar la categoría de la hoja "${sheetName}". ` +
        `Se esperaba que iniciara con "Barra y servicio", "Cocina" o "Nannies".`,
    );
  }
  return found.category;
}

function friendlyAreaName(areaLabel: string | null, sheetName: string, category: Category): string {
  let rest = (areaLabel || sheetName).trim();
  const prefixObj = CATEGORY_PREFIXES.find((c) => c.category === category);
  if (prefixObj && rest.toLowerCase().startsWith(prefixObj.prefix.toLowerCase())) {
    rest = rest.slice(prefixObj.prefix.length).trim();
  }
  if (rest.length === 0) return sheetName.trim();
  return rest.charAt(0).toUpperCase() + rest.slice(1);
}

/**
 * Parsea el workbook completo de Parrot y devuelve las áreas e items
 * detectados. No toca la base de datos: es puro.
 */
export function parseParrotTemplate(workbook: XLSX.WorkBook): ParsedTemplate {
  const areas: ParsedArea[] = [];
  const items: ParsedItem[] = [];
  const seenParrotIds = new Set<string>();

  workbook.SheetNames.forEach((sheetName, sheetIdx) => {
    const ws = workbook.Sheets[sheetName];
    if (!ws['!ref']) return; // hoja vacía, se ignora

    const range = XLSX.utils.decode_range(ws['!ref']);
    const category = detectCategory(sheetName);

    let areaLabel: string | null = null;
    let rowCount = 0;

    for (let r = HEADER_ROWS; r <= range.e.r; r++) {
      const cell = (c: number) => ws[XLSX.utils.encode_cell({ r, c })]?.v;

      const parrotId = cell(0);
      if (parrotId === undefined || parrotId === null || String(parrotId).trim() === '') {
        continue; // fila sin producto (posible fila en blanco al final)
      }

      const parrotIdStr = String(parrotId).trim();
      if (seenParrotIds.has(parrotIdStr)) {
        throw new Error(
          `ID Parrot duplicado: "${parrotIdStr}" (hoja "${sheetName}", fila ${r + 1}). ` +
            `Cada ID debe ser único en todo el archivo.`,
        );
      }
      seenParrotIds.add(parrotIdStr);

      const name = cell(1);
      if (!name) {
        throw new Error(`Producto sin nombre en hoja "${sheetName}", fila ${r + 1} (parrot_id ${parrotIdStr}).`);
      }

      const presentation = cell(2);
      const unit = cell(4);
      if (!unit) {
        throw new Error(`Producto sin unidad (columna E) en hoja "${sheetName}", fila ${r + 1}.`);
      }

      const areaCell = cell(9);
      if (areaLabel === null && areaCell) areaLabel = String(areaCell);

      items.push({
        parrot_id: parrotIdStr,
        name: String(name).trim(),
        presentation_name: presentation ? String(presentation).trim() : null,
        unit: String(unit).trim(),
        parrot_sheet_name: sheetName,
        parrot_row: r + 1, // convertir a número de fila Excel (1-indexado)
        sort_order: rowCount,
      });
      rowCount++;
    }

    areas.push({
      name: friendlyAreaName(areaLabel, sheetName, category),
      category,
      parrot_sheet_name: sheetName,
      parrot_area_label: areaLabel,
      sort_order: sheetIdx,
    });
  });

  return { areas, items };
}

interface ProgressBarProps {
  value: number; // 0-100
  complete?: boolean;
}

export function ProgressBar({ value, complete }: ProgressBarProps) {
  const clamped = Math.max(0, Math.min(100, value));
  return (
    <div className="h-2 w-full rounded-full bg-neutral-200 overflow-hidden">
      <div
        className={`h-full rounded-full transition-all duration-300 ${
          complete ? 'bg-jungle' : 'bg-honey'
        }`}
        style={{ width: `${clamped}%` }}
      />
    </div>
  );
}

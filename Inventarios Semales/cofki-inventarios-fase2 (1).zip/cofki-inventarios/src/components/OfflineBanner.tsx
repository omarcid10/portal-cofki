import { useOnlineStatus } from '../hooks/useOnlineStatus';

export function OfflineBanner() {
  const online = useOnlineStatus();
  if (online) return null;

  return (
    <div className="fixed top-0 inset-x-0 z-50 bg-candy text-white text-center text-sm font-semibold py-2">
      ⚠ Sin conexión — tus capturas se guardarán en cuanto vuelva la señal
    </div>
  );
}

export type SaveState = 'idle' | 'saving' | 'saved' | 'error';

export function SaveIndicator({ state }: { state: SaveState }) {
  if (state === 'idle') return <span className="text-sm text-seal">&nbsp;</span>;
  if (state === 'saving') return <span className="text-sm text-seal">Guardando…</span>;
  if (state === 'error') return <span className="text-sm text-candy">⚠ No se pudo guardar, reintentando…</span>;
  return <span className="text-sm text-jungle font-medium">✓ Guardado</span>;
}

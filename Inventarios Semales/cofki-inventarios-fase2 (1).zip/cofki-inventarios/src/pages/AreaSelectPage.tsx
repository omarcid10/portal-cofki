import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getActiveAreas, getActiveItems, getBranchByCode } from '../services/catalogService';
import { getCountsForSession, getOrCreateSession, completeSession } from '../services/inventoryService';
import { ProgressBar } from '../components/ProgressBar';
import { OfflineBanner } from '../components/OfflineBanner';
import type { Area, Branch, InventorySession, Item } from '../types/inventory';

const CATEGORY_ORDER = ['Barra y Servicio', 'Cocina', 'Nannies'] as const;

export function AreaSelectPage() {
  const { branchCode } = useParams<{ branchCode: string }>();
  const navigate = useNavigate();

  const [branch, setBranch] = useState<Branch | null>(null);
  const [session, setSession] = useState<InventorySession | null>(null);
  const [areas, setAreas] = useState<Area[]>([]);
  const [items, setItems] = useState<Item[]>([]);
  const [counts, setCounts] = useState<Map<string, number | null>>(new Map());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [completing, setCompleting] = useState(false);

  async function loadAll() {
    if (!branchCode) return;
    setLoading(true);
    setError(null);
    try {
      const b = await getBranchByCode(branchCode);
      if (!b) {
        setError('Sucursal no encontrada.');
        return;
      }
      setBranch(b);

      const [s, a, i] = await Promise.all([getOrCreateSession(b.id), getActiveAreas(), getActiveItems()]);
      setSession(s);
      setAreas(a);
      setItems(i);
      setCounts(await getCountsForSession(s.id));
    } catch {
      setError('No se pudo cargar el inventario. Revisa tu conexión.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [branchCode]);

  const itemsByArea = useMemo(() => {
    const map = new Map<string, Item[]>();
    for (const it of items) {
      const list = map.get(it.area_id) ?? [];
      list.push(it);
      map.set(it.area_id, list);
    }
    return map;
  }, [items]);

  const areaProgress = useMemo(() => {
    const map = new Map<string, { total: number; counted: number }>();
    for (const area of areas) {
      const areaItems = itemsByArea.get(area.id) ?? [];
      const counted = areaItems.filter((it) => counts.get(it.id) !== undefined && counts.get(it.id) !== null).length;
      map.set(area.id, { total: areaItems.length, counted });
    }
    return map;
  }, [areas, itemsByArea, counts]);

  const overall = useMemo(() => {
    const total = items.length;
    const counted = items.filter((it) => counts.get(it.id) !== undefined && counts.get(it.id) !== null).length;
    return { total, counted };
  }, [items, counts]);

  const areasByCategory = useMemo(() => {
    const grouped = new Map<string, Area[]>();
    for (const area of areas) {
      const list = grouped.get(area.category) ?? [];
      list.push(area);
      grouped.set(area.category, list);
    }
    return grouped;
  }, [areas]);

  async function handleComplete() {
    if (!session) return;
    setCompleting(true);
    try {
      const updated = await completeSession(session.id);
      setSession(updated);
    } catch {
      setError('No se pudo completar: revisa que todos los productos tengan cantidad.');
    } finally {
      setCompleting(false);
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center text-seal">Cargando…</div>
    );
  }

  if (error && !branch) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-3 px-6 text-center">
        <p className="text-candy">{error}</p>
        <button onClick={() => navigate('/')} className="text-jungle underline">
          Volver a sucursales
        </button>
      </div>
    );
  }

  const overallPct = overall.total > 0 ? Math.round((overall.counted / overall.total) * 100) : 0;
  const isComplete = overall.total > 0 && overall.counted === overall.total;
  const isFinalized = session?.status === 'COMPLETED' || session?.status === 'EXPORTED';

  return (
    <div className="min-h-screen bg-neutral-50 pb-12">
      <OfflineBanner />

      <header className="px-6 pt-10 pb-4">
        <button onClick={() => navigate('/')} className="text-sm text-seal mb-2">
          ← Sucursales
        </button>
        <h1 className="text-2xl font-bold text-elephant">{branch?.name}</h1>
        <p className="text-sm text-seal mb-3">Inventario semanal</p>

        <ProgressBar value={overallPct} complete={isComplete} />
        <div className="flex items-center justify-between mt-1.5">
          <span className="text-sm text-seal">
            {overall.counted} / {overall.total} productos
          </span>
          <span className="text-sm font-semibold text-elephant">{overallPct}%</span>
        </div>

        {isFinalized && (
          <p className="mt-3 text-jungle font-semibold text-sm">✓ Inventario completado</p>
        )}
        {!isFinalized && isComplete && (
          <button
            onClick={handleComplete}
            disabled={completing}
            className="mt-4 w-full rounded-xl bg-jungle text-white font-semibold py-3 disabled:opacity-60"
          >
            {completing ? 'Completando…' : 'Marcar inventario como completo'}
          </button>
        )}
        {error && branch && <p className="mt-3 text-sm text-candy">{error}</p>}
      </header>

      <main className="px-6 space-y-8">
        {CATEGORY_ORDER.filter((cat) => areasByCategory.has(cat)).map((category) => (
          <section key={category}>
            <h2 className="text-sm font-semibold text-seal uppercase tracking-wide mb-3">{category}</h2>
            <div className="space-y-2.5">
              {(areasByCategory.get(category) ?? []).map((area) => {
                const p = areaProgress.get(area.id) ?? { total: 0, counted: 0 };
                const pct = p.total > 0 ? Math.round((p.counted / p.total) * 100) : 0;
                const done = p.total > 0 && p.counted === p.total;
                return (
                  <button
                    key={area.id}
                    onClick={() => navigate(`/${branchCode}/${area.id}`)}
                    className="w-full text-left rounded-2xl bg-white border border-neutral-200 px-4 py-4 shadow-sm active:scale-[0.99] transition-transform"
                  >
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-semibold text-elephant">{area.name}</span>
                      <span className="text-sm text-seal">
                        {done ? '✓' : `${p.counted}/${p.total}`}
                      </span>
                    </div>
                    <ProgressBar value={pct} complete={done} />
                  </button>
                );
              })}
            </div>
          </section>
        ))}
      </main>
    </div>
  );
}

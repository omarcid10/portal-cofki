import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getActiveBranches } from '../services/catalogService';
import { useAuth } from '../context/AuthContext';
import type { Branch } from '../types/inventory';

export function BranchSelectPage() {
  const [branches, setBranches] = useState<Branch[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const navigate = useNavigate();
  const { signOut } = useAuth();

  useEffect(() => {
    getActiveBranches()
      .then(setBranches)
      .catch(() => setError('No se pudieron cargar las sucursales.'))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="min-h-screen bg-neutral-50 px-6 py-10 flex flex-col">
      <header className="mb-8 flex items-start justify-between">
        <div>
          <p className="text-sm text-seal font-medium">COFKI</p>
          <h1 className="text-2xl font-bold text-elephant">Inventario semanal</h1>
        </div>
        <button onClick={signOut} className="text-sm text-seal underline">
          Salir
        </button>
      </header>

      <p className="text-sm text-seal mb-4">Selecciona sucursal</p>

      {loading && <p className="text-seal">Cargando…</p>}
      {error && <p className="text-candy">{error}</p>}

      <div className="space-y-3">
        {branches.map((b) => (
          <button
            key={b.id}
            onClick={() => navigate(`/${b.code}`)}
            className="w-full text-left rounded-2xl bg-white border border-neutral-200 px-5 py-5 text-lg font-semibold text-elephant shadow-sm active:scale-[0.99] transition-transform"
          >
            {b.name}
          </button>
        ))}
      </div>
    </div>
  );
}

import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getAreaById, getBranchByCode, getItemsByArea } from '../services/catalogService';
import {
  flushPendingCounts,
  getCountsForSession,
  getOrCreateSession,
  upsertCount,
} from '../services/inventoryService';
import { useAuth } from '../context/AuthContext';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { ProgressBar } from '../components/ProgressBar';
import { OfflineBanner } from '../components/OfflineBanner';
import { SaveIndicator, type SaveState } from '../components/SaveIndicator';
import type { Area, Branch, InventorySession, Item } from '../types/inventory';

const SAVE_DEBOUNCE_MS = 500;
const AUTO_ADVANCE_DELAY_MS = 650;

function isDecimalUnit(unit: string): boolean {
  const u = unit.trim().toLowerCase();
  return u === 'kg' || u === 'g' || u === 'l' || u === 'ml';
}

export function CapturePage() {
  const { branchCode, areaId } = useParams<{ branchCode: string; areaId: string }>();
  const navigate = useNavigate();
  const { session: authSession } = useAuth();
  const online = useOnlineStatus();
  const userId = authSession?.user.id ?? null;

  const [branch, setBranch] = useState<Branch | null>(null);
  const [area, setArea] = useState<Area | null>(null);
  const [invSession, setInvSession] = useState<InventorySession | null>(null);
  const [items, setItems] = useState<Item[]>([]);
  const [counts, setCounts] = useState<Record<string, number | null>>({});
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [inputValue, setInputValue] = useState('');
  const [saveState, setSaveState] = useState<SaveState>('idle');

  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const advanceTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    async function load() {
      if (!branchCode || !areaId) return;
      setLoading(true);
      setLoadError(null);
      try {
        const b = await getBranchByCode(branchCode);
        if (!b) throw new Error('branch');
        const a = await getAreaById(areaId);
        if (!a) throw new Error('area');
        const s = await getOrCreateSession(b.id);
        const its = await getItemsByArea(areaId);
        const cts = await getCountsForSession(s.id);

        setBranch(b);
        setArea(a);
        setInvSession(s);
        setItems(its);
        setCounts(Object.fromEntries(cts));
        setCurrentIndex(0);
      } catch {
        setLoadError('No se pudo cargar el área. Revisa tu conexión.');
      } finally {
        setLoading(false);
      }
    }
    load();
  }, [branchCode, areaId]);

  // Reintenta lo pendiente al recuperar conexión.
  useEffect(() => {
    if (online && invSession) {
      flushPendingCounts(invSession.id);
    }
  }, [online, invSession]);

  const currentItem = items[currentIndex] as Item | undefined;
  const isFinalized = invSession?.status === 'COMPLETED' || invSession?.status === 'EXPORTED';

  // Sincroniza el input de texto cuando cambia el producto actual.
  useEffect(() => {
    if (!currentItem) return;
    const existing = counts[currentItem.id];
    setInputValue(existing === null || existing === undefined ? '' : String(existing));
    setSaveState('idle');
  }, [currentItem, counts]);

  const clearTimers = useCallback(() => {
    if (saveTimer.current) clearTimeout(saveTimer.current);
    if (advanceTimer.current) clearTimeout(advanceTimer.current);
  }, []);

  useEffect(() => clearTimers, [currentIndex, clearTimers]);

  const countedTotal = useMemo(
    () => items.filter((it) => counts[it.id] !== undefined && counts[it.id] !== null).length,
    [items, counts],
  );
  const areaComplete = items.length > 0 && countedTotal === items.length;

  function goToIndex(idx: number) {
    clearTimers();
    setCurrentIndex(Math.max(0, Math.min(items.length - 1, idx)));
  }

  function handleChange(raw: string) {
    setInputValue(raw);
    clearTimers();

    if (raw.trim() === '') {
      setSaveState('idle');
      return;
    }

    const num = Number(raw);
    if (Number.isNaN(num) || num < 0) {
      setSaveState('idle');
      return;
    }

    setSaveState('saving');
    saveTimer.current = setTimeout(() => void doSave(num), SAVE_DEBOUNCE_MS);
  }

  async function doSave(num: number) {
    if (!invSession || !currentItem || !userId) return;
    try {
      await upsertCount(invSession.id, currentItem.id, num, userId);
      setCounts((prev) => ({ ...prev, [currentItem.id]: num }));
      setSaveState('saved');

      advanceTimer.current = setTimeout(() => {
        if (currentIndex < items.length - 1) {
          goToIndex(currentIndex + 1);
        }
      }, AUTO_ADVANCE_DELAY_MS);
    } catch {
      setSaveState('error');
    }
  }

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-seal">Cargando…</div>;
  }

  if (loadError || !currentItem) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-3 px-6 text-center">
        <p className="text-candy">{loadError ?? 'Esta área no tiene productos activos.'}</p>
        <button onClick={() => navigate(`/${branchCode}`)} className="text-jungle underline">
          Volver a áreas
        </button>
      </div>
    );
  }

  const decimal = isDecimalUnit(currentItem.unit);
  const progressPct = items.length > 0 ? Math.round((countedTotal / items.length) * 100) : 0;

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col">
      <OfflineBanner />

      <header className="px-6 pt-10 pb-3">
        <button onClick={() => navigate(`/${branchCode}`)} className="text-sm text-seal mb-2">
          ← {branch?.name}
        </button>
        <p className="text-sm text-seal mb-2">{area?.name}</p>
        <ProgressBar value={progressPct} complete={areaComplete} />
        <div className="flex items-center justify-between mt-1.5">
          <span className="text-sm text-seal">
            {currentIndex + 1} / {items.length} productos
          </span>
          {areaComplete && <span className="text-sm font-semibold text-jungle">Área completada ✓</span>}
        </div>
      </header>

      <main className="flex-1 flex flex-col justify-center px-6">
        <div className="bg-white rounded-3xl border border-neutral-200 shadow-sm p-6">
          <h1 className="text-2xl font-bold text-elephant leading-snug mb-1">{currentItem.name}</h1>
          {currentItem.presentation_name && (
            <p className="text-sm text-seal mb-4">{currentItem.presentation_name}</p>
          )}
          <p className="text-sm text-seal mb-1">Unidad: {currentItem.unit}</p>

          <label className="block text-sm font-medium text-seal mt-4 mb-1" htmlFor="qty">
            Cantidad
          </label>
          <input
            id="qty"
            type="number"
            inputMode={decimal ? 'decimal' : 'numeric'}
            step={decimal ? '0.01' : '1'}
            min="0"
            value={inputValue}
            disabled={isFinalized}
            onChange={(e) => handleChange(e.target.value)}
            placeholder="0"
            className="w-full text-4xl font-bold text-elephant rounded-2xl border border-neutral-300 px-4 py-4 focus:outline-none focus:ring-2 focus:ring-jungle disabled:bg-neutral-100 disabled:text-seal"
            autoFocus
          />
          <div className="mt-2 h-5">
            <SaveIndicator state={saveState} />
          </div>
        </div>

        <div className="flex items-center justify-between mt-6">
          <button
            onClick={() => goToIndex(currentIndex - 1)}
            disabled={currentIndex === 0}
            className="px-5 py-3 rounded-xl text-elephant font-medium disabled:opacity-30"
          >
            ← Anterior
          </button>
          <button
            onClick={() => goToIndex(currentIndex + 1)}
            disabled={currentIndex === items.length - 1}
            className="px-5 py-3 rounded-xl bg-elephant text-white font-medium disabled:opacity-30"
          >
            Siguiente →
          </button>
        </div>
      </main>
    </div>
  );
}

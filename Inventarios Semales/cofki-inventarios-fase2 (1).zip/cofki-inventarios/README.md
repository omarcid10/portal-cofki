# COFKI INVENTARIOS

App para digitalizar el inventario semanal de las sucursales de Cofki y
generar el Excel listo para cargar a Parrot.

**Estado actual: FASE 1 (base de datos) + FASE 2 (frontend de captura)
completas.** Falta el dashboard gerencial (Fase 3) y la exportación real a
Excel (Fase 4).

## Qué existe hoy

```
supabase/migrations/
  0001_schema.sql                   -- tablas, triggers, RPC complete_inventory_session
  0002_rls.sql                       -- funciones helper + políticas RLS
  0003_seed_branches.sql             -- Aurora, Pueblo Serena, GM3
  0004_storage.sql                   -- bucket privado para la plantilla Parrot
  0005_get_or_create_session.sql     -- RPC para crear la sesión semanal on-demand

src/
  types/                 -- tipos compartidos (catálogo + inventario)
  lib/
    parrotTemplateParser.ts  -- lee el xlsx y devuelve áreas + items (puro, sin DB)
    supabaseClient.ts        -- cliente de Supabase para el navegador
  context/AuthContext.tsx    -- sesión + perfil/rol
  services/
    authService.ts           -- login/logout/perfil
    catalogService.ts         -- sucursales, áreas, items
    inventoryService.ts       -- sesión, conteos, autosave con cola local
  components/
    ProgressBar.tsx, OfflineBanner.tsx, SaveIndicator.tsx
  pages/
    LoginPage.tsx
    BranchSelectPage.tsx    -- selección de sucursal
    AreaSelectPage.tsx      -- selección de área, agrupada por categoría, con progreso
    CapturePage.tsx         -- captura con autosave y avance automático
  App.tsx, main.tsx

scripts/
  import-parrot-template.ts -- corre el parser y hace upsert en Supabase

ANALISIS_EXCEL.md   -- análisis completo del archivo real de Parrot
```

## Cómo probarlo

### Base de datos (si todavía no la has corrido)

1. Crear el proyecto en Supabase.
2. Correr las 5 migraciones en orden (SQL editor o `supabase db push`):
   `0001_schema.sql → 0002_rls.sql → 0003_seed_branches.sql → 0004_storage.sql → 0005_get_or_create_session.sql`.
3. Copiar `.env.example` a `.env` y llenar `VITE_SUPABASE_URL`,
   `VITE_SUPABASE_ANON_KEY` (Settings → API) y `SUPABASE_SERVICE_ROLE_KEY`
   (solo para el importador, nunca en el frontend).
4. `npm install`
5. `npm run import:catalog -- ./reporte-conteo-2026-09-14.xlsx` — debe
   reportar 16 áreas / 228 productos.

### Frontend

6. Crear al menos un usuario para probar. Dos formas:
   - Desde Supabase → Authentication → Users → "Add user" (con contraseña).
   - O habilitar el registro por correo en Supabase Auth y registrarte desde
     la propia app (no hay pantalla de registro todavía, así que por ahora
     usa la opción de arriba).
7. `npm run dev` y abre la URL que imprime (también funciona desde el
   celular si estás en la misma red: usa la IP que muestra, no
   `localhost`).
8. Inicia sesión con el usuario que creaste.
9. Selecciona una sucursal → una categoría/área → captura una cantidad.
   Debe aparecer "Guardando…" y luego "✓ Guardado", y avanzar solo al
   siguiente producto.
10. Cierra el navegador y vuelve a entrar: la cantidad capturada debe
    seguir ahí (se guardó en Supabase, no solo en el navegador).
11. Cuando todos los productos de la sucursal tengan cantidad, en la
    pantalla de áreas debe aparecer el botón "Marcar inventario como
    completo".

El build de producción (`npm run build`) ya se probó localmente y compila
sin errores (405 KB / 116 KB gzip — ligero).

## Qué necesitas configurar de tu lado

- Correr las migraciones 0001-0005 si aún no lo has hecho (ver arriba).
- Crear tu primer usuario y promoverlo a `ADMIN`:
  ```sql
  update profiles set role = 'ADMIN' where id = '<uuid-del-usuario>';
  ```
  (Por ahora no cambia nada visible en el frontend — el catálogo se
  administra por script, no hay pantalla de admin todavía. Sirve para
  cuando construyamos Fase 3.)

## Qué falta (próximas fases)

- **Fase 3:** dashboard gerencial (`/manager`) — 3 sucursales, % de avance,
  detalle por sucursal, áreas/productos pendientes.
- **Fase 4:** `generateParrotInventoryExcel()` — exportación real, abriendo
  la plantilla original y escribiendo solo columna D.
- **Fase 5:** pruebas de seguridad/edge cases.
- **Fase 6:** deployment (GitHub + Vercel + Supabase producción).

Todavía no existe: pantalla de registro/gestión de usuarios, subida de la
plantilla Parrot a Storage desde una UI (por ahora la importación se corre
localmente contra el archivo), ni ninguna pantalla de administración —
todo eso es Fase 3 en adelante.

## Decisiones que tomé en Fase 2 (avísame si algo no es lo que esperabas)

1. **RPC `get_or_create_active_session`** (migración 0005, nueva): con la
   RLS tal como quedó en Fase 1, un `COUNT_USER` podía leer/actualizar
   sesiones pero no crearlas — solo `MANAGER`/`ADMIN` podían. Eso bloquearía
   a un colaborador la primera vez que alguien cuenta en una sucursal en la
   semana. Agregué esta función (seguro, no permite elegir semana ni
   duplicar sesiones) para que la sesión se cree sola la primera vez que
   alguien entra a capturar.
2. **Avance automático:** después de guardar una cantidad, la app espera
   ~0.65s sin más tecleo y avanza sola al siguiente producto. Si el guardado
   falla (sin conexión), no avanza y muestra el aviso de reintento.
3. **Cola local simple para pérdida de conexión:** si el guardado falla por
   red, la cantidad se guarda en `localStorage` y se reintenta sola al
   volver la señal (evento `online`) o al recargar la página. No es una
   cola offline completa (no se pidió) — solo evita perder lo que el
   usuario acaba de capturar.
4. **Decimales por unidad:** `kg`, `g`, `l`, `ml` permiten decimales
   (`inputMode="decimal"`); cualquier otra unidad (como `pza`, que es la
   única otra que existe hoy en el catálogo real) usa `inputMode="numeric"`
   con paso de 1.
5. **Login:** implementé correo + contraseña (`supabase.auth.signInWithPassword`).
   No hay pantalla de registro — los usuarios se crean desde el panel de
   Supabase por ahora. Si prefieres magic link o algo distinto, es un
   cambio contenido a `LoginPage.tsx` y `authService.ts`.

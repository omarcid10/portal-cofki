/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Paleta oficial del Manual de Identidad Cofki (sistema de color primario)
        candy: '#FF5252', // rojo — errores / validación
        jungle: '#00BFA5', // verde-azulado — acción primaria / completado
        honey: '#FFA726', // naranja — en progreso
        butter: '#FFD180', // naranja claro — acentos suaves
        elephant: '#424242', // gris oscuro — texto principal
        seal: '#757575', // gris medio — texto secundario
      },
      fontFamily: {
        sans: ['Montserrat', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};

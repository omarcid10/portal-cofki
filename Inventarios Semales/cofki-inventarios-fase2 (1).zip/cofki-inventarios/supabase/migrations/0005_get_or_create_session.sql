-- ============================================================================
-- COFKI INVENTARIOS — 0005_get_or_create_session.sql
--
-- Necesidad detectada al construir Fase 2: con la RLS actual, un COUNT_USER
-- puede LEER/ACTUALIZAR sesiones (sessions_select / sessions_count_user_update_status)
-- pero no puede CREARLAS (solo MANAGER/ADMIN vía sessions_admin_write). Eso
-- significa que si nadie con esos roles ha creado antes la sesión de la
-- semana para una sucursal, un colaborador de conteo se quedaría bloqueado
-- al entrar por primera vez.
--
-- Esta función (security definer) resuelve eso: dado un branch_id, obtiene
-- (o crea, si no existe) la semana ISO actual y la sesión de esa sucursal
-- para esa semana, y la regresa. Es segura porque:
--   - No permite elegir semana ni branch_id arbitrario fuera de lo que ya
--     puede ver el usuario (branches es de lectura pública para autenticados).
--   - Respeta el UNIQUE(inventory_week_id, branch_id): si la sesión ya
--     existe, no la duplica, solo la regresa.
--   - No cambia el status de sesiones existentes ni permite pasarlas a
--     COMPLETED (eso solo lo hace complete_inventory_session()).
-- ============================================================================

create or replace function get_or_create_active_session(p_branch_id uuid)
returns inventory_sessions as $$
declare
  v_week_code text;
  v_week_id   uuid;
  v_start     date;
  v_session   inventory_sessions;
begin
  if not exists (select 1 from branches where id = p_branch_id and active = true) then
    raise exception 'Sucursal no válida o inactiva' using errcode = 'P0001';
  end if;

  -- Semana ISO (lunes a domingo), ej. '2026-W38'
  v_week_code := to_char(now(), 'IYYY') || '-W' || to_char(now(), 'IW');
  v_start := date_trunc('week', now())::date;

  insert into inventory_weeks (week_code, start_date, end_date)
  values (v_week_code, v_start, v_start + 6)
  on conflict (week_code) do nothing;

  select id into v_week_id from inventory_weeks where week_code = v_week_code;

  insert into inventory_sessions (inventory_week_id, branch_id, created_by)
  values (v_week_id, p_branch_id, auth.uid())
  on conflict (inventory_week_id, branch_id) do nothing;

  select * into v_session
  from inventory_sessions
  where inventory_week_id = v_week_id and branch_id = p_branch_id;

  return v_session;
end;
$$ language plpgsql security definer set search_path = public;

comment on function get_or_create_active_session is 'Punto de entrada único para el frontend: obtiene o crea (idempotente) la sesión de inventario de la semana actual para una sucursal. No permite completar ni duplicar sesiones.';

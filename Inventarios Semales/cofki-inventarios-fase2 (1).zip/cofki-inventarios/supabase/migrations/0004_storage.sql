-- ============================================================================
-- COFKI INVENTARIOS — 0004_storage.sql
-- Bucket privado para la(s) plantilla(s) xlsx de Parrot.
-- Los archivos de inventario GENERADOS no se guardan aquí: se arman al vuelo
-- en el navegador (bajo demanda) y no requieren persistirse.
-- ============================================================================

insert into storage.buckets (id, name, public)
values ('parrot-templates', 'parrot-templates', false)
on conflict (id) do nothing;

-- Solo ADMIN puede leer/escribir la plantilla original.
create policy parrot_templates_storage_admin
  on storage.objects
  for all
  to authenticated
  using (bucket_id = 'parrot-templates' and is_admin())
  with check (bucket_id = 'parrot-templates' and is_admin());

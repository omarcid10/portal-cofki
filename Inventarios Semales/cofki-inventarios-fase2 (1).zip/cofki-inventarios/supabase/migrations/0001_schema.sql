-- ============================================================================
-- COFKI INVENTARIOS — 0001_schema.sql
-- Esquema base: sucursales, perfiles/roles, áreas, catálogo, semanas,
-- sesiones de inventario y conteos.
-- ============================================================================

create extension if not exists pgcrypto; -- gen_random_uuid()

-- ----------------------------------------------------------------------------
-- Función utilitaria: mantener updated_at
-- ----------------------------------------------------------------------------
create or replace function set_updated_at()
returns trigger as $$
begin
  new.updated_at = now();
  return new;
end;
$$ language plpgsql;

-- ----------------------------------------------------------------------------
-- branches — sucursales (no hardcodeadas en el código)
-- ----------------------------------------------------------------------------
create table branches (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  code        text not null unique,
  active      boolean not null default true,
  created_at  timestamptz not null default now()
);

comment on table branches is 'Sucursales de Cofki. Ej: Aurora, Pueblo Serena, GM3.';

-- ----------------------------------------------------------------------------
-- profiles — extiende auth.users con rol de aplicación
-- ----------------------------------------------------------------------------
create table profiles (
  id          uuid primary key references auth.users (id) on delete cascade,
  full_name   text,
  role        text not null default 'COUNT_USER'
              check (role in ('ADMIN', 'MANAGER', 'COUNT_USER')),
  active      boolean not null default true,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

comment on table profiles is 'Rol de aplicación por usuario. 1:1 con auth.users.';

create trigger trg_profiles_updated_at
  before update on profiles
  for each row execute function set_updated_at();

-- Crear automáticamente un profile (rol COUNT_USER) cuando se crea un auth.user
create or replace function handle_new_auth_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, new.raw_user_meta_data ->> 'full_name')
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer set search_path = public;

create trigger trg_on_auth_user_created
  after insert on auth.users
  for each row execute function handle_new_auth_user();

-- ----------------------------------------------------------------------------
-- user_branches — sucursales autorizadas para un COUNT_USER
-- ----------------------------------------------------------------------------
create table user_branches (
  user_id     uuid not null references profiles (id) on delete cascade,
  branch_id   uuid not null references branches (id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (user_id, branch_id)
);

comment on table user_branches is 'Reservada para uso futuro. Actualmente NO se aplica ninguna restricción por usuario (decisión confirmada: cualquier COUNT_USER activo opera cualquier sucursal) — ver has_branch_access() en 0002_rls.sql.';

-- ----------------------------------------------------------------------------
-- areas — corresponde 1:1 a una hoja del archivo Parrot
-- ----------------------------------------------------------------------------
create table areas (
  id                  uuid primary key default gen_random_uuid(),
  name                text not null,                 -- nombre amigable, ej. "Abarrotes"
  category            text not null
                      check (category in ('Barra y Servicio', 'Cocina', 'Nannies')),
  parrot_sheet_name   text not null unique,           -- nombre EXACTO de la hoja en el xlsx (incluye espacios finales)
  parrot_area_label   text,                           -- valor de columna J "Area de Almacenamiento" (texto completo, sin truncar)
  sort_order          int not null default 0,
  active              boolean not null default true,
  created_at          timestamptz not null default now()
);

comment on table areas is 'Áreas de inventario. parrot_sheet_name debe coincidir exactamente con el nombre de hoja del Excel Parrot.';

-- ----------------------------------------------------------------------------
-- items — catálogo de productos, 1:1 con una fila de una hoja Parrot
-- ----------------------------------------------------------------------------
create table items (
  id                  uuid primary key default gen_random_uuid(),
  parrot_id           text not null unique,           -- identificador real, ej. IN-1724777243159
  name                text not null,
  presentation_name   text,
  unit                text not null,                  -- columna E del Excel ("kg", "pza", ...)
  area_id             uuid not null references areas (id),
  parrot_sheet_name   text not null,                  -- redundante pero explícito, debe = areas.parrot_sheet_name
  parrot_row          int not null,                   -- número de fila EXACTO en la hoja (1-indexado, tal como Excel)
  active              boolean not null default true,
  sort_order          int not null default 0,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  unique (parrot_sheet_name, parrot_row)
);

comment on table items is 'Catálogo de insumos Parrot. parrot_id es la clave lógica de negocio (no el nombre).';

create index idx_items_area_id on items (area_id);
create index idx_items_active on items (active);

create trigger trg_items_updated_at
  before update on items
  for each row execute function set_updated_at();

-- ----------------------------------------------------------------------------
-- parrot_templates — versión de la plantilla original de Parrot (Supabase Storage)
-- ----------------------------------------------------------------------------
create table parrot_templates (
  id            uuid primary key default gen_random_uuid(),
  file_name     text not null,
  storage_path  text not null,      -- ruta dentro del bucket 'parrot-templates'
  version       int not null default 1,
  active        boolean not null default true,
  created_at    timestamptz not null default now(),
  created_by    uuid references profiles (id)
);

comment on table parrot_templates is 'Plantillas xlsx originales de Parrot, almacenadas en Supabase Storage (bucket parrot-templates). Nunca en GitHub.';

-- ----------------------------------------------------------------------------
-- inventory_weeks — concepto de semana de inventario
-- ----------------------------------------------------------------------------
create table inventory_weeks (
  id          uuid primary key default gen_random_uuid(),
  week_code   text not null unique,     -- ej. '2026-W38'
  start_date  date not null,
  end_date    date not null,
  status      text not null default 'OPEN' check (status in ('OPEN', 'CLOSED')),
  created_at  timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- inventory_sessions — un inventario por sucursal por semana
-- ----------------------------------------------------------------------------
create table inventory_sessions (
  id                  uuid primary key default gen_random_uuid(),
  inventory_week_id   uuid not null references inventory_weeks (id),
  branch_id           uuid not null references branches (id),
  status              text not null default 'NOT_STARTED'
                      check (status in ('NOT_STARTED', 'IN_PROGRESS', 'COMPLETED', 'EXPORTED')),
  started_at          timestamptz,
  completed_at        timestamptz,
  created_by          uuid references profiles (id),
  completed_by        uuid references profiles (id),
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now(),
  unique (inventory_week_id, branch_id)
);

create index idx_sessions_branch on inventory_sessions (branch_id);
create index idx_sessions_week on inventory_sessions (inventory_week_id);

create trigger trg_sessions_updated_at
  before update on inventory_sessions
  for each row execute function set_updated_at();

-- ----------------------------------------------------------------------------
-- inventory_counts — detalle de conteo por producto
-- IMPORTANTE: quantity es NULLABLE a propósito. NULL = no contado. 0 = contado en cero.
-- ----------------------------------------------------------------------------
create table inventory_counts (
  id                      uuid primary key default gen_random_uuid(),
  inventory_session_id   uuid not null references inventory_sessions (id) on delete cascade,
  item_id                 uuid not null references items (id),
  quantity                numeric,             -- NULL ≠ 0. Ver comentario arriba.
  counted_by              uuid references profiles (id),
  counted_at              timestamptz,
  updated_at              timestamptz not null default now(),
  unique (inventory_session_id, item_id)
);

comment on column inventory_counts.quantity is 'NULL = producto aún no contado. 0 = contado, cantidad física es cero. Nunca tratar NULL como 0.';

create index idx_counts_session on inventory_counts (inventory_session_id);
create index idx_counts_item on inventory_counts (item_id);

create trigger trg_counts_updated_at
  before update on inventory_counts
  for each row execute function set_updated_at();

-- ----------------------------------------------------------------------------
-- Trigger: al insertar/actualizar un conteo, marcar la sesión IN_PROGRESS
-- (si estaba NOT_STARTED) y registrar started_at.
-- ----------------------------------------------------------------------------
create or replace function mark_session_in_progress()
returns trigger as $$
begin
  update inventory_sessions
     set status = 'IN_PROGRESS',
         started_at = coalesce(started_at, now())
   where id = new.inventory_session_id
     and status = 'NOT_STARTED';
  return new;
end;
$$ language plpgsql security definer set search_path = public;

create trigger trg_counts_mark_in_progress
  after insert on inventory_counts
  for each row execute function mark_session_in_progress();

-- ----------------------------------------------------------------------------
-- RPC: complete_inventory_session
-- Único mecanismo permitido para marcar COMPLETED. Valida server-side que
-- TODOS los items activos del catálogo tengan quantity IS NOT NULL para esa
-- sesión. El valor 0 cuenta como completado; NULL no.
-- ----------------------------------------------------------------------------
create or replace function complete_inventory_session(p_session_id uuid)
returns inventory_sessions as $$
declare
  v_missing int;
  v_session inventory_sessions;
begin
  select count(*) into v_missing
  from items i
  left join inventory_counts c
    on c.item_id = i.id and c.inventory_session_id = p_session_id
  where i.active = true
    and c.quantity is null;

  if v_missing > 0 then
    raise exception 'No se puede completar: % producto(s) sin contar', v_missing
      using errcode = 'P0001';
  end if;

  update inventory_sessions
     set status = 'COMPLETED',
         completed_at = now(),
         completed_by = auth.uid()
   where id = p_session_id
  returning * into v_session;

  return v_session;
end;
$$ language plpgsql security definer set search_path = public;

comment on function complete_inventory_session is 'Única vía permitida para marcar un inventario COMPLETED. Valida server-side que no existan productos activos sin contar (quantity IS NULL).';

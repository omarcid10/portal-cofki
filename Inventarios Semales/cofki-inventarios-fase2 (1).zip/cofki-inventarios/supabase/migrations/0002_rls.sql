-- ============================================================================
-- COFKI INVENTARIOS — 0002_rls.sql
-- Row Level Security. El frontend NUNCA es la única barrera de seguridad.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- Funciones helper (security definer, evitan recursión de RLS)
-- ----------------------------------------------------------------------------
create or replace function current_role_is(p_roles text[])
returns boolean as $$
  select exists (
    select 1 from profiles
    where id = auth.uid()
      and role = any (p_roles)
      and active = true
  );
$$ language sql stable security definer set search_path = public;

create or replace function is_admin() returns boolean as $$
  select current_role_is(array['ADMIN']);
$$ language sql stable security definer set search_path = public;

create or replace function is_manager_or_admin() returns boolean as $$
  select current_role_is(array['ADMIN', 'MANAGER']);
$$ language sql stable security definer set search_path = public;

-- Decisión (confirmada): por ahora CUALQUIER usuario autenticado y activo
-- puede operar CUALQUIER sucursal (sin restricción por usuario). La tabla
-- user_branches se conserva para el día que se quiera activar la
-- restricción — en ese caso basta con cambiar esta función para que vuelva
-- a consultar user_branches, sin tocar el resto del esquema ni el frontend.
create or replace function has_branch_access(p_branch_id uuid) returns boolean as $$
  select exists (
    select 1 from profiles
    where id = auth.uid() and active = true
  );
$$ language sql stable security definer set search_path = public;

-- ----------------------------------------------------------------------------
-- Enable RLS
-- ----------------------------------------------------------------------------
alter table branches            enable row level security;
alter table profiles            enable row level security;
alter table user_branches       enable row level security;
alter table areas               enable row level security;
alter table items               enable row level security;
alter table parrot_templates    enable row level security;
alter table inventory_weeks     enable row level security;
alter table inventory_sessions  enable row level security;
alter table inventory_counts    enable row level security;

-- ----------------------------------------------------------------------------
-- branches: lectura para cualquier autenticado; escritura solo ADMIN
-- ----------------------------------------------------------------------------
create policy branches_select on branches
  for select to authenticated using (true);

create policy branches_admin_write on branches
  for all to authenticated using (is_admin()) with check (is_admin());

-- ----------------------------------------------------------------------------
-- profiles: cada usuario ve/edita su propio perfil; ADMIN ve/edita todos
-- ----------------------------------------------------------------------------
create policy profiles_select_own on profiles
  for select to authenticated using (id = auth.uid() or is_admin());

create policy profiles_update_own on profiles
  for update to authenticated using (id = auth.uid() or is_admin())
  with check (id = auth.uid() or is_admin());

create policy profiles_admin_insert on profiles
  for insert to authenticated with check (is_admin());

-- ----------------------------------------------------------------------------
-- user_branches: el usuario ve las suyas; ADMIN administra todas
-- ----------------------------------------------------------------------------
create policy user_branches_select on user_branches
  for select to authenticated using (user_id = auth.uid() or is_admin());

create policy user_branches_admin_write on user_branches
  for all to authenticated using (is_admin()) with check (is_admin());

-- ----------------------------------------------------------------------------
-- areas / items: catálogo. Lectura para cualquier autenticado; escritura ADMIN
-- ----------------------------------------------------------------------------
create policy areas_select on areas
  for select to authenticated using (true);

create policy areas_admin_write on areas
  for all to authenticated using (is_admin()) with check (is_admin());

create policy items_select on items
  for select to authenticated using (true);

create policy items_admin_write on items
  for all to authenticated using (is_admin()) with check (is_admin());

-- ----------------------------------------------------------------------------
-- parrot_templates: solo ADMIN (contiene ruta a Storage)
-- ----------------------------------------------------------------------------
create policy parrot_templates_admin_all on parrot_templates
  for all to authenticated using (is_admin()) with check (is_admin());

-- ----------------------------------------------------------------------------
-- inventory_weeks: lectura para cualquier autenticado; escritura ADMIN/MANAGER
-- ----------------------------------------------------------------------------
create policy weeks_select on inventory_weeks
  for select to authenticated using (true);

create policy weeks_write on inventory_weeks
  for all to authenticated using (is_manager_or_admin()) with check (is_manager_or_admin());

-- ----------------------------------------------------------------------------
-- inventory_sessions:
--   - MANAGER/ADMIN: acceso total de lectura, y de escritura administrativa.
--   - COUNT_USER: lectura/escritura de sesiones de cualquier sucursal (sin
--     restricción, ver has_branch_access()). El cambio a COMPLETED solo
--     ocurre por el RPC complete_inventory_session (security definer), no
--     por UPDATE directo.
-- ----------------------------------------------------------------------------
create policy sessions_select on inventory_sessions
  for select to authenticated using (has_branch_access(branch_id));

create policy sessions_admin_write on inventory_sessions
  for all to authenticated using (is_manager_or_admin()) with check (is_manager_or_admin());

create policy sessions_count_user_update_status on inventory_sessions
  for update to authenticated
  using (has_branch_access(branch_id) and status in ('NOT_STARTED', 'IN_PROGRESS'))
  with check (has_branch_access(branch_id) and status in ('NOT_STARTED', 'IN_PROGRESS'));

-- ----------------------------------------------------------------------------
-- inventory_counts:
--   - Lectura: cualquiera con acceso a la sucursal de la sesión.
--   - Escritura (insert/update, upsert): solo si tiene acceso a la sucursal
--     Y la sesión no está COMPLETED/EXPORTED. counted_by debe ser el propio
--     usuario (evita que alguien registre conteos a nombre de otro).
-- ----------------------------------------------------------------------------
create policy counts_select on inventory_counts
  for select to authenticated using (
    exists (
      select 1 from inventory_sessions s
      where s.id = inventory_counts.inventory_session_id
        and has_branch_access(s.branch_id)
    )
  );

create policy counts_insert on inventory_counts
  for insert to authenticated with check (
    counted_by = auth.uid()
    and exists (
      select 1 from inventory_sessions s
      where s.id = inventory_counts.inventory_session_id
        and has_branch_access(s.branch_id)
        and s.status in ('NOT_STARTED', 'IN_PROGRESS')
    )
  );

create policy counts_update on inventory_counts
  for update to authenticated
  using (
    exists (
      select 1 from inventory_sessions s
      where s.id = inventory_counts.inventory_session_id
        and has_branch_access(s.branch_id)
        and s.status in ('NOT_STARTED', 'IN_PROGRESS')
    )
  )
  with check (
    counted_by = auth.uid()
    and exists (
      select 1 from inventory_sessions s
      where s.id = inventory_counts.inventory_session_id
        and has_branch_access(s.branch_id)
        and s.status in ('NOT_STARTED', 'IN_PROGRESS')
    )
  );

create policy counts_manager_read_all on inventory_counts
  for select to authenticated using (is_manager_or_admin());

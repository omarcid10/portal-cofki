-- ============================================================================
-- COFKI INVENTARIOS — 0003_seed_branches.sql
-- Sucursales iniciales. Se pueden agregar más después sin tocar código.
-- ============================================================================

insert into branches (name, code, active) values
  ('Aurora',         'AURORA',   true),
  ('Pueblo Serena',  'PSERENA',  true),
  ('GM3',            'GM3',      true)
on conflict (code) do nothing;

# Análisis de `reporte-conteo-2026-09-14.xlsx` (fuente de verdad)

Análisis hecho leyendo el archivo real con openpyxl/SheetJS. No se asumió
ninguna estructura de antemano.

## 1. Hojas (16 confirmadas)

| # | Nombre exacto de hoja (`parrot_sheet_name`)   | Categoría        | Nombre amigable       | Productos |
|---|------------------------------------------------|------------------|------------------------|-----------|
| 1 | `Barra y servicio abarrotes`                    | Barra y Servicio | Abarrotes               | 8 |
| 2 | `Barra y servicio café en grano ` *(espacio final)* | Barra y Servicio | Café en grano y té      | 6 |
| 3 | `Barra y servicio congelador ` *(espacio final)*    | Barra y Servicio | Congelador               | 6 |
| 4 | `Barra y servicio fruta y verdur` *(truncado)*      | Barra y Servicio | Fruta y verdura          | 5 |
| 5 | `Barra y servicio jugos`                        | Barra y Servicio | Jugos                    | 2 |
| 6 | `Barra y servicio polvos y jarab` *(truncado)*      | Barra y Servicio | Polvos y jarabes         | 8 |
| 7 | `Barra y servicio postres y gall` *(truncado)*      | Barra y Servicio | Postres y galletas       | 9 |
| 8 | `Barra y servicio refrescos y le` *(truncado)*      | Barra y Servicio | Refrescos y leches       | 11 |
| 9 | `Cocina abarrotes`                              | Cocina           | Abarrotes                | 67 |
| 10| `Cocina congelador`                             | Cocina           | Congelador               | 1 |
| 11| `Cocina fruta y verdura`                        | Cocina           | Fruta y verdura          | 34 |
| 12| `Cocina lacteos`                                | Cocina           | Lacteos                  | 11 |
| 13| `Cocina panaderia y tortillas ` *(espacio final)*   | Cocina           | Panaderia y tortillas    | 9 |
| 14| `Cocina produccion`                             | Cocina           | Produccion               | 28 |
| 15| `Cocina proteina`                               | Cocina           | Proteina                 | 18 |
| 16| `Nannies actividades`                           | Nannies          | Actividades              | 5 |

**Total: 16 hojas, 228 productos, 0 IDs duplicados.**

⚠️ **Importante:** varios nombres de hoja vienen truncados a 31 caracteres
(límite propio de Excel) o con espacios finales (`"...café en grano "`). Por
eso `parrot_sheet_name` se guarda tal cual, byte por byte, y **nunca** se
regenera ni se normaliza — es la clave para encontrar la hoja correcta al
exportar. El nombre amigable que ve el usuario se deriva de la columna J
("Area de Almacenamiento"), que sí trae el texto completo sin truncar.

## 2. Estructura de cada hoja

- **Fila 1:** agrupadores (`Interno`, `Información General`, `Información de Presentación`, con celdas combinadas).
- **Fila 2:** encabezados generales (`Parrot ID`, `Nombre de Insumo`, `Nombre de presentación`, `Cantidad`, `UdM de Presentación`, `Cantidad`, `UdM de receta`, `Presentaciones por caja`).
- **Fila 3:** encabezados de columna reales (`ID Parrot (No editar)`, `Nombre`, `Nombre de presentación`, `Cantidad*`, `Unidad`, `Cantidad*`, `Unidad`, `Presentaciones por caja`, `No. de cajas*`, `Area de Almacenamiento`).
- **Fila 4 en adelante:** un producto por fila.

Columnas (confirmado en las 16 hojas, sin excepción):

| Col | Contenido                          | ¿Se modifica al exportar? |
|-----|-------------------------------------|----------------------------|
| A   | ID Parrot                           | No |
| B   | Nombre                              | No |
| C   | Nombre de presentación              | No |
| D   | **Cantidad física (la que captura la app)** | **Sí — única columna que se escribe** |
| E   | Unidad (de la columna D)            | No |
| F   | Cantidad (receta)                   | No |
| G   | Unidad (de receta)                  | No |
| H   | Presentaciones por caja             | No |
| I   | No. de cajas                        | No |
| J   | Área de almacenamiento (texto completo) | No |

`freeze_panes = A4` y hay celdas combinadas en la fila 1 (`C1:J1`, `H2:J2`)
en todas las hojas — se deben preservar tal cual al exportar (por eso el
exportador abre la plantilla original y solo escribe celdas, nunca
reconstruye la hoja).

## 3. Identificación de producto y mapeo a celda

- **Identificador real:** `parrot_id` (columna A), ej. `IN-1724777243159`.
  Nunca el nombre — el propio archivo confirma esto: hay productos con el
  mismo tipo de nombre en distintas hojas pero ningún `parrot_id` repetido
  en las 228 filas.
- **Mapeo exacto a celda:** cada producto guarda `parrot_sheet_name` +
  `parrot_row` (número de fila real de Excel, 1-indexado, tal como aparece
  en el archivo — ej. fila 4 es el primer producto). Al exportar, la celda a
  escribir es simplemente `${parrot_sheet_name}!D${parrot_row}`. No se busca
  por nombre ni por posición relativa: se usa el número de fila guardado en
  el catálogo, así que un reordenamiento futuro en Parrot no rompe nada
  siempre que se vuelva a importar la plantilla.

## 4. Inconsistencias encontradas en el archivo real

- **Una celda con dato de ejemplo preexistente:** en la hoja
  `Barra y servicio café en grano `, fila 4 (`IN-1728342441359`, "Cafe en
  grano"), la columna D ya trae `2.5` en lugar de estar vacía. El resto de
  las 227 filas tiene D vacío (`''`). Al importar el catálogo **no leemos
  la columna D** (es dato de conteo, no de catálogo), así que esto no afecta
  la importación. Vale la pena confirmar contigo si ese `2.5` es un dato de
  prueba que se puede ignorar.
- **Columna H ("Presentaciones por caja")** viene llena en 36 de 228 filas
  y vacía en el resto — es normal, no todos los insumos manejan caja.
- **Columna C ("Nombre de presentación")** viene vacía en algunos productos
  (ej. "Ajo en polvo") — se guarda como `NULL`, es válido.
- **Solo existen dos unidades en todo el archivo:** `kg` y `pza`. No hay
  `g`, `l` ni `ml` como el prompt original contemplaba como posibles; el
  catálogo se importa tal cual venga (no se fuerza una lista fija de
  unidades), así que si en el futuro aparecen otras unidades no hay que
  tocar el importador.

## 5. Resumen numérico

- 16 hojas / áreas
- 228 productos
- 228 `parrot_id` únicos (sin duplicados)
- 3 categorías: Barra y Servicio (8 áreas, 55 productos), Cocina (7 áreas,
  168 productos), Nannies (1 área, 5 productos)
- 2 unidades: `kg`, `pza`
